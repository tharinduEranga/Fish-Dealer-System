package lk.ijse.Test;

public interface Tests {
    public static void m(){
        System.out.println("wwe");
    }
    public void m1();
}
