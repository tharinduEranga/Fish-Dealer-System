package lk.ijse.Test;

import java.util.Scanner;

public class TestDate  {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        System.out.println(decimal(in.nextInt()));
    }

    private static int decimal(int param){
        int inc=1;
        int dec=0;
        while (param>0){
            dec=dec+(param%10)*inc;
            inc=inc*2;
            param=param/10;
        }
        return dec;
    }


}

