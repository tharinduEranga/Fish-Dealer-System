package lk.ijse.Test;

import lk.ijse.generate.AutoGenerateId;

import java.sql.Array;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class Text {

    public static void main(String[] args) throws ParseException {
//        String pid="OR1998";
//        char ch=pid.charAt(pid.length()-1);
//        char ch1=pid.charAt(pid.length()-2);
//        char ch2=pid.charAt(pid.length()-3);
//
//        int a=Character.getNumericValue(ch);
//        int a1=Character.getNumericValue(ch1);
//        int a2=Character.getNumericValue(ch2);
//        if(a1==9&&a==9){
//            pid = pid.substring(0, pid.length() - 3);
//            a2++;
//            a1=0;
//            a=0;
//            pid=pid+a2+a1+a;
//        }
//        else if(a==9){
//            pid = pid.substring(0, pid.length() - 2);
//            a1++;
//            a=0;
//            pid=pid+a1+a;
//        }else{
//            pid = pid.substring(0, pid.length() - 1);
//            a++;
//            pid=pid+a;
//        }
//        java.sql.Date date= java.sql.Date.valueOf("2018-05-29");
//        int x=date.compareTo(java.sql.Date.valueOf("2018-11-31"));
//        System.out.println(x);
//        System.out.println(pid);
//
//                //creating instances of java.util.Date which represents today's date and time
//                java.util.Date now = new java.util.Date();
//                System.out.println("Value of java.util.Date : " + now);
//
//                //converting java.util.Date to java.sql.Date in Java
//                java.sql.Date sqlDate = new java.sql.Date(now.getTime());
//                System.out.println("Converted value of java.sql.Date : " + sqlDate);
//
//                //converting java.sql.Date to java.util.Date back
//                java.util.Date utilDate = new java.util.Date(sqlDate.getTime());
//                System.out.println("Converted value of java.util.Date : " + utilDate);


//        Calendar cal=Calendar.getInstance();
//        cal.add(Calendar.MONTH, 4);
//        cal.set(cal.DATE, cal.getActualMinimum(cal.DAY_OF_MONTH));
//        Date nmsd=cal.getTime();
//        cal.set(cal.DATE, cal.getActualMaximum(cal.DAY_OF_MONTH));
//        Date nmld=cal.getTime();
//        String dateWithoutTime=nmld+"";
//        String subbes=dateWithoutTime.substring(0, dateWithoutTime.length() - 17);
//        String desub=dateWithoutTime.substring(24, dateWithoutTime.length() - 0);
        //System.out.println(dateWithoutTime);
  //      LocalDateTime lt=toLocalDate(cal);
//        new Date(lt.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()).toString();
//        System.out.println(localDateTimeToDate(lt));
       // Read more: http://www.java67.com/2012/12/how-to-convert-sql-date-to-util-date.html#ixzz5HENJCfm6
        try {
            String id=new AutoGenerateId().generateId("Customer","CID");
            System.out.println(id);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static java.sql.Date localDateTimeToDate(LocalDateTime lt) {
        return new java.sql.Date(lt.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli());
    }

    private static LocalDateTime toLocalDate(Calendar cal) {
        TimeZone tz=cal.getTimeZone();
        ZoneId zid=tz==null?ZoneId.systemDefault():
                tz.toZoneId();
        return LocalDateTime.ofInstant(cal.toInstant(), zid);
    }
}
