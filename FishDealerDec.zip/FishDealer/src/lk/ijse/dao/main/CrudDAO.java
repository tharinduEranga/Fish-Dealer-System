package lk.ijse.dao.main;

        import lk.ijse.entity.SuperEntity;

public interface CrudDAO<T extends SuperEntity, K> extends SuperDAO {

}
