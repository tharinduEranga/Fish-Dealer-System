package lk.ijse.dao.main;

import lk.ijse.dbconnection.DBConnection;

import java.sql.*;

public class CrudUtility {
    public static PreparedStatement getStatement(String SQL, Object... params)throws ClassNotFoundException, SQLException{
        Connection conn=DBConnection.getInstance().getConnection();
        PreparedStatement stm=conn.prepareStatement(SQL);
        for (int i=0; i<params.length; i++) {
            stm.setObject(i + 1, params[i]);
        }
        return stm;
    }

    public static ResultSet executeQuery(String SQL, Object... params)throws ClassNotFoundException, SQLException{
        return getStatement(SQL, params).executeQuery();
    }
    public static int executeUpdate(String SQL, Object... params)throws ClassNotFoundException, SQLException{
        return getStatement(SQL, params).executeUpdate();
    }

}
