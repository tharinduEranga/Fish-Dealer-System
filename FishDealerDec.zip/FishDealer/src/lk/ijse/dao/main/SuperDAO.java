package lk.ijse.dao.main;

public interface SuperDAO {

}
