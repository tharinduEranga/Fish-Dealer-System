package lk.ijse.dao.main;


import lk.ijse.dao.impl.*;

public class DAOFactory {
    public enum DAOTypes{
        CUSTOMER, ITEM, ORDER, ORDERDETAIL, STOCK, SUPPLIER, PAYMENT, QUOTATION, MARKET, QUERY, DUESTOCK, PRIORITY, LOGIN;
    }

    private static DAOFactory dAOFactory;

    private DAOFactory(){

    }

    public static DAOFactory getInstance(){
        if (dAOFactory == null){
            dAOFactory = new DAOFactory();
        }
        return dAOFactory;
    }

    public <T> T getDAO(DAOTypes daoType){
        switch(daoType){
            case CUSTOMER:
                return (T) new CustomerDAOimpl();
            case ITEM:
                return (T) new ItemDAOimpl();
            case ORDERDETAIL:
                return (T) new CustomerOrderDetailsDAOimpl();
            case ORDER:
                return (T) new CustomerOrderDAOimpl();
            case QUERY:
                return (T) new QueryDAOimpl();
            case STOCK:
                return (T) new StockDAOimpl();
            case QUOTATION:
                return (T) new QuotationsDAOimpl();
            case MARKET:
                return (T) new MarketDAOimpl();
            case DUESTOCK:
                return (T) new DueStockDAOimpl();
            case PRIORITY:
                return (T) new PriorityDAOimpl();
            case PAYMENT:
                return (T) new CustomerPaymentDAOimpl();
            case SUPPLIER:
                return (T) new SupplierDAOimpl();
            case LOGIN:
                return (T) new LoginDAOimpl();
            default:
                return null;
        }
    }

}

