package lk.ijse.dao.impl;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import lk.ijse.dao.custom.PriorityDAO;
import lk.ijse.dao.main.CrudUtility;
import lk.ijse.entity.Priority;

import java.sql.ResultSet;

public class PriorityDAOimpl implements PriorityDAO {

    @Override
    public ObservableList<Priority> getAll() throws Exception {
        ResultSet rst= CrudUtility.executeQuery("SELECT * FROM PRIORITY");
        ObservableList<Priority>priorities= FXCollections.observableArrayList();
        while (rst.next()){
            priorities.add(new Priority(rst.getString("PID"),rst.getString("TYPE")));
        }
        return priorities;
    }

    @Override
    public String searchPriority(String pname) throws Exception {
        ResultSet rst=CrudUtility.executeQuery("SELECT PID FROM PRIORITY WHERE TYPE=?",pname);
        if(rst.next()){
            return rst.getString("PID");
        }
        return null;
    }
}
