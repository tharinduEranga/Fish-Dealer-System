package lk.ijse.dao.impl;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import lk.ijse.dao.custom.CustomerOrderDetailsDAO;
import lk.ijse.dao.main.CrudUtility;
import lk.ijse.entity.CustomEntity;
import lk.ijse.entity.CustomerOrderDetails;

import java.sql.ResultSet;

public class CustomerOrderDetailsDAOimpl implements CustomerOrderDetailsDAO{

    @Override
    public boolean addOcrderDetails(CustomerOrderDetails cod) throws Exception{
        return CrudUtility.executeUpdate("INSERT INTO customerorderdetails VALUES(?,?,?,?)",cod.getQty(),cod.getUnitPrice(),cod.getOd_pk().getOid(),cod.getOd_pk().getIid())>0;
    }

    @Override
    public ObservableList<CustomEntity> getAllOrderDetails() throws Exception {
        ResultSet rst=CrudUtility.executeQuery("select c.name, i.itemname, co.qty, co.pricePerItem\n" +
                "                from customer c, item i, customerorder cu, customerorderdetails co\n" +
                "                 where c.cid= cu.cid and cu.coid=co.coid and i.iid=co.iid");
        ObservableList<CustomEntity>orderDetails= FXCollections.observableArrayList();
        while (rst.next()){
            orderDetails.add(new CustomEntity(rst.getString("NAME"),rst.getString("ITEMNAME"),rst.getDouble("QTY"),rst.getDouble("pricePerItem")));
        }
        return orderDetails;
    }

    @Override
    public boolean updateDetail(double qty, String oid, String itemName) throws Exception {
        return CrudUtility.executeUpdate("update customerorderdetails set qty=? where COID=? AND ITEMNAME=?", qty ,oid, itemName)>0;
    }

    @Override
    public String getLastId() throws Exception {
        ResultSet rst=CrudUtility.executeQuery("SELECT CODID FROM CUSTOMERORDERDETAILS ORDER BY CODID DESC LIMIT 1");
        if (rst.next()){
            return rst.getString("CODID");
        }else
            return null;
    }

    @Override
    public ObservableList<CustomerOrderDetails> getOrderDetail(String oid) throws Exception {
        ResultSet rst=CrudUtility.executeQuery("SELECT * FROM CUSTOMERORDERDETAILS WHERE COID=?",oid);
        ObservableList<CustomerOrderDetails> od=FXCollections.observableArrayList();
        while (rst.next()){
            od.add(new CustomerOrderDetails(rst.getString("coid"),rst.getDouble("qty"),rst.getDouble("pricePerItem"),rst.getString("iid")));
        }
        return od;
    }

    @Override
    public double getTotalSoldKg() throws Exception {
        ResultSet rst=CrudUtility.executeQuery("SELECT SUM(QTY)AS TOTAL FROM customerorderdetails");
        if (rst.next()){
            return rst.getDouble("TOTAL");
        }else
            return 0.0;
    }
}
