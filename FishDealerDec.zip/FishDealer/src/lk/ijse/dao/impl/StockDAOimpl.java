package lk.ijse.dao.impl;

import javafx.collections.FXCollections;
import lk.ijse.dao.custom.StockDAO;
import lk.ijse.dao.main.CrudUtility;
import lk.ijse.entity.Stock;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class StockDAOimpl implements StockDAO{

    @Override
    public ArrayList<Stock> getSelectedStocks(String itemCode) throws SQLException, ClassNotFoundException {
        ArrayList<Stock>stocks=new ArrayList<>();
        ResultSet rst= CrudUtility.executeQuery("select * from stock where iid=?",itemCode);
        while (rst.next()){
            stocks.add(new Stock(rst.getString("stid"),rst.getString("iid"),rst.getDouble("qty"),rst.getDate("date"),rst.getString("sid"),rst.getDouble("cost")));
        }
        return stocks;
    }

    @Override
    public boolean updateStock(Stock stock) throws SQLException, ClassNotFoundException {
        return CrudUtility.executeUpdate("update stock set qty=? where stid=?",stock.getQty(),stock.getStid())>0;
    }

    @Override
    public String getLastId() throws Exception {
        ResultSet rst=CrudUtility.executeQuery("SELECT STID FROM STOCK ORDER BY STID DESC LIMIT 1");
        if (rst.next()){
            return rst.getString("STID");
        }else
            return null;
    }

    @Override
    public boolean addStock(Stock s) throws Exception {
        return CrudUtility.executeUpdate("INSERT INTO STOCK VALUES(?,?,?,?,?,?)",s.getStid(),s.getIid(),s.getQty(),s.getData(),s.getSid(),s.getCost())>0;
    }

    @Override
    public ArrayList<Stock> getAllStocks() throws Exception {
        ResultSet rst=CrudUtility.executeQuery("SELECT * FROM STOCK");
        ArrayList<Stock>s=new ArrayList<>();
        while (rst.next()){
            s.add(new Stock(rst.getString("stid"),rst.getString("iid"),rst.getDouble("qty"),rst.getDate("date"),rst.getString("sid"), rst.getDouble("cost")));
        }
        return s;
    }

    @Override
    public boolean deleteStock(String stid) throws Exception {
        return CrudUtility.executeUpdate("DELETE FROM STOCK WHERE STID=?",stid)>0;
    }
}
