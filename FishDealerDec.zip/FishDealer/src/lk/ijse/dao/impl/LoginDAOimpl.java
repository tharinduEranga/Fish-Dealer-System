package lk.ijse.dao.impl;

import lk.ijse.dao.custom.LoginDAO;
import lk.ijse.dao.main.CrudDAO;
import lk.ijse.dao.main.CrudUtility;
import lk.ijse.entity.Login;

import java.sql.ResultSet;

public class LoginDAOimpl implements LoginDAO {
    @Override
    public Login getLogin() throws Exception {
        ResultSet rst= CrudUtility.executeQuery("SELECT * FROM LOGIN");
        if(rst.next()){
            return new Login(rst.getString("USERNAME"),rst.getString("PASSWORD"));
        }else
            return null;
    }
}
