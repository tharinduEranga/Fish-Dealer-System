package lk.ijse.dao.impl;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import lk.ijse.dao.custom.MarketDAO;
import lk.ijse.dao.main.CrudUtility;
import lk.ijse.entity.Market;

import java.sql.ResultSet;

public class MarketDAOimpl implements MarketDAO{
    @Override
    public ObservableList<Market> geAllMarkets() throws Exception {
        ObservableList<Market>markets= FXCollections.observableArrayList();
        ResultSet rst= CrudUtility.executeQuery("SELECT * FROM MARKET");
        while (rst.next()){
            markets.add(new Market(rst.getString("MID"),rst.getString("NAME")));
            //System.out.println(rst.getString("MID")+rst.getString("NAME"));
        }
        return markets;
    }

    @Override
    public String getLastId() throws Exception {
        ResultSet rst=CrudUtility.executeQuery("SELECT MID FROM MARKET ORDER BY MID DESC LIMIT 1");
        if(rst.next()){
            return rst.getString("MID");
        }else
            return null;
    }

    @Override
    public boolean addMarket(Market market) throws Exception {
        return CrudUtility.executeUpdate("INSERT INTO MARKET VALUES(?,?,?)",market.getMid(),market.getMname(),market.getAddress())>0;
    }

    @Override
    public Market searchMarket(String s) throws Exception {
        ResultSet rst=CrudUtility.executeQuery("SELECT * FROM MARKET WHERE NAME=? OR MID=?", s, s);
        if (rst.next()){
            return new Market(rst.getString("MID"),rst.getString("NAME"),rst.getString("ADDRESS"));
        }else
            return null;
    }
}
