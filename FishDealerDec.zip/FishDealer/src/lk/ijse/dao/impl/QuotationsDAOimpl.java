package lk.ijse.dao.impl;

import javafx.collections.ObservableList;
import lk.ijse.dao.custom.QuotationsDAO;
import lk.ijse.dao.main.CrudUtility;
import lk.ijse.entity.Quotations;

import java.sql.ResultSet;

public class QuotationsDAOimpl implements QuotationsDAO{
    @Override
    public boolean addQuotation(Quotations q) throws Exception{
        return CrudUtility.executeUpdate("INSERT INTO QUOTATIONS VALUES(?,?,?,?)",q.getQid(),q.getPrice(),q.getCid(),q.getIid())>0;
    }

    @Override
    public String getLastId() throws Exception {
        ResultSet rst= CrudUtility.executeQuery("SELECT * FROM QUOTATIONS ORDER BY QID DESC LIMIT 1");
        if(rst.next()){
            return rst.getString("QID");
        }else
            return null;
    }
}
