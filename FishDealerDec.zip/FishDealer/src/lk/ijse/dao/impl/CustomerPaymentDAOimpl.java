package lk.ijse.dao.impl;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import lk.ijse.dao.custom.CustomerPaymentDAO;
import lk.ijse.dao.main.CrudUtility;
import lk.ijse.entity.CustomerPayment;

import java.sql.Date;
import java.sql.ResultSet;

public class CustomerPaymentDAOimpl implements CustomerPaymentDAO{
    @Override
    public boolean addPayment(CustomerPayment cp) throws Exception {
        return CrudUtility.executeUpdate("INSERT INTO customerpayment VALUES(?,?,?,?)",cp.getPid(),cp.getDate(),cp.getAmount(),cp.getOid())>0;
    }

    @Override
    public String getLastId() throws Exception {
        ResultSet rst=CrudUtility.executeQuery("SELECT * FROM customerpayment ORDER BY CPID DESC LIMIT 1");
        if(rst.next()){
            return rst.getString("CPID");
        }else
            return null;
    }

    @Override
    public CustomerPayment searchPaymrnt(String oid) throws Exception {
        ResultSet rst=CrudUtility.executeQuery("SELECT * FROM CUSTOMERPAYMENT WHERE CPID=? OR COID=?", oid, oid);
        if(rst.next()){
            return new CustomerPayment(rst.getString("CPID"),rst.getString("COID"),rst.getDate("DATE"),rst.getDouble("PAYMENT"));
        }else
            return null;
    }

    @Override
    public double getTotalOfAllPayments() throws Exception {
        ResultSet rst=CrudUtility.executeQuery("SELECT SUM(payment)as TOTAL FROM CUSTOMERPAYMENT");
        if(rst.next()){
            return rst.getDouble("TOTAL");
        }else
            return 0.0;
    }

    @Override
    public ObservableList<CustomerPayment> getAllPayments() throws Exception {
        ResultSet rst=CrudUtility.executeQuery("SELECT * FROM CUSTOMERPAYMENT");
        ObservableList<CustomerPayment>payment= FXCollections.observableArrayList();
        while (rst.next()){
            payment.add(new CustomerPayment(rst.getString("CPID"),rst.getString("COID"),rst.getDate("DATE"),rst.getDouble("PAYMENT")));
        }
        return payment;
    }
}
