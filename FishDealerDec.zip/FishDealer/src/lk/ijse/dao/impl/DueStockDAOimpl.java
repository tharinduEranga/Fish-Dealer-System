package lk.ijse.dao.impl;

import lk.ijse.dao.custom.DueStockDAO;
import lk.ijse.dao.main.CrudUtility;
import lk.ijse.entity.DueStock;

import java.sql.ResultSet;

public class DueStockDAOimpl implements DueStockDAO{
    @Override
    public boolean addnew(DueStock dueStock) throws Exception {
        return CrudUtility.executeUpdate("INSERT INTO DUESTOCK VALUES(?,?)",dueStock.getIid(),dueStock.getQty())>0;
    }

    @Override
    public String getLastId() throws Exception {
        ResultSet rst=CrudUtility.executeQuery("SELECT DSID FROM DUESTOCK ORDER BY DSID DESC LIMIT 1");
        if(rst.next()){
            return rst.getString("DSID");
        }
        else
            return null;
    }

    @Override
    public boolean delete(String iid) throws Exception {
        return CrudUtility.executeUpdate("DELETE FROM DUESTOCK WHERE IID=?",iid)>0;
    }

    @Override
    public boolean updateQty(String iid, double v) throws Exception {
        return CrudUtility.executeUpdate("UPDATE DUESTOCK SET QTY=? WHERE IID=?",v, iid)>0;
    }
}
