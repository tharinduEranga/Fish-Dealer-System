package lk.ijse.dao.impl;

import lk.ijse.dao.custom.ItemDAO;
import lk.ijse.dao.main.CrudUtility;
import lk.ijse.entity.Item;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ItemDAOimpl implements ItemDAO{

    public ObservableList<Item> getItemNames() throws SQLException, ClassNotFoundException {
        ObservableList<Item>items=FXCollections.observableArrayList();
        ResultSet rst=CrudUtility.executeQuery("SELECT * FROM ITEM");
        while (rst.next()){
            Item i=new Item(rst.getString("IID"),rst.getString("ITEMNAME"));
            items.add(i);
        }
        return items;
    }

    @Override
    public boolean updateItem(Item item) throws SQLException, ClassNotFoundException {
        return false;//CrudUtility.executeUpdate("UPDATE ITEM SET availableqty=? WHERE IID=?",item.getAvailableQty(), item.getIid())>0;
    }

    public Item getItem(String code) throws SQLException, ClassNotFoundException {
        ResultSet rst= CrudUtility.executeQuery("SELECT * FROM ITEM WHERE ITEMNAME like '%"+code+"%' OR IID like '%"+code+"%'");
        if(rst.next()){
            return new Item(rst.getString("IID"), rst.getString("ITEMNAME"));
        }else
            return null;
    }
}
