package lk.ijse.dao.impl;

import com.sun.org.apache.regexp.internal.RE;
import lk.ijse.dao.custom.QueryDAO;
import lk.ijse.dao.main.CrudUtility;
import lk.ijse.dto.ItemTableDTO;
import lk.ijse.entity.CustomEntity;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import lk.ijse.entity.Customer;
import lk.ijse.entity.Quotations;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.EventListener;

public class QueryDAOimpl implements QueryDAO {

    @Override
    public ObservableList<CustomEntity> getSuppliersWithMarket() throws SQLException, ClassNotFoundException {
        ObservableList<CustomEntity>suppliers= FXCollections.observableArrayList();
        ResultSet rst= CrudUtility.executeQuery("select s.sname, m.name, s.tel " +
                                                "from supplier s, market m " +
                                                "where m.mid=s.market group by s.sid");
        while (rst.next()){
            suppliers.add(new CustomEntity(rst.getString("SNAME"),rst.getString("NAME"),Integer.parseInt(rst.getString("TEL"))));
        }
        return suppliers;
    }

    @Override
    public ObservableList<CustomEntity> searchSuppliers(String name, String market) throws SQLException, ClassNotFoundException {
        ResultSet rst=null;
        if(!name.isEmpty()&&!market.isEmpty()) {
            rst = CrudUtility.executeQuery("select s.sname, m.name, s.tel from supplier s, market m where m.mid=s.market and s.sname like '%"+name+"%' and m.name=? group by s.sid", market);
        }else if(name.isEmpty()&&!market.isEmpty()){
            rst = CrudUtility.executeQuery("select s.sname, m.name, s.tel from supplier s, market m where m.mid=s.market and m.name=? group by s.sid", market);
        }else if(!name.isEmpty()&&market.isEmpty()){
            rst = CrudUtility.executeQuery("select s.sname, m.name, s.tel from supplier s, market m where m.mid=s.market and s.sname like '%"+name+"%' group by s.sid;");
        }
        ObservableList<CustomEntity>suppliers=FXCollections.observableArrayList();
        while (rst.next()){
            suppliers.add(new CustomEntity(rst.getString("SNAME"),rst.getString("NAME"),Integer.parseInt(rst.getString("TEL"))));
        }
        return suppliers;
    }

    @Override
    public ObservableList<CustomEntity> getAllItemsWithQty() throws SQLException, ClassNotFoundException {
       ResultSet rst=CrudUtility.executeQuery("SELECT i.iid, i.itemname, sum(s.qty)as availableQty from item i, stock s where i.iid=s.iid group by i.iid");
        ObservableList<CustomEntity> items=FXCollections.observableArrayList();
        while (rst.next()){
            items.add(new CustomEntity(rst.getString("IID"),rst.getString("ITEMNAME"),rst.getDouble("availableQty")));
        }
        return items;
    }

    @Override
    public CustomEntity getItem(String name) throws SQLException, ClassNotFoundException {
        ResultSet rst=CrudUtility.executeQuery("SELECT i.iid, i.itemname, sum(s.qty)as availableQty from item i, stock s where i.iid=s.iid and i.itemname like '%"+name+"%' group by i.iid");
        if(rst.next()){
            return new CustomEntity(rst.getString("IID"),rst.getString("ITEMNAME"),rst.getDouble("availableQty"));
        }
        else
            return null;
    }

    @Override
    public ObservableList<CustomEntity> getAllQuotations() throws Exception {
        ResultSet rst=CrudUtility.executeQuery("select c.name, i.itemname, q.price from quotations q, customer c, item i where c.cid=q.cid and i.iid=q.iid group by q.qid");
        ObservableList<CustomEntity> quo=FXCollections.observableArrayList();
        while (rst.next()){
            quo.add(new CustomEntity(rst.getString("name"),rst.getString("ITEMNAME"),rst.getDouble("price")));
        }
        return quo;
    }

    @Override
    public ObservableList<String> getNonQuoCustomers() throws Exception {
        ResultSet rst=CrudUtility.executeQuery("select * from customer");
        ObservableList<String>customers=FXCollections.observableArrayList();
        while (rst.next()){
            customers.add(rst.getString("NAME"));
        }
        return customers;
    }

    @Override
    public ObservableList<CustomEntity> getStockForTable() throws Exception {
        ResultSet rst=CrudUtility.executeQuery("SELECT I.IID, I.ITEMNAME, S.QTY, S.COST, SU.SNAME, S.DATE\n" +
                "                FROM ITEM I, STOCK S, SUPPLIER SU\n" +
                "                WHERE I.IID=S.IID AND SU.SID=S.SID\n" +
                "                GROUP BY S.STID\n" +
                "                ORDER BY S.DATE DESC");
        ObservableList<CustomEntity>stock=FXCollections.observableArrayList();
        while (rst.next()){
            stock.add(new CustomEntity(rst.getString("IID"),rst.getString("ITEMNAME"),rst.getDouble("QTY"),rst.getDouble("COST"),rst.getString("SNAME"),rst.getDate("DATE")));
        }
        return stock;
    }

    @Override
    public ObservableList<CustomEntity> getDueStocks() throws Exception {
        ResultSet rst=CrudUtility.executeQuery("SELECT I.ITEMNAME, D.QTY FROM ITEM I, DUESTOCK D WHERE I.IID=D.IID");
        ObservableList<CustomEntity>duestocks=FXCollections.observableArrayList();
        while (rst.next()){
            duestocks.add(new CustomEntity(rst.getString("ITEMNAME"),rst.getDouble("qty")));
        }
        return duestocks;
    }

    @Override
    public ObservableList<CustomEntity> getOrdersForTable() throws Exception {
        ResultSet rst=CrudUtility.executeQuery("select co.coid, c.name, p. type, co.date, co.price\n" +
                "from customer c, customerorder co, priority p\n" +
                "where c.cid= co.cid and co.pid=p.pid\n" +
                "group by co.coid;");
        ObservableList<CustomEntity>orders=FXCollections.observableArrayList();
        while (rst.next()){
            orders.add(new CustomEntity(rst.getString("coid"),rst.getString("name"),rst.getString("type"),rst.getDouble("price"),rst.getDate("date")));
        }
        return orders;
    }

    @Override
    public ObservableList<CustomEntity> getOrderDetail(String oid) throws Exception {
        ResultSet rst=CrudUtility.executeQuery("select i.itemname, od.qty, od.priceperitem from item i, customerorderdetails od where i.iid=od.iid and od.coid=?",oid);
        ObservableList<CustomEntity>orderDetail=FXCollections.observableArrayList();
        while (rst.next()){
            orderDetail.add(new CustomEntity(rst.getString("itemname"),rst.getDouble("qty"),rst.getDouble("priceperitem")));
        }
        return orderDetail;
    }

    @Override
    public CustomEntity searchOrderToPay(String oid) throws Exception {
        ResultSet rst=CrudUtility.executeQuery("select c.name, co.date, co.price from customer c, customerorder co where c.cid=co.cid and co.coid=?",oid);
        if(rst.next()){
            return new CustomEntity(rst.getString("name"),rst.getDate("date"),rst.getDouble("price"));
        }else
            return null;
    }

    @Override
    public ObservableList<CustomEntity> searchStock(String name) throws Exception {
        ResultSet rst=CrudUtility.executeQuery("SELECT I.IID, I.ITEMNAME, S.QTY, S.COST, SU.SNAME, S.DATE\n" +
                "                FROM ITEM I, STOCK S, SUPPLIER SU\n" +
                "                WHERE I.IID=S.IID AND SU.SID=S.SID AND I.IID=?\n" +
                "                GROUP BY S.STID\n" +
                "                ORDER BY S.DATE DESC",name);
        ObservableList<CustomEntity>stock=FXCollections.observableArrayList();
        while (rst.next()){
            stock.add(new CustomEntity(rst.getString("IID"),rst.getString("ITEMNAME"),rst.getDouble("QTY"),rst.getDouble("COST"),rst.getString("SNAME"),rst.getDate("DATE")));
        }
        return stock;
    }

    @Override
    public ObservableList<CustomEntity> searchOrders(String cid, Date date) throws Exception {
        ResultSet rst=null;
        if(cid.isEmpty()&&date!=null) {
            rst = CrudUtility.executeQuery("select co.coid, c.name, co.date, p.type, co.price\n" +
                    "from customer c, customerorder co, priority p\n" +
                    "where c.cid= co.cid and co.pid=p.pid and co.date=?\n" +
                    "group by co.coid;",date);
        }else if(!cid.isEmpty()&&date==null) {
            //System.out.println(cid+"    Cus id");
            rst = CrudUtility.executeQuery("select co.coid, c.name, co.date, p.type, co.price\n" +
                    "from customer c, customerorder co, priority p\n" +
                    "where c.cid= co.cid and co.pid=p.pid and co.cid=?\n" +
                    "group by co.coid;",cid);
        }else if(!cid.isEmpty()&&date!=null) {
            rst = CrudUtility.executeQuery("select co.coid, c.name, co.date, p.type, co.price\n" +
                    "from customer c, customerorder co, priority p\n" +
                    "where c.cid= co.cid and co.pid=p.pid and co.cid=? and co.date=?\n" +
                    "group by co.coid;",cid, date);
        }
        ObservableList<CustomEntity>orders=FXCollections.observableArrayList();
        while (rst.next()){
            orders.add(new CustomEntity(rst.getString("coid"),rst.getString("name"),rst.getString("type"),rst.getDouble("price"),rst.getDate("date")));
        }
        return orders;
    }
    @Override
    public ObservableList<CustomEntity> searchSceduledOrders(String cid, Date date) throws Exception {
        ResultSet rst=null;
        if(cid.isEmpty()&&date!=null) {
            rst = CrudUtility.executeQuery("select co.coid, c.name, co.date, p.type, co.price\n" +
                    "from customer c, customerorder co, priority p, customerpayment pm\n" +
                    "where c.cid= co.cid and co.coid=pm.coid and co.date=?\n" +
                    "group by co.coid",date);
        }else if(!cid.isEmpty()&&date==null) {
            rst = CrudUtility.executeQuery("select co.coid, c.name, co.date, p.type, co.price\n" +
                    "from customer c, customerorder co, priority p, customerpayment pm\n" +
                    "where c.cid= co.cid and co.coid=pm.coid and co.cid=?\n" +
                    " group by co.coid",cid);
        }else if(!cid.isEmpty()&&date!=null) {
            rst = CrudUtility.executeQuery("select co.coid, c.name, co.date, p.type, co.price\n" +
                    "from customer c, customerorder co, priority p, customerpayment pm\n" +
                    "where c.cid= co.cid and co.coid=pm.coid and co.cid=? and co.date=?\n" +
                    " group by co.coid",cid, date);
        }
        ObservableList<CustomEntity>orders=FXCollections.observableArrayList();
        while (rst.next()){
            orders.add(new CustomEntity(rst.getString("coid"),rst.getString("name"),rst.getString("type"),rst.getDouble("price"),rst.getDate("date")));
        }
        return orders;
    }

    @Override
    public ObservableList<CustomEntity> getAllPayments() throws Exception {
        ResultSet rst=CrudUtility.executeQuery("SELECT P.CPID, C.NAME, P.DATE, P.PAYMENT FROM CUSTOMER C, customerpayment P, customerORDER CO WHERE C.CID=CO.CID AND CO.COID=P.COID GROUP BY P.CPID");
        ObservableList<CustomEntity>pm=FXCollections.observableArrayList();
        while (rst.next()){
            pm.add(new CustomEntity(rst.getString("NAME"),rst.getDate("date"),rst.getDouble("PAYMENT"), rst.getString("CPID")));
        }
        return pm;
    }

    @Override
    public ObservableList<CustomEntity> searchQuotations(String cu, String fi) throws Exception {
        ResultSet rst=null;
        if(!cu.equals("")&&fi.equals("")) {
            rst = CrudUtility.executeQuery("select c.name, i.itemname, q.price from quotations q, customer c, item i where c.cid=q.cid and i.iid=q.iid and q.cid like '%"+cu+"%' group by q.qid");
        }else if (cu.equals("")&&!fi.equals("")){
            rst = CrudUtility.executeQuery("select c.name, i.itemname, q.price from quotations q, customer c, item i where c.cid=q.cid and i.iid=q.iid and q.iid like '%"+fi+"%' group by q.qid");
        }else if (!cu.equals("")&&!fi.equals("")){
            rst = CrudUtility.executeQuery("select c.name, i.itemname, q.price from quotations q, customer c, item i where c.cid=q.cid and i.iid=q.iid and q.cid like '%"+cu+"%' and q.iid like '%"+fi+"%' group by q.qid");
        }
        ObservableList<CustomEntity> quo=FXCollections.observableArrayList();
        while (rst.next()){
            quo.add(new CustomEntity(rst.getString("name"),rst.getString("ITEMNAME"),rst.getDouble("price")));
        }
        if(quo.size()>0) {
            return quo;
        }else
            return null;
    }

    @Override
    public ObservableList<CustomEntity> getScheduledOrders() throws Exception {
        ResultSet rst=CrudUtility.executeQuery("select co.coid, c.name, co.date, p.type, co.price\n" +
                "                                from customer c, customerorder co, priority p\n" +
                "                                where c.cid= co.cid and co.pid=p.pid and co.date>=date(curdate())\n" +
                "                                group by co.coid");
        ObservableList<CustomEntity>so=FXCollections.observableArrayList();
        while (rst.next()){
            so.add(new CustomEntity(rst.getString("coid"),rst.getString("name"),rst.getString("type"),rst.getDouble("price"),rst.getDate("date")));
        }
        return so;
    }

    @Override
    public ObservableList<CustomEntity> getPlacedOrders() throws Exception {
        ResultSet rst=CrudUtility.executeQuery("select co.coid, c.name, co.date, p.type, co.price\n" +
                "                                from customer c, customerorder co, priority p, customerpayment pm\n" +
                "                                where c.cid= co.cid and co.pid=p.pid and co.coid=pm.coid\n" +
                "                                group by co.coid");
        ObservableList<CustomEntity>so=FXCollections.observableArrayList();
        while (rst.next()){
            so.add(new CustomEntity(rst.getString("coid"),rst.getString("name"),rst.getString("type"),rst.getDouble("price"),rst.getDate("date")));
        }
        return so;
    }

    @Override
    public Quotations getQuotationPrice(String cid, String iid) throws Exception {
        ResultSet rst=CrudUtility.executeQuery("select * from quotations where cid=? and iid=?",cid,iid);
        if (rst.next()){
            return new Quotations(rst.getString(1),rst.getDouble(2),rst.getString(3),rst.getString(4));
        }else
            return null;
    }
}
