package lk.ijse.dao.impl;

import lk.ijse.dao.custom.CustomerOrderDAO;
import lk.ijse.dao.main.CrudUtility;
import lk.ijse.entity.CustomEntity;
import lk.ijse.entity.CustomerOrder;

import java.sql.ResultSet;
import java.util.ArrayList;

public class CustomerOrderDAOimpl implements CustomerOrderDAO{
    public String getLastOrderId() throws Exception{
        ResultSet rst= CrudUtility.executeQuery("SELECT COID FROM CUSTOMERORDER ORDER BY COID DESC LIMIT 1");
        if(rst.next()) {
            return rst.getString("COID");
        }else
            return null;
    }

    @Override
    public boolean addOrder(CustomerOrder order) throws Exception {
        return CrudUtility.executeUpdate("INSERT INTO customerorder VALUES(?,?,?,?,?)",order.getOid(),order.getDate(),order.getPriority(),order.getCid(),order.getPrice())>0;
    }

    @Override
    public boolean updateOrder(CustomerOrder order) throws Exception {
        return false;
    }

    @Override
    public boolean deleteOrder(String oid) throws Exception {
        return CrudUtility.executeUpdate("DELETE FROM CUSTOMERORDER WHERE COID=?", oid)>0;
    }

    @Override
    public ArrayList<CustomerOrder> getAllOrders() throws Exception {
        ResultSet rst = CrudUtility.executeQuery("SELECT * FROM CUSTOMERORDER");
        ArrayList<CustomerOrder>orders=new ArrayList<>();
        while (rst.next()){
            orders.add(new CustomerOrder(rst.getString("COID"),rst.getDate("date"),rst.getString("CID"),rst.getString("pid"),rst.getDouble("PRICE")));
        }
        return orders;
    }

    @Override
    public int getOrdersCount() throws Exception {
        ResultSet rst=CrudUtility.executeQuery("SELECT COUNT(COID)AS COUNT FROM CUSTOMERORDER");
        if(rst.next()){
            return rst.getInt("COUNT");
        }else
            return 0;
    }

    @Override
    public CustomerOrder searchOrder(String oid) throws Exception {
        ResultSet rst=CrudUtility.executeQuery("SELECT * FROM CUSTOMERORDER WHERE COID=?", oid);
        if(rst.next()){
            return new CustomerOrder(rst.getString("COID"), rst.getDate("DATE"), rst.getString("CID"), rst.getString("PID"), rst.getDouble("PRICE"));
        }
        else
            return null;
    }

}
