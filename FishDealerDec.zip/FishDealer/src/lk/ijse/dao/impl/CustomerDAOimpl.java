package lk.ijse.dao.impl;

import lk.ijse.dao.custom.CustomerDAO;
import lk.ijse.dao.main.CrudUtility;
import lk.ijse.entity.Customer;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
import java.time.LocalDate;

public class CustomerDAOimpl implements CustomerDAO{
    @Override
    public ObservableList<Customer> getCustomerNames() throws ClassNotFoundException, SQLException {
        ObservableList<Customer>custNames=FXCollections.observableArrayList();
        ResultSet rst=CrudUtility.executeQuery("SELECT * FROM CUSTOMER");
        while (rst.next()){
            custNames.add(new Customer(rst.getString("CID"),rst.getString("NAME"),rst.getString("ADDRESS"),Integer.parseInt(rst.getString("TEL")),rst.getDate("REGDATE")));
        }
        return custNames;
    }

    public boolean addCustomer(Customer c) throws SQLException, ClassNotFoundException {
        return CrudUtility.executeUpdate("INSERT INTO CUSTOMER VALUES(?,?,?,?,?)", c.getCid(),c.getName(),c.getAddress(),c.getTel(),c.getDate())>0;
    }

    @Override
    public Customer searchCustomer(String cid) throws SQLException, ClassNotFoundException {
        ResultSet rst=CrudUtility.executeQuery("SELECT * FROM CUSTOMER WHERE CID LIKE '%"+cid+"%' OR NAME like '%"+cid+"%'");
        if(rst.next()){
            return new Customer(rst.getString("CID"), rst.getString("NAME"),rst.getString("ADDRESS"),Integer.parseInt(rst.getString("TEL")),rst.getDate("REGDATE"));
        }
        return null;
    }

    @Override
    public String getLastCustomerId() throws SQLException, ClassNotFoundException {
        ResultSet rst=CrudUtility.executeQuery("SELECT * FROM CUSTOMER ORDER BY CID DESC LIMIT 1");
        if(rst.next()) {
            return rst.getString("CID");
        }else
            return null;
    }

    @Override
    public boolean updateCustomer(Customer c) throws SQLException, ClassNotFoundException {
        return CrudUtility.executeUpdate("UPDATE CUSTOMER SET NAME=?, ADDRESS=?, TEL=?, REGDATE=? WHERE CID=?",c.getName(),c.getAddress(),c.getTel(),c.getDate(),c.getCid())>0;
    }

    @Override
    public ObservableList<Customer> searchCustomers(String text, String value) throws SQLException, ClassNotFoundException {
        ObservableList<Customer>customers=FXCollections.observableArrayList();
        ResultSet rst=null;
        if(text.isEmpty()&&!value.isEmpty()){
            rst=CrudUtility.executeQuery("SELECT * FROM CUSTOMER WHERE regdate like '%"+value+"%'");
        }else if(!text.isEmpty()&&!value.isEmpty()){
            rst=CrudUtility.executeQuery("SELECT * FROM CUSTOMER WHERE (NAME LIKE '%"+text+"%' or address LIKE '%"+text+"%') AND regdate like '%"+value+"%'");
        }else if(!text.isEmpty()&&value.isEmpty()){
            rst=CrudUtility.executeQuery("SELECT * FROM CUSTOMER WHERE NAME LIKE '%"+text+"%' or address LIKE '%"+text+"%'");
        }
        while (rst.next()){
            customers.add(new Customer(rst.getString("CID"),rst.getString("NAME"),rst.getString("ADDRESS"),Integer.parseInt(rst.getString("TEL")),rst.getDate("REGDATE")));
        }
        return customers;
    }

    @Override
    public boolean deleteCustomer(String cid) throws Exception {
        return CrudUtility.executeUpdate("DELETE FROM CUSTOMER WHERE CID=? OR NAME=?",cid, cid)>0;
    }
}
