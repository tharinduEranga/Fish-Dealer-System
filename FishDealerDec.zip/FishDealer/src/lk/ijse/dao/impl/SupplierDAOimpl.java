package lk.ijse.dao.impl;

import javafx.collections.FXCollections;
import lk.ijse.controller.ReportController;
import lk.ijse.dao.custom.SupplierDAO;
import lk.ijse.dao.main.CrudUtility;
import lk.ijse.entity.Supplier;
import javafx.collections.ObservableList;

import java.sql.ResultSet;
import java.sql.SQLException;

public class SupplierDAOimpl implements SupplierDAO{
    @Override
    public ObservableList<Supplier> getAllSuppliers() throws SQLException, ClassNotFoundException {
        ResultSet rst= CrudUtility.executeQuery("SELECT * FROM SUPPLIER");
        ObservableList<Supplier>suppliers= FXCollections.observableArrayList();
        while (rst.next()){
            suppliers.add(new Supplier(rst.getString("sid"),rst.getString("sname"),rst.getString("market"),rst.getInt("tel")));
        }
        return suppliers;
    }

    @Override
    public Supplier searchSupplier(String name) throws Exception {
        ResultSet rst= CrudUtility.executeQuery("select * from supplier where sname like '%"+name+"%'");
        if (rst.next()){
            return new Supplier(rst.getString("sid"),rst.getString("sname"),rst.getString("market"),rst.getInt("tel"));
        }else
            return null;
    }

    @Override
    public String getLastId() throws Exception {
        ResultSet rst=CrudUtility.executeQuery("SELECT SID FROM SUPPLIER ORDER BY SID DESC LIMIT 1");
        if (rst.next()){
            return rst.getString("SID");
        }else
            return null;
    }

    @Override
    public boolean addSupplier(Supplier s) throws Exception {
        return CrudUtility.executeUpdate("INSERT INTO SUPPLIER VALUES(?,?,?,?)", s.getId(), s.getName(), s.getMid(), s.getTel())>0;
    }

}
