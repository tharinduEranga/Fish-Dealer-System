package lk.ijse.dao.custom;

import lk.ijse.dao.main.CrudDAO;
import lk.ijse.entity.Customer;
import lk.ijse.entity.DueStock;

public interface DueStockDAO extends CrudDAO<Customer, String> {
    boolean addnew(DueStock dueStock)throws Exception;

    String getLastId()throws Exception;

    boolean delete(String iid)throws Exception;

    boolean updateQty(String iid, double v)throws Exception;
}
