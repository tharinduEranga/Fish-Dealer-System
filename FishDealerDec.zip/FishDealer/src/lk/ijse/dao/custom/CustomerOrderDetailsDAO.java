package lk.ijse.dao.custom;

import javafx.collections.ObservableList;
import lk.ijse.dao.main.CrudDAO;
import lk.ijse.entity.CustomEntity;
import lk.ijse.entity.Customer;
import lk.ijse.entity.CustomerOrderDetails;

public interface CustomerOrderDetailsDAO extends CrudDAO<Customer, String> {

    boolean addOcrderDetails(CustomerOrderDetails customerOrderDetails) throws Exception;

    ObservableList<CustomEntity> getAllOrderDetails()throws Exception;

    boolean updateDetail(double qty, String oid, String itemName)throws Exception;

    String getLastId()throws Exception;

    ObservableList<CustomerOrderDetails> getOrderDetail(String oid)throws Exception;

    double getTotalSoldKg()throws Exception;
}
