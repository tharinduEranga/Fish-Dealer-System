package lk.ijse.dao.custom;

import lk.ijse.dao.main.CrudDAO;
import lk.ijse.entity.Customer;
import lk.ijse.entity.Supplier;
import javafx.collections.ObservableList;

import java.sql.SQLException;

public interface SupplierDAO extends CrudDAO<Customer, String> {
    ObservableList<Supplier> getAllSuppliers() throws SQLException, ClassNotFoundException;


    Supplier searchSupplier(String name)throws Exception;

    String getLastId()throws Exception;

    boolean addSupplier(Supplier supplier)throws Exception;
}
