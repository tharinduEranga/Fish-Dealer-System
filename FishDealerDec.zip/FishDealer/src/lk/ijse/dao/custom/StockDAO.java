package lk.ijse.dao.custom;

import lk.ijse.dao.main.CrudDAO;
import lk.ijse.entity.Customer;
import lk.ijse.entity.Stock;

import java.sql.SQLException;
import java.util.ArrayList;

public interface StockDAO extends CrudDAO<Customer, String> {
    ArrayList<Stock> getSelectedStocks(String itemCode) throws SQLException, ClassNotFoundException;

    boolean updateStock(Stock stock) throws SQLException, ClassNotFoundException;

    String getLastId()throws Exception;

    boolean addStock(Stock stock)throws Exception;

    ArrayList<Stock> getAllStocks()throws Exception;

    boolean deleteStock(String stid)throws Exception;
}
