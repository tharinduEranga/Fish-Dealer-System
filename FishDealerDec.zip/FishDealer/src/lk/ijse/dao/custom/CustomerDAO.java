package lk.ijse.dao.custom;

import lk.ijse.dao.main.CrudDAO;
import lk.ijse.entity.Customer;
import javafx.collections.ObservableList;

import java.sql.SQLException;

public interface CustomerDAO extends CrudDAO<Customer, String> {
    public boolean addCustomer(Customer c) throws SQLException, ClassNotFoundException;

    public Customer searchCustomer(String cid) throws SQLException, ClassNotFoundException;

    public String getLastCustomerId() throws SQLException, ClassNotFoundException;

    public boolean updateCustomer(Customer customer) throws SQLException, ClassNotFoundException;

    public ObservableList<Customer> getCustomerNames() throws ClassNotFoundException, SQLException;

    ObservableList<Customer> searchCustomers(String text, String value) throws SQLException, ClassNotFoundException;

    boolean deleteCustomer(String cid)throws Exception;
}
