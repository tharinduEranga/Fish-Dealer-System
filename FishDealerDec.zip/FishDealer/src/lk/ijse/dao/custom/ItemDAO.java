package lk.ijse.dao.custom;

import lk.ijse.dao.main.CrudDAO;
import lk.ijse.dto.ItemTableDTO;
import lk.ijse.entity.Customer;
import lk.ijse.entity.Item;
import javafx.collections.ObservableList;

import java.sql.SQLException;

public interface ItemDAO extends CrudDAO<Customer, String> {
    public Item getItem(String name) throws SQLException, ClassNotFoundException;
    public ObservableList<Item> getItemNames() throws SQLException, ClassNotFoundException;
    boolean updateItem(Item item) throws SQLException, ClassNotFoundException;


}
