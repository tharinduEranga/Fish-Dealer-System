package lk.ijse.dao.custom;

import javafx.collections.ObservableList;
import lk.ijse.dao.main.CrudDAO;
import lk.ijse.entity.Customer;
import lk.ijse.entity.CustomerPayment;

public interface CustomerPaymentDAO extends CrudDAO<Customer, String> {
    boolean addPayment(CustomerPayment cp)throws Exception;

    String getLastId()throws Exception;

    CustomerPayment searchPaymrnt(String oid)throws Exception;

    double getTotalOfAllPayments()throws Exception;

    ObservableList<CustomerPayment> getAllPayments()throws Exception;
}
