package lk.ijse.dao.custom;

import javafx.collections.ObservableList;
import lk.ijse.dao.main.CrudDAO;
import lk.ijse.entity.Customer;
import lk.ijse.entity.Market;

public interface MarketDAO extends CrudDAO<Customer, String> {
    ObservableList<Market> geAllMarkets()throws Exception;

    String getLastId()throws Exception;

    boolean addMarket(Market market)throws Exception;

    Market searchMarket(String s)throws Exception;
}
