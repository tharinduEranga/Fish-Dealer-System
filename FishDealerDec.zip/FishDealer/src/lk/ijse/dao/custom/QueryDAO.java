package lk.ijse.dao.custom;

import lk.ijse.dto.ItemTableDTO;
import lk.ijse.entity.CustomEntity;
import javafx.collections.ObservableList;
import lk.ijse.entity.Quotations;

import java.sql.Date;
import java.sql.SQLException;

public interface QueryDAO {
    ObservableList<CustomEntity> getSuppliersWithMarket() throws SQLException, ClassNotFoundException;

    ObservableList<CustomEntity> searchSuppliers(String text, String s)throws SQLException, ClassNotFoundException;

    ObservableList<CustomEntity> getAllItemsWithQty() throws SQLException, ClassNotFoundException;

    CustomEntity getItem(String name) throws SQLException, ClassNotFoundException;

    ObservableList<CustomEntity> getAllQuotations()throws Exception;

    ObservableList<String> getNonQuoCustomers()throws Exception;

    ObservableList<CustomEntity> getStockForTable()throws Exception;

    ObservableList<CustomEntity> getDueStocks()throws Exception;

    ObservableList<CustomEntity> getOrdersForTable()throws Exception;

    ObservableList<CustomEntity> getOrderDetail(String oid)throws Exception;

    CustomEntity searchOrderToPay(String oid)throws Exception;

    ObservableList<CustomEntity> searchStock(String name)throws Exception;

    ObservableList<CustomEntity> searchOrders(String cid, Date date)throws Exception;

    ObservableList<CustomEntity> getScheduledOrders()throws Exception;

    ObservableList<CustomEntity> getPlacedOrders()throws Exception;

    Quotations getQuotationPrice(String cid, String iid)throws Exception;

    ObservableList<CustomEntity> searchSceduledOrders(String cid, Date date) throws Exception;

    ObservableList<CustomEntity> getAllPayments()throws Exception;

    ObservableList<CustomEntity> searchQuotations(String cu, String fi)throws Exception;
}
