package lk.ijse.dao.custom;

import lk.ijse.dao.main.CrudDAO;
import lk.ijse.entity.CustomEntity;
import lk.ijse.entity.Customer;
import lk.ijse.entity.CustomerOrder;

import java.util.ArrayList;

public interface CustomerOrderDAO extends CrudDAO<Customer, String> {

    String getLastOrderId() throws Exception;
    boolean addOrder(CustomerOrder order)throws Exception;
    boolean updateOrder(CustomerOrder order)throws Exception;
    boolean deleteOrder(String oid)throws Exception;
    ArrayList<CustomerOrder>getAllOrders()throws Exception;
    int getOrdersCount()throws Exception;

    CustomerOrder searchOrder(String oid)throws Exception;
}
