package lk.ijse.dao.custom;

import lk.ijse.dao.main.CrudDAO;
import lk.ijse.entity.Login;

public interface LoginDAO extends CrudDAO<Login, String> {

    Login getLogin()throws Exception;
}
