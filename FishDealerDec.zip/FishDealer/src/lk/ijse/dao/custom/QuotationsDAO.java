package lk.ijse.dao.custom;

import javafx.collections.ObservableList;
import lk.ijse.dao.main.CrudDAO;
import lk.ijse.entity.Customer;
import lk.ijse.entity.Quotations;

public interface QuotationsDAO extends CrudDAO<Customer, String> {
    boolean addQuotation(Quotations quotations)throws Exception;

    String getLastId()throws Exception;

}
