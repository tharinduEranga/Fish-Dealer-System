package lk.ijse.dao.custom;

import javafx.collections.ObservableList;
import lk.ijse.dao.main.CrudDAO;
import lk.ijse.entity.Customer;
import lk.ijse.entity.Priority;

public interface PriorityDAO extends CrudDAO<Customer, String> {
    ObservableList<Priority> getAll()throws Exception;

    String searchPriority(String pname)throws Exception;
}
