package lk.ijse.main;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TabPane;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Main extends Application {
    Stage stage;
    public static Main m;
    public static Main getCurrentInstance(){
        return m;
    }

    public void close(){
        stage.close();
    }

    @Override
    public void start(Stage st) throws Exception{
        this.stage=st;
        Parent root = FXMLLoader.load(getClass().getResource("../View/Login.fxml"));
        stage.initStyle(StageStyle.UNDECORATED);
        stage.setScene(new Scene(root, 849, 500));
        stage.show();
        m=this;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
