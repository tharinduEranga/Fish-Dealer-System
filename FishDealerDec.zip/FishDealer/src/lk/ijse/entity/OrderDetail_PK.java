package lk.ijse.entity;

public class OrderDetail_PK {
    private String oid;
    private String iid;

    public OrderDetail_PK(String oid, String iid) {

        this.oid = oid;
        this.iid = iid;
    }
    public String getOid() {
        return oid;
    }

    public String getIid() {
        return iid;
    }
}
