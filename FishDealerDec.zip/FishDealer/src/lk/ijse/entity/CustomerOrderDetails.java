package lk.ijse.entity;

public class CustomerOrderDetails implements SuperEntity {
    //String odid;
    private double qty;
    private double unitPrice;
    private String oid;
    private String itemCode;
    private OrderDetail_PK od_pk;
    public CustomerOrderDetails(String oid, double qty, double unitPrice, String itemCode) {
        this.qty = qty;
        this.unitPrice = unitPrice;
        this.oid = oid;
        this.itemCode = itemCode;
        this.od_pk=new OrderDetail_PK(oid, itemCode);
    }

//    public String getOdid() {
//        return odid;
//    }

    public double getQty() {
        return qty;
    }

    public OrderDetail_PK getOd_pk() {
        return od_pk;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public String getOid() {
        return oid;
    }

    public String getItemCode() {
        return itemCode;
    }

}

