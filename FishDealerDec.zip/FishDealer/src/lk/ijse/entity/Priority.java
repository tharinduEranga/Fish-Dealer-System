package lk.ijse.entity;

public class Priority implements SuperEntity{
   private String pid;
   private String type;

    public Priority(String pid, String type) {
        this.pid = pid;
        this.type = type;
    }

    public String getPid() {
        return pid;
    }

    public String getType() {
        return type;
    }
}
