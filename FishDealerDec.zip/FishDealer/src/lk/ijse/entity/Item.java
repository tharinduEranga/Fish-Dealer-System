package lk.ijse.entity;

public class Item implements SuperEntity {
    private String iid;
    private String name;

    public Item(String iid, String name) {
        this.iid = iid;
        this.name = name;
    }

    public String getIid() {
        return iid;
    }

    public String getName() {
        return name;
    }


}
