package lk.ijse.entity;

public class Market implements SuperEntity {
    private String mid;
    private String mname;
    private String address;
    public Market(String mid, String mname) {

        this.mid = mid;
        this.mname = mname;
    }

    public Market(String mid, String mname, String address) {
        this.mid = mid;
        this.mname = mname;
        this.address = address;
    }

    public String getAddress() {
        return address;
    }

    public String getMid() {
        return mid;
    }

    public String getMname() {
        return mname;
    }
}
