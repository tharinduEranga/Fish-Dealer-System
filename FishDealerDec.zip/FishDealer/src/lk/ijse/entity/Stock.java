package lk.ijse.entity;

import java.sql.Date;

public class Stock implements SuperEntity {
    private String stid;
    private String iid;
    private double qty;
    private Date data;
    private String sid;
    private double cost;

    public Stock(String stid, String iid, double qty, Date data, String sid, double cost) {
        this.stid = stid;
        this.iid = iid;
        this.qty = qty;
        this.data = data;
        this.sid = sid;
        this.cost = cost;
    }

    public String getStid() {
        return stid;
    }

    public String getIid() {
        return iid;
    }

    public double getQty() {
        return qty;
    }

    public Date getData() {
        return data;
    }

    public String getSid() {
        return sid;
    }

    public double getCost() {
        return cost;
    }

    public void setStid(String stid) {
        this.stid = stid;
    }

    public void setIid(String iid) {
        this.iid = iid;
    }

    public void setQty(double qty) {
        this.qty = qty;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }
}
