package lk.ijse.entity;

import java.sql.Date;

public class CustomEntity implements SuperEntity {
    private  String cusId;
    private  String custName;
   private String custAddress;
   private int custTel;
   private Date custRegDate;
    private  String custOid;
   private Date custOrderDate;
   private String priority;
   private String itemId;
    private String itemName;
   private double itemQty;
   private double price;
   private String supplierId;
   private String supplierName;
   private String marketName;
   private int supplierTel;
   private Date stockDate;
   private Date orderDate;
   private String pid;

    public CustomEntity(String custName, Date custOrderDate, double price, String pid) {
        this.custName = custName;
        this.custOrderDate = custOrderDate;
        this.price = price;
        this.pid = pid;
    }

    public CustomEntity(String itemName, double itemQty) {
        this.itemName = itemName;
        this.itemQty = itemQty;
    }

    public CustomEntity(String itemName, double itemQty, double price) {
        this.itemName = itemName;
        this.itemQty = itemQty;
        this.price = price;
    }

    public CustomEntity(String custName, Date custOrderDate, double price) {
        this.custName = custName;
        this.custOrderDate = custOrderDate;
        this.price = price;
    }

    public CustomEntity(String supplierName, String marketName, int supplierTel) {
        this.supplierName = supplierName;
        this.marketName = marketName;
        this.supplierTel = supplierTel;
    }


    public CustomEntity(String itemId, String itemname, double qty) {
        this.itemId=itemId;
        this.custName=itemId;
        this.itemName=itemname;
        this.itemQty=qty;
        this.price=qty;
    }

    public CustomEntity(String iid, String itemName, double itemQty, double price, String supplierName, Date stockDate) {
        this.itemId=iid;
        this.itemName = itemName;
        this.itemQty = itemQty;
        this.price = price;
        this.supplierName = supplierName;
        this.stockDate = stockDate;
    }

    public CustomEntity(String custName, String itemName, double itemQty, double price) {
        this.custName = custName;
        this.itemName = itemName;
        this.itemQty = itemQty;
        this.price = price;
    }

    public String getPid() {
        return pid;
    }

    public CustomEntity(String custOid, String custName, String priority, double price, Date orderDate) {
        this.custOid=custOid;
        this.custName = custName;
        this.priority = priority;
        this.price = price;
        this.orderDate = orderDate;
    }

    public Date getStockDate() {
        return stockDate;
    }

    public String getCusId() {
        return cusId;
    }

    public String getCustName() {
        return custName;
    }

    public String getCustAddress() {
        return custAddress;
    }

    public int getCustTel() {
        return custTel;
    }

    public Date getCustRegDate() {
        return custRegDate;
    }

    public String getCustOid() {
        return custOid;
    }

    public Date getCustOrderDate() {
        return custOrderDate;
    }

    public String getPriority() {
        return priority;
    }

    public String getItemId() {
        return itemId;
    }

    public String getItemName() {
        return itemName;
    }

    public double getItemQty() {
        return itemQty;
    }

    public double getPrice() {
        return price;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public String getSupplierId() {
        return supplierId;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public String getMarketName() {
        return marketName;
    }

    public int getSupplierTel() {
        return supplierTel;
    }

}
