package lk.ijse.entity;

public interface SuperEntity {

}
