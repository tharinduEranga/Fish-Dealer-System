package lk.ijse.entity;

import java.sql.Date;

public class CustomerOrder implements SuperEntity {
    private String oid;
    private Date date;
    private String cid;
    private String priority;
    private double price;
    public CustomerOrder(String oid, Date date, String cid, String priority, double price) {
        this.oid = oid;
        this.date = date;
        this.cid = cid;
        this.priority = priority;
        this.price=price;
    }

    public String getOid() {
        return oid;
    }

    public Date getDate() {
        return date;
    }

    public String getCid() {
        return cid;
    }

    public String getPriority() {
        return priority;
    }

    public double getPrice() {
        return price;
    }
}
