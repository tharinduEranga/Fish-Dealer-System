package lk.ijse.entity;

public class DueStock implements SuperEntity {
    private String iid;
   private double qty;
    public DueStock(String iid, double qty) {
        this.iid = iid;
        this.qty=qty;
    }

    public String getIid() {
        return iid;
    }

    public double getQty() {
        return qty;
    }
}
