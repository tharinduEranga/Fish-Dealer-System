package lk.ijse.entity;

public class Quotations implements SuperEntity {
    private String qid;
    private  double price;
    private String cid;
    private  String iid;

    public Quotations(String qid, double price, String cid, String iid) {
        this.qid = qid;
        this.price = price;
        this.cid = cid;
        this.iid = iid;
    }

    public String getQid() {
        return qid;
    }

    public double getPrice() {
        return price;
    }

    public String getCid() {
        return cid;
    }

    public String getIid() {
        return iid;
    }
}
