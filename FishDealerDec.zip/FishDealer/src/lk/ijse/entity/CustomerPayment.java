package lk.ijse.entity;

import java.sql.Date;

public class CustomerPayment implements SuperEntity {
    private String pid;
    private String oid;
    private Date date;
    private double amount;


    public CustomerPayment(String pid, String oid, Date date, double amount) {
        this.pid = pid;
        this.oid = oid;
        this.date = date;
        this.amount = amount;
    }

    public String getPid() {
        return pid;
    }

    public String getOid() {
        return oid;
    }

    public Date getDate() {
        return date;
    }

    public double getAmount() {
        return amount;
    }

}
