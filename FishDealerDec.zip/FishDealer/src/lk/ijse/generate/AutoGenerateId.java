package lk.ijse.generate;

import lk.ijse.business.custom.*;
import lk.ijse.business.main.BOFactory;
import lk.ijse.dao.main.CrudUtility;
import lk.ijse.dbconnection.DBConnection;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AutoGenerateId {
//    CustomerBO customerBO;
//    ItemBO itemBO;
//    SupplierBO supplierBO;
//    StockBO stockBO;
//    CustomerOrderBO customerOrderBO;
//    CustomerOrderDetailsBO customerOrderDetailsBO;
//    MarketBO marketBO;
//    CustomerPaymentBO customerPaymentBO;
//    QuotationsBO quotationsBO;
    Connection conn;
    public AutoGenerateId() {
        try {
            conn=DBConnection.getInstance().getConnection();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
//        customerBO= BOFactory.getInstance().getBO(BOFactory.BOTypes.CUSTOMER);
//        itemBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.ITEM);
//        supplierBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.SUPPLIER);
//        stockBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.STOCK);
//        customerOrderBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.ORDER);
//        customerOrderDetailsBO= BOFactory.getInstance().getBO(BOFactory.BOTypes.ORDERDETAIL);
//        marketBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.MARKET);
//        customerPaymentBO= BOFactory.getInstance().getBO(BOFactory.BOTypes.PAYMENT);
//        quotationsBO =BOFactory.getInstance().getBO(BOFactory.BOTypes.QUOTATION);
    }
//    String generateId(String id){
//        char ch=id.charAt(id.length()-1);
//        char ch1=id.charAt(id.length()-2);
//        char ch2=id.charAt(id.length()-3);
//
//        int a=Character.getNumericValue(ch);
//        int a1=Character.getNumericValue(ch1);
//        int a2=Character.getNumericValue(ch2);
//        if(a1==9&&a==9){
//            id = id.substring(0, id.length() - 3);
//            a2++;
//            a1=0;
//            a=0;
//            id=id+a2+a1+a;
//        }
//        else if(a==9){
//            id = id.substring(0, id.length() - 2);
//            a1++;
//            a=0;
//            id=id+a1+a;
//        }else{
//            id = id.substring(0, id.length() - 1);
//            a++;
//            id=id+a;
//        }
//        return id;
//    }
    public String generateId(String table, String id){
        try {
            ResultSet rst = CrudUtility.executeQuery("SELECT  " + id + "  FROM  " + table + "  ORDER BY  " + id + "  DESC LIMIT 1");
            if (rst.next()) {
                id = rst.getString(1);
                char ch = id.charAt(id.length() - 1);
                char ch1 = id.charAt(id.length() - 2);
                char ch2 = id.charAt(id.length() - 3);

                int a = Character.getNumericValue(ch);
                int a1 = Character.getNumericValue(ch1);
                int a2 = Character.getNumericValue(ch2);
                if (a1 == 9 && a == 9) {
                    id = id.substring(0, id.length() - 3);
                    a2++;
                    a1 = 0;
                    a = 0;
                    id = id + a2 + a1 + a;
                } else if (a == 9) {
                    id = id.substring(0, id.length() - 2);
                    a1++;
                    a = 0;
                    id = id + a1 + a;
                } else {
                    id = id.substring(0, id.length() - 1);
                    a++;
                    id = id + a;
                }
            } else
                id=null;
        }catch (Exception e){
            e.printStackTrace();
        }
        return id;
    }



}
