package lk.ijse.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.business.custom.CustomerBO;
import lk.ijse.business.custom.ItemBO;
import lk.ijse.business.custom.QueryBO;
import lk.ijse.business.custom.QuotationsBO;
import lk.ijse.business.main.BOFactory;
import lk.ijse.dbconnection.DBConnection;
import lk.ijse.dto.CustomerDTO;
import lk.ijse.dto.ItemDTO;
import lk.ijse.dto.QuotationsTableDTO;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.swing.JRViewer;

import javax.management.Query;
import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class QuotationController implements Initializable {
    @FXML
    private JFXTextField fishText;
    @FXML
    private ImageView exitButton;
    @FXML
    private TableView<QuotationsTableDTO> quotationsTable;

    @FXML
    private JFXTextField searchText;
    @FXML
    private JFXButton reportQutationButton;

    @FXML
    private Button searchButton;
    ObservableList<QuotationsTableDTO>quotations= FXCollections.observableArrayList();
    QuotationsBO quotationsBO;
    CustomerBO customerBO;
    QueryBO queryBO;
    ItemBO itemBO;
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        quotationsBO= BOFactory.getInstance().getBO(BOFactory.BOTypes.QUOTATION);
        this.customerBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.CUSTOMER);
        this.queryBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.QUERY);
        this.itemBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.ITEM);
        loadQuotations();
        quotationsTable.setEditable(true);
    }

    @FXML
    void getReport(ActionEvent event) {
        int i=quotationsTable.getSelectionModel().getSelectedIndex();
        if(i>=0) {
            try {
                CustomerDTO c=customerBO.searchCustomer(quotations.get(i).getCustomer());
                Connection conn = DBConnection.getInstance().getConnection();
                PreparedStatement stm = null;
                ResultSet rst = null;

                JasperDesign jd = JRXmlLoader.load("C:\\Users\\Tharindu\\JaspersoftWorkspace\\MyReports\\Quotation.jrxml");
                String SQL = "select c.name, i.itemname, q.price\n" +
                        "     from customer c, item i, quotations q\n" +
                        "     where c.cid=q.cid and i.iid=q.iid and q.cid='" + c.getCid() + "'";
                JRDesignQuery jrDesignQuery = new JRDesignQuery();
                jrDesignQuery.setText(SQL);
                jd.setQuery(jrDesignQuery);

                JasperReport jr = JasperCompileManager.compileReport(jd);
                JasperPrint jp = JasperFillManager.fillReport(jr, null, conn);
                if (!jp.getPages().toString().equals("[]")) {
                    JRViewer jv = new JRViewer(jp);
                    jv.setVisible(true);
                    jv.setOpaque(true);
                    JFrame f1 = new JFrame();
                    f1.setSize(1079, 899);
                    f1.setLocationRelativeTo(null);
                    f1.add(jv);
                    f1.setVisible(true);
                } else {
                    Alert a = new Alert(Alert.AlertType.INFORMATION);
                    a.setContentText("Nothing For Selected Customer");
                    a.show();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void loadQuotations() {
        try {
            quotations.removeAll(quotations);
            quotations=queryBO.getAllQuotations();
            quotationsTable.getColumns().get(0).setStyle("-fx-alignment: CENTER_LEFT;");
            quotationsTable.getColumns().get(1).setStyle("-fx-alignment: CENTER_LEFT;");
            quotationsTable.getColumns().get(2).setStyle("-fx-alignment: CENTER;");
            quotationsTable.getColumns().get(0).setCellValueFactory(new PropertyValueFactory<>("customer"));
            quotationsTable.getColumns().get(1).setCellValueFactory(new PropertyValueFactory<>("fish"));
            quotationsTable.getColumns().get(2).setCellValueFactory(new PropertyValueFactory<>("price"));
            quotationsTable.setItems(quotations);
            quotationsTable.refresh();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void searchQuotations() {
        quotations.removeAll(quotations);
        try {
            CustomerDTO c=customerBO.searchCustomer(searchText.getText());
            ItemDTO i=itemBO.searchAnItem(fishText.getText());
            if (!searchText.getText().equals("") && !fishText.getText().equals("")) {
                if(c!=null&&i!=null) {
                    quotations = queryBO.searchQuotations(c.getCid(), "");
                    quotationsTable.setItems(quotations);
                }
            } else if (searchText.getText().equals("") && !fishText.getText().equals("")) {
                if(i!=null) {
                    quotations = queryBO.searchQuotations(c.getCid(), "");
                    quotationsTable.setItems(quotations);
                }
            } else if (!searchText.getText().equals("") && fishText.getText().equals("")) {
                if(c!=null) {
                    quotations = queryBO.searchQuotations(c.getCid(), "");
                    quotationsTable.setItems(quotations);
                }
            } else {
                loadQuotations();
                quotationsTable.refresh();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @FXML
    void searchByKey(KeyEvent event) {
        searchQuotations();
    }

    @FXML
    public void makeQuotation(ActionEvent actionEvent) {
        AnchorPane ap = null;
        try {
            ap = FXMLLoader.load(getClass().getResource("../View/MakeQuotation.fxml"));
            Stage stage=new Stage();
            stage.setScene(new Scene(ap));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void searchFish(ActionEvent actionEvent) {

    }

    public void getValue(MouseEvent mouseEvent) {
//        QuotationsTableDTO v=quotationsTable.getSelectionModel().getSelectedItem();
//        System.out.println(v.getCustomer());

    }
    @FXML
    void exit(MouseEvent event) {
        System.exit(0);
    }
}
