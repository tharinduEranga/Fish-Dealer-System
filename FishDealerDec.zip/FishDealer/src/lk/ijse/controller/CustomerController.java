package lk.ijse.controller;

import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.business.custom.CustomerBO;
import lk.ijse.business.custom.CustomerOrderBO;
import lk.ijse.business.custom.ItemBO;
import lk.ijse.business.main.BOFactory;
import lk.ijse.dbconnection.DBConnection;
import lk.ijse.dto.CustomerDTO;
import lk.ijse.dto.CustomerTableDTO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.util.StringConverter;
import lk.ijse.dto.ItemDTO;
import lk.ijse.generate.AutoGenerateId;

import java.net.URL;
import java.sql.Connection;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CustomerController implements Initializable{

    @FXML
    private AnchorPane anchor;

    @FXML
    private Button deleteButton;

    @FXML
    private Button searchButton;

    @FXML
    private Button saveButton;

    @FXML
    private Label statusLabel;

    @FXML
    private Button clearButton;

    @FXML
    private Button reloadButton;

    @FXML
    private JFXDatePicker datePicker;

    @FXML
    private JFXTextField nameSearchText;

    @FXML
    private JFXTextField nameText;

    @FXML
    private JFXTextField addressText;

    @FXML
    private JFXTextField telText;

    @FXML
    private TableView<CustomerTableDTO> customerTable;

    ObservableList<CustomerDTO>customers=FXCollections.observableArrayList();
    ObservableList<CustomerTableDTO>customerTableList=FXCollections.observableArrayList();
    ObservableList<CustomerDTO>cs=FXCollections.observableArrayList();
    ObservableList<CustomerTableDTO>custs=FXCollections.observableArrayList();

    String oid;
    boolean isClick=false;
    private CustomerBO customerBO;
    private ItemBO itemBO;
    private CustomerOrderBO orderBO;
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        this.customerBO = BOFactory.getInstance().getBO(BOFactory.BOTypes.CUSTOMER);
        this.itemBO = BOFactory.getInstance().getBO(BOFactory.BOTypes.ITEM);
        this.orderBO = BOFactory.getInstance().getBO(BOFactory.BOTypes.ORDER);
        loadNextCustomerId();
        dateFormatter();
        loadCustomers();
    }

    private void dateFormatter() {
        String pattern="yyyy-MM-dd";
        datePicker.setPromptText(pattern.toLowerCase());
        datePicker.setConverter(new StringConverter<LocalDate>() {
            DateTimeFormatter dateFormatter=DateTimeFormatter.ofPattern(pattern);
            @Override
            public String toString(LocalDate date) {
                if(date!=null){
                    return dateFormatter.format(date);
                }else {
                    return "";
                }
            }
            @Override
            public LocalDate fromString(String string) {
                if(string!=null && !string.isEmpty()){
                    return LocalDate.parse(string,dateFormatter);
                }else {
                    return null;
                }
            }
        });
    }

    @FXML
    private void loadCustomers() {
        try {
            customers.removeAll(customers);
            customers=customerBO.getAllCustomers();
            for (CustomerDTO c: customers) {
                if(customerTableList.size()<customers.size())
                customerTableList.add(new CustomerTableDTO(c.getName(),c.getAddress(),c.getTel(),c.getDate()));
            }
            customerTable.getColumns().get(0).setStyle("-fx-alignment: CENTER_LEFT;");
            customerTable.getColumns().get(1).setStyle("-fx-alignment: CENTER_LEFT;");
            customerTable.getColumns().get(2).setStyle("-fx-alignment: CENTER;");
            customerTable.getColumns().get(3).setStyle("-fx-alignment: CENTER;");
            customerTable.getColumns().get(0).setCellValueFactory(new PropertyValueFactory<>("name"));
            customerTable.getColumns().get(1).setCellValueFactory(new PropertyValueFactory<>("address"));
            customerTable.getColumns().get(2).setCellValueFactory(new PropertyValueFactory<>("tel"));
            customerTable.getColumns().get(3).setCellValueFactory(new PropertyValueFactory<>("regDate"));
            customerTable.setItems(customerTableList);
            customerTable.refresh();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private void loadNextCustomerId() {
        oid=new AutoGenerateId().generateId("Customer","CID");
    }

    public void saveCustomer(ActionEvent actionEvent) {
           try {
            if(!isClick) {
                if(telText.getText().matches("[0-9\\s]+")&&!nameText.getText().equals("")&&!addressText.getText().equals("")&&telText.getText().length()==10) {
                    CustomerDTO cdto = new CustomerDTO(oid, nameText.getText(), addressText.getText(), Integer.parseInt(telText.getText()), java.sql.Date.valueOf(LocalDate.now()));
                    boolean b = customerBO.addCustomer(cdto);
                    if (b) {
                        statusLabel.setText("Added");
                        customerTableList.removeAll(customerTableList);
                        loadCustomers();
                        customerTable.refresh();
                        loadNextCustomerId();
                        Alert a = new Alert(Alert.AlertType.INFORMATION.CONFIRMATION);
                        a.setTitle("Add Quotation");
                        a.setContentText("Want to Make Quotaion?");
                        Optional<ButtonType> result = a.showAndWait();
                        if (result.get() == ButtonType.OK) {
                            FXMLLoader loader=new FXMLLoader();
                            loader.setLocation(getClass().getResource("../View/MakeQuotation.fxml"));
                            loader.load();
                            MakeQuotationController mq=loader.getController();
                            mq.setComboValues(cdto);
                            Parent p=loader.getRoot();
                            Stage stage = new Stage();
                            stage.setScene(new Scene(p));
                            stage.show();
                        } else {
                            a.close();
                        }
                    } else
                        statusLabel.setText("Failed to Add");
                }else {
                    statusLabel.setText("Wrong Input");
                }
            }else{
                if(telText.getText().matches("[0-9\\s]+")&&telText.getText().length()==10) {
                    CustomerDTO cust = customerBO.searchCustomer(nameText.getText());
                    CustomerDTO c = new CustomerDTO(cust.getCid(), nameText.getText(), addressText.getText(), Integer.parseInt(telText.getText()), cust.getDate());
                    boolean b = customerBO.updateCustomer(c);
                    if (b) {
                        statusLabel.setText("Updated");
                        customerTableList.removeAll(customerTableList);
                        loadCustomers();
                        customerTable.refresh();
                    } else
                        statusLabel.setText("Failed to Update");
                }else {
                    statusLabel.setText("Wrong Input");
                }
            }
        }  catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void anchorButtonPress(KeyEvent keyEvent) {
        settText();
    }

    private void settText() {
        statusLabel.setText("");
    }

    public void anchorClick(MouseEvent mouseEvent) {
        settText();
    }

    public void tableMouseEnter(MouseEvent mouseEvent) {
        settText();
    }

    public void tableMouseClick(MouseEvent mouseEvent) {
        isClick=true;
        int i=customerTable.getSelectionModel().getSelectedIndex();
        if(customerTableList.size()>0&&i>=0) {
            nameText.setText(customerTableList.get(i).getName());
            addressText.setText(customerTableList.get(i).getAddress());
            telText.setText("0"+customerTableList.get(i).getTel());
        }else{
            nameText.setText(custs.get(i).getName());
            addressText.setText(custs.get(i).getAddress());
            telText.setText("0"+custs.get(i).getTel());
        }
    }

    public void searchCustomer() {
        if(nameSearchText.getText().matches("[']")) {

        }else {
            try {
                if (datePicker.getValue() != null) {
                    cs = customerBO.searchCustomers(nameSearchText.getText(), datePicker.getValue().toString());
                    customerTableList.removeAll(customerTableList);
                    custs.removeAll(custs);
                    for (CustomerDTO c : cs) {
                        custs.add(new CustomerTableDTO(c.getName(), c.getAddress(), c.getTel(), c.getDate()));
                        customerTable.setItems(custs);
                        customerTable.refresh();
                    }
                } else if ((nameSearchText.getText().equals("") || nameSearchText.getText() == null) && datePicker.getValue() == null) {
                    customerTable.refresh();
                } else {
                    cs = customerBO.searchCustomers(nameSearchText.getText(), "");
                    customerTableList.removeAll(customerTableList);
                    custs.removeAll(custs);
                    for (CustomerDTO c : cs) {
                        custs.add(new CustomerTableDTO(c.getName(), c.getAddress(), c.getTel(), c.getDate()));
                        customerTable.setItems(custs);
                        customerTable.refresh();
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    public void clearText(ActionEvent actionEvent) {
        nameText.setText("");
        addressText.setText("");
        telText.setText("");
        isClick=false;
    }

    public void searchByKey(KeyEvent keyEvent) {
        try {
            if(!nameSearchText.getText().isEmpty()) {
                searchCustomer();
            }else{
                loadCustomers();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteCustomer(ActionEvent actionEvent) {
        try {
            CustomerDTO c=customerBO.searchCustomer(nameText.getText());
            boolean b=customerBO.deleteCustomer(c.getCid());
            if(b){
                statusLabel.setText("Deleted");
                customerTableList.removeAll(customerTableList);
                loadCustomers();
                customerTable.refresh();
            }else {
                statusLabel.setText("Failed");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @FXML
    void exit(MouseEvent event) {
        System.exit(0);
    }

    @FXML
    void gotoAddress(ActionEvent event) {
        addressText.requestFocus();
    }

    @FXML
    void gotoTel(ActionEvent event) {
        telText.requestFocus();
    }
}
