package lk.ijse.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Tab;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.business.custom.DueStockBO;
import lk.ijse.business.custom.ItemBO;
import lk.ijse.business.custom.QueryBO;
import lk.ijse.business.main.BOFactory;
import lk.ijse.dao.custom.QueryDAO;
import lk.ijse.dto.DueStockTableDTO;
import lk.ijse.dto.ItemDTO;

import javax.swing.text.TableView;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class DueStockController implements Initializable {
    @FXML
    private ImageView exitButton;
    @FXML
    private JFXButton addStockDue;

    @FXML
    private JFXTextField updateText;
    @FXML
    private javafx.scene.control.TableView<DueStockTableDTO> dueStockTable;
    ItemDTO item;
    ObservableList<DueStockTableDTO>dueStocks= FXCollections.observableArrayList();
    DueStockBO dueStockBO;
    QueryBO queryBO;
    ItemBO itemBO;
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        this.dueStockBO= BOFactory.getInstance().getBO(BOFactory.BOTypes.DUESTOCK);
        this.queryBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.QUERY);
        this.itemBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.ITEM);
        loaDueStocks();
    }

    private void loaDueStocks() {
        try {
            dueStocks=queryBO.getAllDueStocks();
            dueStockTable.getColumns().get(0).setStyle("-fx-alignment: CENTER_LEFT;");
            dueStockTable.getColumns().get(1).setStyle("-fx-alignment: CENTER");

            dueStockTable.getColumns().get(0).setCellValueFactory(new PropertyValueFactory<>("itemName"));
            dueStockTable.getColumns().get(1).setCellValueFactory(new PropertyValueFactory<>("qty"));
            dueStockTable.setItems(dueStocks);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void addStockDue(ActionEvent actionEvent) throws IOException {
        AnchorPane ap = FXMLLoader.load(getClass().getResource("../View/StockPage.fxml"));
        Stage stage=new Stage();
        stage.setScene(new Scene(ap));
        stage.show();
    }
    @FXML
    void updateQty(ActionEvent event) {

        if(dueStockTable.getSelectionModel().getSelectedIndex()>=0) {
            String qty = updateText.getText();
            try {
                item = itemBO.searchAnItem(dueStocks.get(dueStockTable.getSelectionModel().getSelectedIndex()).getItemName());
                boolean b = dueStockBO.updateQty(item.getIid(), Double.parseDouble(qty));
                if (b) {
                    dueStocks.removeAll(dueStocks);
                    loaDueStocks();
                    dueStockTable.refresh();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    @FXML
    void exit(MouseEvent event) {
        System.exit(0);
    }
}
