package lk.ijse.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import javafx.event.EventHandler;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import lk.ijse.business.custom.ItemBO;
import lk.ijse.business.custom.MarketBO;
import lk.ijse.business.custom.QueryBO;
import lk.ijse.business.custom.SupplierBO;
import lk.ijse.business.main.BOFactory;
import lk.ijse.dao.custom.MarketDAO;
import lk.ijse.dto.MarketDTO;
import lk.ijse.dto.SupplierDTO;
import lk.ijse.dto.SupplierTableDTO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.entity.Market;
import lk.ijse.generate.AutoGenerateId;
import lk.ijse.generate.ComboBoxAutoComplete;

import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLTransactionRollbackException;
import java.util.ResourceBundle;

public class SupplierController implements Initializable {
    @FXML
    private ImageView exitButton;
    @FXML
    JFXTextField nameText;
    @FXML
    ComboBox<String> marketCombo;
    @FXML
    JFXTextField telText;
    @FXML
    JFXTextField nameSearchText;
    @FXML
    JFXComboBox marketSearchCombo;
    @FXML
    JFXButton searchButton;
    @FXML
    JFXButton saveButton;
    @FXML
    JFXButton deleteButton;
    @FXML
    private ImageView successImage;
    @FXML
    private ImageView failedImage;
    @FXML
    private JFXButton clearButton;
    @FXML
    private Label validateLabel;

    @FXML
    TableView<SupplierTableDTO>suppliersTable;
    ObservableList<MarketDTO>markets= FXCollections.observableArrayList();
    ObservableList<SupplierTableDTO>suppliers= FXCollections.observableArrayList();
    private SupplierBO supplierBO;
    private QueryBO queryBO;
    private ItemBO itemBO;
    private MarketBO marketBO;
    ObservableList<SupplierTableDTO>suppliersSearches= FXCollections.observableArrayList();
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        supplierBO= BOFactory.getInstance().getBO(BOFactory.BOTypes.SUPPLIER);
        marketBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.MARKET);
        queryBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.QUERY);
        loadMarkets();
        loadSuppliers();
        autoComplete();
        successImage.setVisible(false);
        failedImage.setVisible(false);
        validateLabel.setVisible(false);
    }

    private void autoComplete() {
        new ComboBoxAutoComplete<String>(marketCombo);
        new ComboBoxAutoComplete<String>(marketSearchCombo);
    }
    @FXML
    void clearTexts(ActionEvent event) {
        nameText.setText("");
        telText.setText("");
        marketCombo.setValue(null);
        validateLabel.setVisible(false);
    }
    private void loadMarkets() {
        try {
            markets=marketBO.getMarkets();
            ObservableList<String>marketNames=FXCollections.observableArrayList();
            for (int i=0; i<markets.size(); i++) {
                marketNames.add(markets.get(i).getMname());
            }
            marketCombo.setItems(marketNames);
            marketSearchCombo.setItems(marketNames);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadSuppliers() {
        try {
            suppliers=queryBO.getSuppliersForTable();
            suppliersTable.getColumns().get(0).setStyle("-fx-alignment: CENTER_LEFT;");
            suppliersTable.getColumns().get(1).setStyle("-fx-alignment: CENTER;");
            suppliersTable.getColumns().get(2).setStyle("-fx-alignment: CENTER;");
            suppliersTable.getColumns().get(0).setCellValueFactory(new PropertyValueFactory<>("name"));
            suppliersTable.getColumns().get(1).setCellValueFactory(new PropertyValueFactory<>("market"));
            suppliersTable.getColumns().get(2).setCellValueFactory(new PropertyValueFactory<>("tel"));
            suppliersTable.setItems(suppliers);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    AnchorPane ap;
    Stage stage;
    public void addMarket(ActionEvent actionEvent) throws IOException {
        ap = FXMLLoader.load(getClass().getResource("../View/AddMarket.fxml"));
        stage=new Stage();
        stage.setScene(new Scene(ap));
        stage.show();
        successImage.setVisible(false);
        failedImage.setVisible(false);
    }

    public void saveDetails(ActionEvent actionEvent) {
        try {
            MarketDTO m=marketBO.searchMarket(marketCombo.getValue().toString());
            String sid=new AutoGenerateId().generateId("Supplier","SID");
            String regex="[A-Za-z\\s]+";
            String tel="[0-9\\s]+";
            saveButton.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    if(nameText.getText().matches(regex)&&telText.getText().matches(tel)&&!marketCombo.getValue().isEmpty()&&telText.getText().length()==10) {
                        validateLabel.setVisible(false);
                        String sname=nameText.getText();
                        String mid=m.getMid();
                        int tel=Integer.parseInt(telText.getText());
                        boolean b= false;
                        try {
                            b = supplierBO.addSupplier(new SupplierDTO(sid, sname, mid, tel));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        if(b){
                            successImage.setVisible(true);
                            suppliers.removeAll(suppliers);
                            loadSuppliers();
                            suppliersTable.refresh();
                        }else{
                            failedImage.setVisible(true);
                        }
                    }else {
                        validateLabel.setVisible(true);
                    }
                }
            });
        } catch (Exception e) {
            Alert a=new Alert(Alert.AlertType.INFORMATION);
            a.setContentText(e.getCause().toString());
            a.show();
        }
    }
    @FXML
    void validate(KeyEvent evt){

    }

    public void searchSupplier(ActionEvent actionEvent) {
        try {
            String m=marketSearchCombo.getValue().toString();
            suppliersSearches=queryBO.searchSuppliers(nameSearchText.getText(),m);
            suppliers.removeAll(suppliers);
            suppliersTable.setItems(suppliersSearches);
            suppliersTable.refresh();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void loadDetails(MouseEvent mouseEvent) {
        int i=suppliersTable.getSelectionModel().getFocusedIndex();
        if(suppliers.size()>0) {
            nameText.setText(suppliers.get(i).getName());
            telText.setText(suppliers.get(i).getTel() + "");
        }else {
            nameText.setText(suppliersSearches.get(i).getName());
            telText.setText(suppliersSearches.get(i).getTel() + "");
        }
        successImage.setVisible(false);
        failedImage.setVisible(false);
        validateLabel.setVisible(false);
    }

    public void reloadTable(ActionEvent actionEvent) {
        suppliersSearches.removeAll(suppliersSearches);
        loadSuppliers();
        suppliersTable.refresh();
        successImage.setVisible(false);
        failedImage.setVisible(false);
    }

    public void deleteSupplier(ActionEvent actionEvent) {

    }

    public void searchSupplierName() {
        try {
            suppliersSearches=queryBO.searchSuppliers(nameSearchText.getText(),"");
            suppliers.removeAll(suppliers);
            suppliersTable.setItems(suppliersSearches);
            suppliersTable.refresh();
        } catch (Exception e) {
            e.printStackTrace();
        }
        successImage.setVisible(false);
        failedImage.setVisible(false);
    }

    public void viewStock(ActionEvent actionEvent) {
        successImage.setVisible(false);
        failedImage.setVisible(false);
    }

    public void searchByKey(){
        if(!nameSearchText.getText().isEmpty()) {
            searchSupplierName();
        }else if(nameSearchText.getText().isEmpty()){
            loadSuppliers();
        }
    }

}
