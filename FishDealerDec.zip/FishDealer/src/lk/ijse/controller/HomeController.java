package lk.ijse.controller;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import lk.ijse.business.custom.CustomerOrderBO;
import lk.ijse.business.custom.CustomerOrderDetailsBO;
import lk.ijse.business.custom.CustomerPaymentBO;
import lk.ijse.business.custom.StockBO;
import lk.ijse.business.main.BOFactory;
import net.sf.jasperreports.engine.util.BookmarksFlatDataSource;
import org.omg.PortableServer.THREAD_POLICY_ID;

import java.net.URL;
import java.util.ResourceBundle;

public class HomeController implements Initializable {

    @FXML
    private AnchorPane homePane;

    @FXML
    private Label totalLabel;

    @FXML
    private Label totalOrdersLabel;

    @FXML
    private Label totalGrossLabel;

    @FXML
    private Label totalKGlabel;

    @FXML
    private Label congratsLabel;

    @FXML
    private ImageView image;

    CustomerOrderBO customerOrderBO;
    CustomerPaymentBO customerPaymentBO;
    CustomerOrderDetailsBO customerOrderDetailsBO;
    StockBO stockBO;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        this.customerOrderBO= BOFactory.getInstance().getBO(BOFactory.BOTypes.ORDER);
        this.customerOrderDetailsBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.ORDERDETAIL);
        this.customerPaymentBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.PAYMENT);
        this.stockBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.STOCK);
        initLabels();
    }

    private void initLabels() {
        try {
            int orderCount=customerOrderBO.getOrderCount();
            double totalPayments=customerPaymentBO.getPaymentTotal();
            double totalKg=customerOrderDetailsBO.getTotalSoldKg();
            totalOrdersLabel.setText(orderCount+" Orders Have Made");
            totalGrossLabel.setText(+totalPayments+" /= Gross Has Made");
            totalKGlabel.setText(+totalKg+" KG Fish Sold");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
