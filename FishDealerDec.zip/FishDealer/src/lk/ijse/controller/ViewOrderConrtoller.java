package lk.ijse.controller;

import com.jfoenix.controls.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.StringConverter;
import lk.ijse.business.custom.*;
import lk.ijse.business.main.BOFactory;
import lk.ijse.dbconnection.DBConnection;
import lk.ijse.dto.*;
import lk.ijse.generate.AutoGenerateId;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.swing.JRViewer;

import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class  ViewOrderConrtoller implements Initializable {
    @FXML
    private JFXRadioButton placedRadio;

    @FXML
    private JFXRadioButton sheduledRadio;
    @FXML
    private TableView<OrderDTO> orderTable;
    @FXML
    private TableView<OrderDetailsTableDTO> orderDetailsTable;

    @FXML
    private JFXTextField qtyText;

    @FXML
    private JFXTextField newPriceText;

    @FXML
    private JFXButton updateButton;

    @FXML
    private JFXComboBox<String> fishCombo;

    @FXML
    private JFXTextField searchText;

    @FXML
    private JFXDatePicker datePicker;

    @FXML
    private JFXButton orderDetailButton;

    @FXML
    private JFXButton addButton;

    @FXML
    private JFXButton removeButton;

    @FXML
    private JFXButton payButton;
    boolean b;
    int i=-1;

    ObservableList<OrderDTO>orders= FXCollections.observableArrayList();
    ObservableList<OrderDetailsTableDTO>orderDetails= FXCollections.observableArrayList();
//    ObservableList<OrderDTO>placedOrders= FXCollections.observableArrayList();
//   ObservableList<OrderDTO>sheduledOrders= FXCollections.observableArrayList();
//    ObservableList<OrderDTO>orderSearches=FXCollections.observableArrayList();
    CustomerOrderBO customerOrderBO;
    CustomerOrderDetailsBO customerOrderDetailsBO;
    StockBO stockBO;
    CustomerBO customerBO;
    QueryBO queryBO;
    ItemBO itemBO;
    QuotationsBO quotationsBO;
    private CustomerPaymentBO customerPaymentBO;

    ItemDTO itemDTO;
    QuotationsDTO q;
    CustomerDTO c;
    OrderDTO o;
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        this.customerOrderBO= BOFactory.getInstance().getBO(BOFactory.BOTypes.ORDER);
        this.customerOrderDetailsBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.ORDERDETAIL);
        this.customerBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.CUSTOMER);
        this.queryBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.QUERY);
        this.customerPaymentBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.PAYMENT);
        this.stockBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.STOCK);
        this.itemBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.ITEM);
        this.quotationsBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.QUOTATION);
        loadOrders();
        dateFormatter();
        radioGroup();
        loadFish();
        payButton.setDisable(true);
        newPriceText.setVisible(false);
    }

    private void loadFish() {
        try {
            ObservableList<ItemDTO>fishes=itemBO.getAllItemNames();
            ObservableList<String>fisNames=FXCollections.observableArrayList();
            for (ItemDTO i:fishes) {
                fisNames.add(i.getName());
            }
            fishCombo.setItems(fisNames);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void radioGroup() {
        ToggleGroup g=new ToggleGroup();
        sheduledRadio.setToggleGroup(g);
        placedRadio.setToggleGroup(g);
    }

    private void loadOrders() {
        placedRadio.setSelected(false);
        sheduledRadio.setSelected(false);
        //orderSearches.removeAll(orderSearches);
        orders.removeAll(orders);
        //placedOrders.removeAll(placedOrders);
        //sheduledOrders.removeAll(sheduledOrders);
        try {
            orders=queryBO.getOrdersForTable();
            orderTable.getColumns().get(0).setStyle("-fx-alignment: CENTER_LEFT;");
            orderTable.getColumns().get(1).setStyle("-fx-alignment: CENTER;");
            orderTable.getColumns().get(2).setStyle("-fx-alignment: CENTER;");
            orderTable.getColumns().get(3).setStyle("-fx-alignment: CENTER;");
            orderTable.getColumns().get(0).setCellValueFactory(new PropertyValueFactory<>("custName"));
            orderTable.getColumns().get(1).setCellValueFactory(new PropertyValueFactory<>("date"));
            orderTable.getColumns().get(2).setCellValueFactory(new PropertyValueFactory<>("priority"));
            orderTable.getColumns().get(3).setCellValueFactory(new PropertyValueFactory<>("price"));
            orderTable.refresh();
            orderTable.setItems(orders);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void addOrder(ActionEvent actionEvent) throws IOException {
        AnchorPane ap = FXMLLoader.load(getClass().getResource("../View/OrderPage.fxml"));
        Stage stage=new Stage();
        stage.setScene(new Scene(ap));
        stage.show();
    }

    public void addPayment(ActionEvent actionEvent) throws IOException {
        String cpid=new AutoGenerateId().generateId("customerpayment","CPID");
        try {
            ObservableList<CustomerOrderDetailsDTO> cdtos = customerOrderDetailsBO.searchOrderDetail(orders.get(i).getOid());
            boolean isAdded=false;
            for (CustomerOrderDetailsDTO cd:cdtos){
                ArrayList<StockDTO> st = stockBO.getSelectedStocks(cd.getItemCode());
                double qty = cd.getQty();
                F1:
                for (StockDTO stock : st) {
                    if (qty > stock.getQty()) {
                        qty = qty - stock.getQty();
                        stock.setQty(0);
                    } else {
                        stock.setQty(stock.getQty() - qty);
                        qty = 0;
                    }
                    isAdded = stockBO.updateStock(stock);
                }
            }
            if(isAdded){
                    payButton.setDisable(false);
                    PaymentDTO p = new PaymentDTO(cpid, orders.get(i).getOid(), orders.get(i).getDate(), orders.get(i).getPrice());
                    isAdded = customerPaymentBO.addPayment(p);
                    if (isAdded) {
                        Connection conn= DBConnection.getInstance().getConnection();
                        PreparedStatement stm=null;
                        ResultSet rst=null;
                        JasperDesign jd= JRXmlLoader.load("C:\\Users\\Tharindu\\JaspersoftWorkspace\\MyReports\\Invoice.jrxml");
                        String SQL=" select c.name, c.address, c.tel, o.date, i.itemname, od.qty, od.pricePerItem, p.cpid, p.payment\n" +
                                "   from customer c, customerorder o, customerorderdetails od, item i, customerpayment p\n" +
                                "   where c.cid=o.cid and o.coid=od.coid and od.iid=i.iid and o.coid=p.coid and p.cpid='"+cpid+"'";
                        JRDesignQuery jrDesignQuery=new JRDesignQuery();
                        jrDesignQuery.setText(SQL);
                        jd.setQuery(jrDesignQuery);
                        JasperReport jr= JasperCompileManager.compileReport(jd);
                        JasperPrint jp= JasperFillManager.fillReport(jr,null,conn);
                        if(!jp.getPages().toString().equals("[]")) {
                            JRViewer jv=new JRViewer(jp);
                            jv.setVisible(true);
                            jv.setOpaque(true);
                            JFrame f1 = new JFrame();
                            f1.setSize(1080, 901);
                            f1.add(jv);
                            f1.setLocationRelativeTo(null);
                            f1.setVisible(true);
                        }else{
                            Alert a=new Alert(Alert.AlertType.INFORMATION);
                            a.setContentText("Order Added but Failed to print Bill");
                            a.show();
                        }
                        payButton.setDisable(true);
                    }else {
                        Alert a = new Alert(Alert.AlertType.INFORMATION);
                        a.setTitle("State");
                        a.setContentText("Failed to Make Payment");
                        a.show();
                    }
            }else {
                Alert a = new Alert(Alert.AlertType.INFORMATION);
                a.setTitle("State");
                a.setContentText("Failed to Issue Order");
                a.show();
            }
        }catch (Exception c){
            c.printStackTrace();
        }
    }

    public void viewDetails(ActionEvent actionEvent) throws IOException {
        AnchorPane ap = FXMLLoader.load(getClass().getResource("../View/OrderDetails.fxml"));
        Stage stage=new Stage();
        stage.setScene(new Scene(ap));
        stage.show();
    }

    @FXML
    void getIndex() {

    }

    @FXML
    void addQuotation(ActionEvent event) {
        try {
            QuotationsDTO qu = new QuotationsDTO(new AutoGenerateId().generateId("Quotations","QID"), c.getCid(), itemDTO.getIid(), Double.parseDouble(newPriceText.getText()));
            boolean b=quotationsBO.addQuotation(qu);
            if(b){
                newPriceText.setVisible(false);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @FXML
    void setvisiblePrice(ActionEvent event) {
        try {
            itemDTO=itemBO.searchAnItem(fishCombo.getValue());
            o=customerOrderBO.searchOrder(orderTable.getSelectionModel().getSelectedItem().getOid());
            c=customerBO.searchCustomer(o.getCid());
            QuotationsDTO q=queryBO.loadQuotationPrice(itemDTO.getIid(), c.getCid());
            if(q==null){
                newPriceText.setVisible(true);
            }else
                newPriceText.setText(q.getPrice()+"");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    void updateQty() {
        try {
            if(fishCombo.getValue()!=null) {
            itemDTO=itemBO.searchAnItem(fishCombo.getValue());
            o=customerOrderBO.searchOrder(orderTable.getSelectionModel().getSelectedItem().getOid());
            c=customerBO.searchCustomer(o.getCid());

                boolean b = customerOrderDetailsBO.addOrderDetails(FXCollections.observableArrayList(new CustomerOrderDetailsDTO(Double.parseDouble(qtyText.getText()), Double.parseDouble(newPriceText.getText()), o.getOid(), itemDTO.getName(), itemDTO.getIid())));
                if (b) {
                    orderDetailsTable.refresh();
                    orderDetails.removeAll(orderDetails);
                    orderDetails = queryBO.getSelectedOrder(orderTable.getSelectionModel().getSelectedItem().getOid());
                    orderDetailsTable.setItems(orderDetails);
                } else {

                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    void viewDetail() {
        i=orderTable.getSelectionModel().getSelectedIndex();
        try {
            if(orders.size()>0&&i>=0) {
                PaymentDTO paymentDTO=customerPaymentBO.searchPayment(orders.get(i).getOid());
                orderDetails = queryBO.getSelectedOrder(orders.get(i).getOid());
                if(orders.get(i).getDate().compareTo(java.sql.Date.valueOf(LocalDate.now()))==0&&paymentDTO==null){
                    payButton.setDisable(false);
                }else {
                    payButton.setDisable(true);
                }
            }
            orderDetailsTable.getColumns().get(0).setStyle("-fx-alignment: CENTER_LEFT;");
            orderDetailsTable.getColumns().get(1).setStyle("-fx-alignment: CENTER;");
            orderDetailsTable.getColumns().get(2).setStyle("-fx-alignment: CENTER;");
            orderDetailsTable.getColumns().get(0).setCellValueFactory(new PropertyValueFactory<>("itemName"));
            orderDetailsTable.getColumns().get(1).setCellValueFactory(new PropertyValueFactory<>("qty"));
            orderDetailsTable.getColumns().get(2).setCellValueFactory(new PropertyValueFactory<>("price"));
            orderDetailsTable.setItems(orderDetails);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void dateFormatter() {
        String pattern="yyyy-MM-dd";
        datePicker.setPromptText(pattern.toLowerCase());
        datePicker.setConverter(new StringConverter<LocalDate>() {
            DateTimeFormatter dateFormatter=DateTimeFormatter.ofPattern(pattern);
            @Override
            public String toString(LocalDate date) {
                if(date!=null){
                    return dateFormatter.format(date);
                }else {
                    return "";
                }
            }
            @Override
            public LocalDate fromString(String string) {
                if(string!=null && !string.isEmpty()){
                    return LocalDate.parse(string,dateFormatter);
                }else {
                    return null;
                }
            }
        });
    }

    public void searchOrder() {
        orders.removeAll(orders);
        try {
            if(!sheduledRadio.isSelected()&&!searchText.getText().isEmpty()&&searchText.getText()!=null) {
                String name=searchText.getText();
                CustomerDTO c = customerBO.searchCustomer(name);
                if(c!=null) {
                    if (sheduledRadio.isSelected()) {
                        orders = queryBO.searchSceduleOrders(c.getCid(), null);
                        orderTable.setItems(orders);
                        orderTable.refresh();
                    } else {
                        orders = queryBO.searchCustomerOrders(c.getCid(), null);
                        orderTable.setItems(orders);
                        orderTable.refresh();
                    }
                }
            }else if(sheduledRadio.isSelected()&&datePicker.getValue()!=null){
                orders = queryBO.searchSceduleOrders("", Date.valueOf(datePicker.getValue()));
                orderTable.setItems(orders);
                orderTable.refresh();
            }else if(datePicker.getValue()!=null){
                orders = queryBO.searchCustomerOrders("", Date.valueOf(datePicker.getValue()));
                orderTable.setItems(orders);
                orderTable.refresh();
            }else {
                orderTable.refresh();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void removeOrder(ActionEvent actionEvent) {
        if(orderTable.getSelectionModel().getSelectedIndex()>=0) {
            try {
                OrderDTO o = orderTable.getSelectionModel().getSelectedItem();
                boolean b = customerOrderBO.deleteCustomerOrder(o);
                if (b) {
                    loadOrders();
                } else {
                    Alert a = new Alert(Alert.AlertType.INFORMATION);
                    a.setContentText("Failed");
                    a.show();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else {
            Alert a = new Alert(Alert.AlertType.INFORMATION);
            a.setContentText("Select Valid Row");
            a.show();
        }
    }

    public void loadOrder(ActionEvent actionEvent) {
        b=false;
        loadOrders();
    }

    public void loadPlacedOrders(ActionEvent actionEvent) {
        try {
            //orderSearches.removeAll(orderSearches);
            orders.removeAll(orders);
            //sheduledOrders.removeAll(sheduledOrders);
            orders=customerOrderBO.getPlaced();
            orderTable.getColumns().get(0).setStyle("-fx-alignment: CENTER_LEFT;");
            orderTable.getColumns().get(1).setStyle("-fx-alignment: CENTER;");
            orderTable.getColumns().get(2).setStyle("-fx-alignment: CENTER;");
            orderTable.getColumns().get(3).setStyle("-fx-alignment: CENTER;");
            orderTable.getColumns().get(0).setCellValueFactory(new PropertyValueFactory<>("custName"));
            orderTable.getColumns().get(1).setCellValueFactory(new PropertyValueFactory<>("date"));
            orderTable.getColumns().get(2).setCellValueFactory(new PropertyValueFactory<>("priority"));
            orderTable.getColumns().get(3).setCellValueFactory(new PropertyValueFactory<>("price"));
            orderTable.refresh();
            orderTable.setItems(orders);
            payButton.setDisable(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void loadSceduled(ActionEvent actionEvent) {
        try {
            orders.removeAll(orders);
            orders=customerOrderBO.getShcheduled();
            orderTable.getColumns().get(0).setStyle("-fx-alignment: CENTER_LEFT;");
            orderTable.getColumns().get(1).setStyle("-fx-alignment: CENTER;");
            orderTable.getColumns().get(2).setStyle("-fx-alignment: CENTER;");
            orderTable.getColumns().get(3).setStyle("-fx-alignment: CENTER;");
            orderTable.getColumns().get(0).setCellValueFactory(new PropertyValueFactory<>("custName"));
            orderTable.getColumns().get(1).setCellValueFactory(new PropertyValueFactory<>("date"));
            orderTable.getColumns().get(2).setCellValueFactory(new PropertyValueFactory<>("priority"));
            orderTable.getColumns().get(3).setCellValueFactory(new PropertyValueFactory<>("price"));
            orderTable.refresh();
            orderTable.setItems(orders);
            payButton.setDisable(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void searchOrderByKey(KeyEvent event) {
        searchOrder();
    }
}
