package lk.ijse.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.input.KeyEvent;
import lk.ijse.business.custom.MarketBO;
import lk.ijse.business.main.BOFactory;
import lk.ijse.dto.MarketDTO;
import lk.ijse.generate.AutoGenerateId;

import java.net.URL;
import java.util.ResourceBundle;

public class AddMarketController implements Initializable{
    @FXML
    private JFXTextField nameText;

    @FXML
    private JFXTextField addressText;
    String mid;
    @FXML
    private JFXButton adddButton;
    private MarketBO marketBO;
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        this.marketBO= BOFactory.getInstance().getBO(BOFactory.BOTypes.MARKET);
        loadMarketId();
    }

    private void loadMarketId() {
        mid=new AutoGenerateId().generateId("Market","MID");
    }
    @FXML
    void addMarket(ActionEvent event) {
        try {
            boolean b = marketBO.addMarket(new MarketDTO(mid, nameText.getText(), addressText.getText()));
            if(b){
                Alert a=new Alert(Alert.AlertType.INFORMATION);
                a.setContentText("Added");
                a.show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
