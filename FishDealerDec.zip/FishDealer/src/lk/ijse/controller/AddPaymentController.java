package lk.ijse.controller;

import com.jfoenix.controls.JFXTextField;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.business.custom.CustomerOrderBO;
import lk.ijse.business.custom.CustomerPaymentBO;
import lk.ijse.business.custom.QueryBO;
import lk.ijse.business.main.BOFactory;
import lk.ijse.dto.OrderDTO;
import lk.ijse.dto.PaymentDTO;
import lk.ijse.generate.AutoGenerateId;

import javax.management.Query;
import java.awt.*;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class AddPaymentController implements Initializable {
    @FXML
    private Button payButton;

    @FXML
    private JFXTextField dateText;

    @FXML
    private JFXTextField customerText;

    @FXML
    private JFXTextField orderDateText;

    @FXML
    private JFXTextField orderCostText;

    @FXML
    private JFXTextField enterAmountText;

    String oid;
    CustomerPaymentBO customerPaymentBO;
    CustomerOrderBO customerOrderBO;
    QueryBO queryBO;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        loadDate();
        this.customerPaymentBO= BOFactory.getInstance().getBO(BOFactory.BOTypes.PAYMENT);
        this.customerOrderBO= BOFactory.getInstance().getBO(BOFactory.BOTypes.ORDER);
        this.queryBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.QUERY);
    }

    private void loadOrderDetails() {
        try {
            OrderDTO order = queryBO.searchCustomerOrder(oid);
            customerText.setText(order.getCustName());
            orderDateText.setText(order.getDate()+"");
            orderCostText.setText(order.getPrice()+"");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void loadDate() {
        LocalDate date=LocalDate.now();
        dateText.setText(date.toString());
    }

    @FXML
    public void setOid(String oid) {
        this.oid=oid;
        loadOrderDetails();
    }
    @FXML
    void makePayment(ActionEvent event) {
        try {
            String cpid=new AutoGenerateId().generateId("Payment","PID");
            PaymentDTO p=new PaymentDTO(cpid,oid, Date.valueOf(dateText.getText()),Double.parseDouble(enterAmountText.getText()));
            boolean b=customerPaymentBO.addPayment(p);
            if(b){
                Alert a=new Alert(Alert.AlertType.INFORMATION);
                a.setContentText("Added Payment");
                a.show();
            }else {
                Alert a=new Alert(Alert.AlertType.INFORMATION);
                a.setContentText("Failed");
                a.show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
