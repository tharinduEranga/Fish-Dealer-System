package lk.ijse.controller;

import com.jfoenix.controls.JFXDatePicker;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.StringConverter;
import lk.ijse.dbconnection.DBConnection;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.swing.JRViewer;
import net.sf.jasperreports.view.JasperViewer;

import javax.swing.*;
import java.io.InputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.ResourceBundle;

import static javafx.scene.input.KeyCode.J;

public class ReportsController implements Initializable{

    @FXML
    private Button allButton;

    @FXML
    private JFXDatePicker datePicker;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        dateFormatter();
    }
    private void dateFormatter() {
        String pattern="yyyy-MM-dd";
        datePicker.setPromptText(pattern.toLowerCase());
        datePicker.setConverter(new StringConverter<LocalDate>() {
            DateTimeFormatter dateFormatter=DateTimeFormatter.ofPattern(pattern);
            @Override
            public String toString(LocalDate date) {
                if(date!=null){
                    return dateFormatter.format(date);
                }else {
                    return "";
                }
            }
            @Override
            public LocalDate fromString(String string) {
                if(string!=null && !string.isEmpty()){
                    return LocalDate.parse(string,dateFormatter);
                }else {
                    return null;
                }
            }
        });
    }

    @FXML
    void selectByDate(ActionEvent event) {
        try {
            Connection conn=DBConnection.getInstance().getConnection();
            PreparedStatement stm=null;
            ResultSet rst=null;

            JasperDesign jd= JRXmlLoader.load("C:\\Users\\Tharindu\\JaspersoftWorkspace\\MyReports\\PaymentByDate.jrxml");
            String SQL=" select c.name, co.date, co.price, p.payment, p.date from customer c, customerorder co, customerpayment p where c.cid=co.cid and co.coid=p.coid and p.date='"+datePicker.getValue()+"'";
            JRDesignQuery jrDesignQuery=new JRDesignQuery();
            jrDesignQuery.setText(SQL);
            jd.setQuery(jrDesignQuery);

            JasperReport jr=JasperCompileManager.compileReport(jd);
            JasperPrint jp=JasperFillManager.fillReport(jr,null,conn);
            if(!jp.getPages().toString().equals("[]")) {
                JRViewer jv=new JRViewer(jp);
                jv.setVisible(true);
                jv.setOpaque(true);
                JFrame f1 = new JFrame();
                f1.setSize(1080, 899);
                f1.add(jv);
                f1.setVisible(true);
            }else{
                Alert a=new Alert(Alert.AlertType.INFORMATION);
                a.setContentText("Nothing For Selected Date");
                a.show();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void allPayments(ActionEvent actionEvent) {
        try {
            InputStream resourceAsStream = getClass().getResourceAsStream("../reports/Payments.jasper");
            HashMap hashMap=new HashMap();
            JasperPrint jasperPrint=JasperFillManager.fillReport(resourceAsStream, hashMap, DBConnection.getInstance().getConnection());
            JasperViewer.viewReport(jasperPrint, false);
        }  catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void itemReportView(ActionEvent actionEvent) {

    }

    public void loadCustom(ActionEvent actionEvent) {

    }


}
