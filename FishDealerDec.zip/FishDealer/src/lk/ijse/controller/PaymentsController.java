package lk.ijse.controller;

import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.business.custom.CustomerPaymentBO;
import lk.ijse.business.custom.QueryBO;
import lk.ijse.business.main.BOFactory;
import lk.ijse.dto.PaymentDTO;

import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.util.ResourceBundle;

public class PaymentsController implements Initializable{

    @FXML
    private ImageView exitButton;

    @FXML
    private TableView<PaymentDTO> paymentTable;

    @FXML
    private Button searchButton;

    @FXML
    private JFXDatePicker datePicker;

    @FXML
    private JFXTextField customerText;

    @FXML
    void searchByKey(KeyEvent event) {

    }

    @FXML
    void searchPayments(ActionEvent event) {

    }
    CustomerPaymentBO customerPaymentBO;
    QueryBO queryBO;

    PaymentDTO paymentDTO;
    ObservableList<PaymentDTO>paymentDTOS= FXCollections.observableArrayList();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        this.customerPaymentBO= BOFactory.getInstance().getBO(BOFactory.BOTypes.PAYMENT);
        this.queryBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.QUERY);
        loadPayments();
        loadDate();
    }

    private void loadPayments() {
        try {
            paymentDTOS=queryBO.getAllPayments();
            paymentTable.getColumns().get(0).setStyle("-fx-alignment: CENTER_LEFT;");
            paymentTable.getColumns().get(1).setStyle("-fx-alignment: CENTER;");
            paymentTable.getColumns().get(2).setStyle("-fx-alignment: CENTER;");
            paymentTable.getColumns().get(0).setCellValueFactory(new PropertyValueFactory<>("custName"));
            paymentTable.getColumns().get(1).setCellValueFactory(new PropertyValueFactory<>("date"));
            paymentTable.getColumns().get(2).setCellValueFactory(new PropertyValueFactory<>("amount"));
            paymentTable.setItems(paymentDTOS);
            String pid;
            String oid;
            Date date;
            double amount;
            String custName;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void viewOrders(ActionEvent actionEvent) throws IOException {
        AnchorPane ap = FXMLLoader.load(getClass().getResource("../view/ViewOrdersPage.fxml"));
        Stage stage=new Stage();
        stage.setScene(new Scene(ap));
        stage.show();
    }

    private void loadDate() {

    }
}
