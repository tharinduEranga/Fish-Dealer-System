package lk.ijse.controller;

import com.jfoenix.controls.JFXButton;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.business.custom.QueryBO;
import lk.ijse.business.custom.StockBO;
import lk.ijse.business.main.BOFactory;
import lk.ijse.dto.StockTableDTO;

import java.awt.*;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class StockDetailsController implements Initializable {
    @FXML
    private TableView<StockTableDTO> stockDetailsTable;

    @FXML
    private Button stockButton;

    @FXML
    private Button supplierButton;

    @FXML
    private Button addStockButton;
    ObservableList<StockTableDTO>stock= FXCollections.observableArrayList();

    StockBO stockBO;
    QueryBO queryBO;
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        this.stockBO= BOFactory.getInstance().getBO(BOFactory.BOTypes.STOCK);
        this.queryBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.QUERY);
        loadStocks();
    }

    private void loadStocks() {
        try {
            stock=queryBO.getAllStockForTable();
            stockDetailsTable.getColumns().get(0).setStyle("-fx-alignment: CENTER_LEFT;");
            stockDetailsTable.getColumns().get(1).setStyle("-fx-alignment: CENTER;");
            stockDetailsTable.getColumns().get(2).setStyle("-fx-alignment: CENTER;");
            stockDetailsTable.getColumns().get(3).setStyle("-fx-alignment: CENTER_LEFT;");
            stockDetailsTable.getColumns().get(4).setStyle("-fx-alignment: CENTER;");
            stockDetailsTable.getColumns().get(0).setCellValueFactory(new PropertyValueFactory<>("itemName"));
            stockDetailsTable.getColumns().get(1).setCellValueFactory(new PropertyValueFactory<>("itemQty"));
            stockDetailsTable.getColumns().get(2).setCellValueFactory(new PropertyValueFactory<>("stockDate"));
            stockDetailsTable.getColumns().get(3).setCellValueFactory(new PropertyValueFactory<>("supplierName"));
            stockDetailsTable.getColumns().get(4).setCellValueFactory(new PropertyValueFactory<>("price"));
            stockDetailsTable.setItems(stock);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void addStock(ActionEvent actionEvent) throws IOException {

    }
    @FXML
    public void addNewStock(ActionEvent actionEvent) throws IOException {

    }
    @FXML
    public void addNewSupplier(ActionEvent actionEvent) throws IOException {
        AnchorPane ap = FXMLLoader.load(getClass().getResource("../View/SupplierPage.fxml"));
        Stage stage=new Stage();
        stage.setScene(new Scene(ap));
        stage.show();
    }
}
