package lk.ijse.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import lk.ijse.business.custom.LogInBO;
import lk.ijse.business.main.BOFactory;
import lk.ijse.dbconnection.DBConnection;
import lk.ijse.dto.LoginDTO;
import lk.ijse.main.Main;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class LoginController implements Initializable {

    @FXML
    private Label errorLabel;

    @FXML
    private JFXTextField userNameText;

    @FXML
    private JFXPasswordField passwordText;

    @FXML
    private JFXButton logInButton;

    @FXML
    private ImageView exitImage;

    @FXML
    private JFXButton exitButton;
    LogInBO logInBO;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        this.logInBO= BOFactory.getInstance().getBO(BOFactory.BOTypes.LOGIN);
        errorLabel.setVisible(false);
    }

    @FXML
    void exit(MouseEvent event) {
        System.exit(0);
    }

    public void logIn(ActionEvent actionEvent) throws IOException {
        try {
            LoginDTO lg=logInBO.getLoginData();
            if(userNameText.getText().equals(lg.getUserName())&&passwordText.getText().equals(lg.getPassword())) {
                Stage stage = new Stage();
                Parent root = FXMLLoader.load(getClass().getResource("../View/DashBoard.fxml"));
                stage.initStyle(StageStyle.UNDECORATED);
                stage.setScene(new Scene(root, 1137, 659));
                stage.show();
                Main.getCurrentInstance().close();
            }else{
                errorLabel.setVisible(true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void moveToPass(ActionEvent actionEvent) {
        passwordText.requestFocus();
    }
}
