package lk.ijse.controller;

import com.jfoenix.controls.JFXDatePicker;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import lk.ijse.dbconnection.DBConnection;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.swing.JRViewer;

import javax.swing.*;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class PurchaseInfoController implements Initializable {
    @FXML
    private JFXDatePicker firsstDatePicker;

    @FXML
    private JFXDatePicker secondDatePicker;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        secondDatePicker.setValue(LocalDate.now());
    }

    @FXML
    void loadComparison(ActionEvent event) {
        try {
            Connection conn= DBConnection.getInstance().getConnection();
            PreparedStatement stm=null;
            ResultSet rst=null;

            JasperDesign jd= JRXmlLoader.load("C:\\Users\\Tharindu\\JaspersoftWorkspace\\MyReports\\StockPrices.jrxml");
            String SQL="select i.itemname, st.cost, st.date, s.sname\n" +
                    "from item i, stock st, supplier s\n" +
                    "where i.iid=st.iid and s.sid=st.sid and st.date between date('"+firsstDatePicker.getValue().toString()+"') and date('"+secondDatePicker.getValue().toString()+"')\n" +
                    "group by st.stid\n" +
                    "order by i.itemname desc";
            JRDesignQuery jrDesignQuery=new JRDesignQuery();
            jrDesignQuery.setText(SQL);
            jd.setQuery(jrDesignQuery);

            JasperReport jr= JasperCompileManager.compileReport(jd);
            JasperPrint jp= JasperFillManager.fillReport(jr,null,conn);
            if(!jp.getPages().toString().equals("[]")) {
                JRViewer jv=new JRViewer(jp);
                jv.setVisible(true);
                jv.setOpaque(true);
                JFrame f1 = new JFrame();
                f1.setSize(1080, 900);
                f1.add(jv);
                f1.setVisible(true);
            }else{
                Alert a=new Alert(Alert.AlertType.INFORMATION);
                a.setContentText("Nothing For Selected Date");
                a.show();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
