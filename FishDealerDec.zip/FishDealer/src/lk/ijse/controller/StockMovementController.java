package lk.ijse.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDatePicker;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import lk.ijse.dbconnection.DBConnection;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.swing.JRViewer;
import net.sf.jasperreports.view.JasperViewer;

import javax.swing.*;
import java.io.InputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.ResourceBundle;

public class StockMovementController implements Initializable {
    @FXML
    private JFXDatePicker mostMovableDate;

    @FXML
    private JFXDatePicker leastMovableDate;

    @FXML
    private JFXDatePicker movemantsDatepicker;

    @FXML
    private Label selectByLabel;

    @FXML
    private Label ofAllTimeLable;
    @FXML
    private JFXButton mostMovableButton;

    @FXML
    private JFXButton leastMovableButton;

    @FXML
    private JFXButton movesByDateButton;


    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }

    @FXML
    void loadDateMoves(ActionEvent event) {
        try {
            Connection conn=DBConnection.getInstance().getConnection();
            PreparedStatement stm=null;
            ResultSet rst=null;

            JasperDesign jd= JRXmlLoader.load("C:\\Users\\Tharindu\\JaspersoftWorkspace\\MyReports\\SoldByDate.jrxml");
            String SQL="select i.itemname, sum(od.qty)as QTY \n" +
                    "from item i, customerorderdetails od, customerorder o\n" +
                    "where i.iid=od.iid and o.coid=od.coid and o.date='"+movemantsDatepicker.getValue().toString()+"'" +
                    "group by i.iid;";
            JRDesignQuery jrDesignQuery=new JRDesignQuery();
            jrDesignQuery.setText(SQL);
            jd.setQuery(jrDesignQuery);

            JasperReport jr= JasperCompileManager.compileReport(jd);
            JasperPrint jp=JasperFillManager.fillReport(jr,null,conn);
            if(!jp.getPages().toString().equals("[]")) {
                JRViewer jv=new JRViewer(jp);
                jv.setVisible(true);
                jv.setOpaque(true);
                JFrame f1 = new JFrame();
                f1.setSize(1080, 901);
                f1.add(jv);
                f1.setVisible(true);
            }else{
                Alert a=new Alert(Alert.AlertType.INFORMATION);
                a.setContentText("Nothing For That Date");
                a.show();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    void loadLeastMovable(ActionEvent event) {
        try {
            InputStream resourceAsStream = getClass().getResourceAsStream("../reports/LeastMovableItems.jasper");
            HashMap hashMap = new HashMap();
            JasperPrint jasperPrint = JasperFillManager.fillReport(resourceAsStream, hashMap, DBConnection.getInstance().getConnection());
            JasperViewer.viewReport(jasperPrint, false);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @FXML
    void loadMostMovable(ActionEvent event) {
        try {
            InputStream resourceAsStream = getClass().getResourceAsStream("../reports/MostMovableItems.jasper");
            HashMap hashMap = new HashMap();
            JasperPrint jasperPrint = JasperFillManager.fillReport(resourceAsStream, hashMap, DBConnection.getInstance().getConnection());
            JasperViewer.viewReport(jasperPrint, false);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

}
