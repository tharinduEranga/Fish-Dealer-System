package lk.ijse.controller;

import com.jfoenix.controls.*;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.util.Callback;
import javafx.util.StringConverter;
import lk.ijse.business.custom.*;
import lk.ijse.business.main.BOFactory;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.dbconnection.DBConnection;
import lk.ijse.dto.*;
import lk.ijse.generate.AutoGenerateId;
import lk.ijse.generate.ComboBoxAutoComplete;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.swing.JRViewer;

import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Optional;
import java.util.ResourceBundle;

public class OrderController implements Initializable {
    @FXML
    private JFXButton addOrderButton;
    @FXML
    Label kgLabel;
    @FXML
    Label addedTosSchedule;
    @FXML
    JFXButton placeOrderButton;
    @FXML
    private Label priceLabel;
    @FXML
    private JFXDatePicker datePicker;
    @FXML
    Label dateLabel;
    @FXML
    TextField orderId;
    @FXML
    JFXComboBox<String> custNames;
    @FXML
    JFXComboBox itemName;
    @FXML
    private JFXButton removeButton;
    @FXML
    private ImageView removeLable;
    @FXML
    JFXComboBox priorityCombo;
    @FXML
    JFXTextField qtyText;
    @FXML
    JFXTextField unitPriceText;
    @FXML
    TextField totalText;
    @FXML
    TableView <PlaceOrderTableDTO>orderTable;
    CustomerDTO customer;
    ItemDTO item;
    String id;
    ItemTableDTO itemDTO;
    double total;
    QuotationsDTO q;
    private CustomerBO customerBO;
    private ItemBO itemBO;
    private CustomerOrderBO orderBO;
    private PriorityBO priorityBO;
    private QueryBO queryBO;
    private QuotationsBO quotationsBO;
    private CustomerPaymentBO customerPaymentBO;
    ArrayList<PlaceOrderTableDTO>items=new ArrayList<>();
    ObservableList<ItemDTO> itemsList= null;
    ObservableList<CustomerDTO> custNameList= null;
    ObservableList<String>customerNames=FXCollections.observableArrayList();
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        this.customerBO = BOFactory.getInstance().getBO(BOFactory.BOTypes.CUSTOMER);
        this.itemBO = BOFactory.getInstance().getBO(BOFactory.BOTypes.ITEM);
        this.orderBO = BOFactory.getInstance().getBO(BOFactory.BOTypes.ORDER);
        this.priorityBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.PRIORITY);
        this.quotationsBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.QUOTATION);
        this.queryBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.QUERY);
        this.customerPaymentBO= BOFactory.getInstance().getBO(BOFactory.BOTypes.PAYMENT);
        loadCustomerIds();
        loadDate();
        loadItems();
        loadNextOrderId();
        orderId.setVisible(false);
        generate();
        loadPriority();
        setDisable();
        dateFormatter();
    }

    private void dateFormatter() {
        String pattern="yyyy-MM-dd";
        datePicker.setPromptText(pattern.toLowerCase());
        datePicker.setConverter(new StringConverter<LocalDate>() {
            DateTimeFormatter dateFormatter=DateTimeFormatter.ofPattern(pattern);
            @Override
            public String toString(LocalDate date) {
                if(date!=null){
                    return dateFormatter.format(date);
                }else {
                    return "";
                }
            }
            @Override
            public LocalDate fromString(String string) {
                if(string!=null && !string.isEmpty()){
                    return LocalDate.parse(string,dateFormatter);
                }else {
                    return null;
                }
            }
        });
        datePicker.setValue(LocalDate.now());

        //Disable Past Dates
        final Callback< DatePicker, DateCell > dayCellFactory = new Callback< DatePicker, DateCell >() {
            @Override
            public DateCell call( final DatePicker datePicker) {
                return new DateCell(){
                    @Override
                    public void updateItem( LocalDate item, boolean empty) {
                        super .updateItem(item, empty);
                        if (item.isBefore(LocalDate.now().plusDays(0))) {
                            setDisable(true);
                        }
                        long p = ChronoUnit.DAYS.between(LocalDate.now(), item);
                        setTooltip(new Tooltip(" " + p + " days from now"));
                    }
                };
            }
        };
        datePicker.setDayCellFactory(dayCellFactory);
        datePicker.setValue(datePicker.getValue().plusDays( 0 ));
    }
    @FXML
    void removeRow(ActionEvent event) {
        if(orderTable.getSelectionModel().getSelectedIndex()>=0) {
            total=total-items.get(orderTable.getSelectionModel().getSelectedIndex()).getAmount();
            totalText.setText(total+"");
            items.remove(orderTable.getSelectionModel().getSelectedIndex());
            orderTable.setItems(FXCollections.observableArrayList(items));
            orderTable.refresh();
            if(items.size()==0){
                placeOrderButton.setDisable(true);
                addOrderButton.setDisable(true);
            }
        }
    }

    private void setDisable() {
        itemName.setDisable(true);
        qtyText.setDisable(true);
        unitPriceText.setDisable(true);
        priceLabel.setVisible(false);
        priceLabel.setText("");
        placeOrderButton.setDisable(true);
        addedTosSchedule.setVisible(false);
        priorityCombo.setDisable(true);
        addOrderButton.setDisable(true);
    }
    void setEnable(){
        itemName.setDisable(false);
        qtyText.setDisable(false);
        unitPriceText.setDisable(false);
    }
    private void loadPriority() {
        try {
            ObservableList<PriorityDTO>priorityDTOS=priorityBO.getAll();
            ObservableList<String>priorityName=FXCollections.observableArrayList();
            int c=priorityDTOS.size();
            for (PriorityDTO p:priorityDTOS) {
                c--;
                if(c>0) {
                    priorityName.add(p.getType());
                }else
                    break;
            }
            priorityCombo.setItems(priorityName);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadNextOrderId() {
        String oid=new AutoGenerateId().generateId("Customerorder","COID");
        orderId.setText(oid);
    }

    private void loadItems() {
        try {
            itemsList = itemBO.getAllItemNames();
        }catch (Exception e) {
            e.printStackTrace();
        }
        ObservableList<String>itemNames=FXCollections.observableArrayList();
        for(int i=0;i<itemsList.size();i++){
            itemNames.add(itemsList.get(i).getName());
        }
        itemName.setItems(itemNames);
    }

    private void loadDate() {
        dateLabel.setText(LocalDate.now().toString());
    }

    private void loadCustomerIds() {
        try {
            custNameList = customerBO.getAllCustomers();
            for (CustomerDTO c: custNameList) {
                customerNames.add(c.getName());
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        custNames.setItems(customerNames);
    }

//    public void openStock(ActionEvent actionEvent) throws IOException {
//        AnchorPane ap = FXMLLoader.load(getClass().getResource("../View/StockPage.fxml"));
//        Stage stage=new Stage();
//        stage.setScene(new Scene(ap));
//        stage.show();
//    }

    public void addItemDetail() {
        String name=itemName.getValue().toString();
        String iid=item.getIid();
        if(unitPriceText.getText().isEmpty()||qtyText.getText().isEmpty()) {
        }
        else {
            try {
                double unitprice = Double.parseDouble(unitPriceText.getText());
                double qty = Double.parseDouble(qtyText.getText());
                total = total + qty * unitprice;
                totalText.setText(String.valueOf(total));
                items.add(new PlaceOrderTableDTO(name, qty, unitprice, iid));

                orderTable.getColumns().get(0).setStyle("-fx-alignment: CENTER;");
                orderTable.getColumns().get(1).setStyle("-fx-alignment: CENTER;");
                orderTable.getColumns().get(2).setStyle("-fx-alignment: CENTER;");
                orderTable.getColumns().get(3).setStyle("-fx-alignment: CENTER;");
                orderTable.getColumns().get(0).setCellValueFactory(new PropertyValueFactory<>("name"));
                orderTable.getColumns().get(1).setCellValueFactory(new PropertyValueFactory<>("qty"));
                orderTable.getColumns().get(2).setCellValueFactory(new PropertyValueFactory<>("unitPrice"));
                orderTable.getColumns().get(3).setCellValueFactory(new PropertyValueFactory<>("amount"));
                orderTable.setItems(FXCollections.observableArrayList(items));
                if (q == null) {
                    String qid = new AutoGenerateId().generateId("Quotation","QID");
                    QuotationsDTO quotationsDTO = new QuotationsDTO(qid, customer.getCid(), item.getIid(), Double.parseDouble(unitPriceText.getText()));
                    boolean b = quotationsBO.addQuotation(quotationsDTO);
                    if (b) {
                        priceLabel.setVisible(true);
                        priceLabel.setText("Added New Price");
                    }
                }
                if (priorityCombo.isDisabled()&&Double.parseDouble(qtyText.getText())<itemDTO.getQty()) {
                    placeOrderButton.setDisable(false);
                } else if(!priorityCombo.isDisabled()){
                    addOrderButton.setDisable(false);
                }
            } catch (Exception ex) {
                priceLabel.setVisible(true);
                priceLabel.setText(ex.getCause()+"");
            }
        }
    }

    public void placeOrder(ActionEvent actionEvent) {
        try {
            String oid=orderId.getText();
            CustomerDTO c=customerBO.searchCustomer(custNames.getValue().toString());
            String cid=c.getCid();
            Date date= Date.valueOf(LocalDate.now());
            ArrayList<CustomerOrderDetailsDTO>details=new ArrayList<>();
            for( int i=0; i<orderTable.getItems().size(); i++){
                String item=itemName.getValue().toString();
                String itemCode=items.get(i).getIid();
                double qty=items.get(i).getQty();
                double unitPrice=items.get(i).getUnitPrice();
                CustomerOrderDetailsDTO od=new CustomerOrderDetailsDTO(qty,unitPrice,oid,item,itemCode);
                details.add(od);
            }
            OrderDTO order=new OrderDTO(oid,date,"PR4",cid,total,details);
            boolean isAdded=orderBO.addCustomerOrder(order);
            if(isAdded){
               // if(date.compareTo(java.sql.Date.valueOf(LocalDate.now()))==0) {
                    String cpid=new AutoGenerateId().generateId("Customerpayment","CPID");
                    PaymentDTO p=new PaymentDTO(cpid,oid,date,total);
                    boolean b=customerPaymentBO.addPayment(p);
                    if(b){
                        loadNextOrderId();
                        Connection conn= DBConnection.getInstance().getConnection();
                        PreparedStatement stm=null;
                        ResultSet rst=null;
                        JasperDesign jd= JRXmlLoader.load("C:\\Users\\Tharindu\\JaspersoftWorkspace\\MyReports\\Invoice.jrxml");
                        String SQL=" select c.name, c.address, c.tel, o.date, i.itemname, od.qty, od.pricePerItem, p.cpid, p.payment\n" +
                                "   from customer c, customerorder o, customerorderdetails od, item i, customerpayment p\n" +
                                "   where c.cid=o.cid and o.coid=od.coid and od.iid=i.iid and o.coid=p.coid and p.cpid='"+cpid+"'";
                        JRDesignQuery jrDesignQuery=new JRDesignQuery();
                        jrDesignQuery.setText(SQL);
                        jd.setQuery(jrDesignQuery);
                        JasperReport jr= JasperCompileManager.compileReport(jd);
                        JasperPrint jp= JasperFillManager.fillReport(jr,null,conn);
                        if(!jp.getPages().toString().equals("[]")) {
                            JRViewer jv=new JRViewer(jp);
                            jv.setVisible(true);
                            jv.setOpaque(true);
                            JFrame f1 = new JFrame();
                            f1.setSize(1080, 900);
                            f1.add(jv);
                            f1.setLocationRelativeTo(null);
                            f1.setVisible(true);
                        }else{
                            Alert a=new Alert(Alert.AlertType.INFORMATION);
                            a.setContentText("Order Added but Failed to print Bill");
                            a.show();
                        }
                    }
//                }else {
//                    addedTosSchedule.setText("Added to List");
//                    addedTosSchedule.setVisible(true);
//                }
            }else {
                addedTosSchedule.setText("Failed");
                addedTosSchedule.setVisible(true);
            }
        } catch (Exception e) {
            priceLabel.setVisible(true);
            priceLabel.setText(e.getCause()+"");
        }
    }

    @FXML
    void addToSchedule(ActionEvent event) {
        try {
            String oid=orderId.getText();
            CustomerDTO c=customerBO.searchCustomer(custNames.getValue().toString());
            String cid=c.getCid();
            Date date= Date.valueOf(datePicker.getValue());
            ArrayList<CustomerOrderDetailsDTO>details=new ArrayList<>();
            for( int i=0; i<orderTable.getItems().size(); i++){
                String item=itemName.getValue().toString();
                String itemCode=items.get(i).getIid();
                double qty=items.get(i).getQty();
                double unitPrice=items.get(i).getUnitPrice();
                CustomerOrderDetailsDTO od=new CustomerOrderDetailsDTO(qty,unitPrice,oid,item,itemCode);
                details.add(od);
            }
            OrderDTO order=new OrderDTO(oid,date,id,cid,total,details);
            boolean isAdded=orderBO.addScheduleOrder(order);
            if(isAdded){
                    addedTosSchedule.setText("Added to List");
                    addedTosSchedule.setVisible(true);
            }else {
                addedTosSchedule.setText("Failed");
                addedTosSchedule.setVisible(true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setUnitPrice(ActionEvent actionEvent) {
        try {
            Double.parseDouble(qtyText.getText());
            unitPriceText.requestFocus();
        }catch (Exception e){

        }

    }

    public void gotoFish(ActionEvent actionEvent) {
        try {
            orderTable.setItems(null);
            orderTable.refresh();
            customer=customerBO.searchCustomer(custNames.getValue().toString());
            addedTosSchedule.setVisible(false);
        } catch (Exception e) {
            e.printStackTrace();
        }
        setEnable();
        //itemName.requestFocus();
    }

    public void generate() {
        new ComboBoxAutoComplete<String>(custNames);
        new ComboBoxAutoComplete<String>(itemName);
    }

    public void loadQty(ActionEvent actionEvent) {
        priceLabel.setVisible(false);
        String name=itemName.getValue().toString();
        try {
            itemDTO=queryBO.searchItem(name);
            kgLabel.setText(itemDTO.getQty()+" KG Left");
            item =itemBO.searchAnItem(name);
            q=queryBO.loadQuotationPrice(item.getIid(),customer.getCid());
            if(q!=null) {
                unitPriceText.setText(q.getPrice() + "");
            }else {
                unitPriceText.setText("");
                priceLabel.setText("Add New Quotation Price");
                priceLabel.setVisible(true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        //qtyText.requestFocus();
    }

    public void getPriorityId(ActionEvent actionEvent) {
        String pname=priorityCombo.getValue().toString();
        try {
            id=priorityBO.searchPriority(pname);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void gotoPriority(ActionEvent actionEvent) {
        priorityCombo.setDisable(false);
        priorityCombo.requestFocus();
    }
}
