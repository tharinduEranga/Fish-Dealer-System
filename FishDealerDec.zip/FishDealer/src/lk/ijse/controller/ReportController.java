package lk.ijse.controller;

import com.jfoenix.controls.JFXButton;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingNode;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.effect.Glow;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import lk.ijse.business.custom.CustomerBO;
import lk.ijse.business.custom.CustomerOrderBO;
import lk.ijse.business.custom.ItemBO;
import lk.ijse.business.main.BOFactory;
import lk.ijse.dbconnection.DBConnection;
import lk.ijse.dto.CustomerDTO;
import lk.ijse.dto.CustomerTableDTO;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.swing.JRViewer;
import net.sf.jasperreports.view.JasperViewer;

import javax.jws.soap.SOAPBinding;
import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.ResourceBundle;

public class ReportController implements Initializable{
    @FXML
    private Label stockMovementLble;
    @FXML
    private ImageView exitButton;
    @FXML
    ImageView returnedLabel;
    @FXML
    private ImageView lowCustomerLabel;
    @FXML
    private JFXButton lowCustomerButton;

    @FXML
    private JFXButton topCustomerButton;

    @FXML
    private JFXButton viewPurchases;

    @FXML
    private JFXButton stockMovements;

    @FXML
    private JFXButton botiqueShares;

    @FXML
    private JFXButton sales;

    @FXML
    private JFXButton rewmovedStocks;

    @FXML
    private JFXButton payments;

    private CustomerBO customerBO;
    private ItemBO itemBO;
    private CustomerOrderBO orderBO;

    public void initialize(URL location, ResourceBundle resources) {
        this.customerBO = BOFactory.getInstance().getBO(BOFactory.BOTypes.CUSTOMER);
        this.itemBO = BOFactory.getInstance().getBO(BOFactory.BOTypes.ITEM);
        this.orderBO = BOFactory.getInstance().getBO(BOFactory.BOTypes.ORDER);
    }

    @FXML
    void viewLowCustomers() {
        try {
            InputStream resourceAsStream = getClass().getResourceAsStream("../reports/Low10.jasper");
            HashMap hashMap=new HashMap();
            JasperPrint jasperPrint=JasperFillManager.fillReport(resourceAsStream, hashMap, DBConnection.getInstance().getConnection());
            JasperViewer.viewReport(jasperPrint, false);
        }  catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @FXML
    void viewLowCustomers(MouseEvent event) {
        viewLowCustomers();
    }

    @FXML
    void viewPayments(ActionEvent event) throws IOException {
        AnchorPane ap = FXMLLoader.load(getClass().getResource("../View/Report.fxml"));
        Stage stage=new Stage();
        stage.setScene(new Scene(ap));
        stage.show();
    }

    @FXML
    void viewPurchases(ActionEvent event) throws IOException {
        AnchorPane ap = FXMLLoader.load(getClass().getResource("../View/PurchaseInfo.fxml"));
        Stage stage=new Stage();
        stage.setScene(new Scene(ap));
        stage.show();
    }

    @FXML
    void viewSales(ActionEvent event) throws IOException {
        AnchorPane ap = FXMLLoader.load(getClass().getResource("../View/SalesDetails.fxml"));
        Stage stage=new Stage();
        stage.setScene(new Scene(ap));
        stage.show();
    }

    @FXML
    void viewStockMovements(ActionEvent event) {
        try {
            AnchorPane ap = FXMLLoader.load(getClass().getResource("../View/StockMovementsPage.fxml"));
            Stage stage=new Stage();
            stage.setScene(new Scene(ap));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void loadStockMovement(MouseEvent event) {
        try {
            AnchorPane ap = FXMLLoader.load(getClass().getResource("../View/StockMovementsPage.fxml"));
            Stage stage=new Stage();
            stage.setScene(new Scene(ap));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void viewTopCustomers(MouseEvent event) {
        viewTopCustomers();
    }

    @FXML
    void viewTopCustomers() {
        try {
            Connection conn=DBConnection.getInstance().getConnection();
            PreparedStatement stm=null;
            ResultSet rst=null;

            JasperDesign jd= JRXmlLoader.load("C:\\Users\\Tharindu\\JaspersoftWorkspace\\MyReports\\Most Valuable Customers.jrxml");
            String SQL="SELECT C.NAME, COUNT(O.COID)AS No\n" +
                    "FROM CUSTOMER C, CUSTOMERORDER O\n" +
                    "WHERE C.CID=O.CID AND O.DATE\n" +
                    "GROUP BY C.CID order by no desc limit 10";
            JRDesignQuery jrDesignQuery=new JRDesignQuery();
            jrDesignQuery.setText(SQL);
            jd.setQuery(jrDesignQuery);

            JasperReport jr= JasperCompileManager.compileReport(jd);
            JasperPrint jp=JasperFillManager.fillReport(jr,null,conn);
            if(!jp.getPages().toString().equals("[]")) {
                JRViewer jv=new JRViewer(jp);
                jv.setVisible(true);
                jv.setOpaque(true);
                JFrame f1 = new JFrame();
                f1.setSize(1080, 900);
                f1.add(jv);
                f1.setVisible(true);
            }else{
                Alert a=new Alert(Alert.AlertType.INFORMATION);
                a.setContentText("Nothing For Selected Date");
                a.show();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }

}
