package lk.ijse.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.business.custom.*;
import lk.ijse.business.impl.DueStockBOimpl;
import lk.ijse.business.main.BOFactory;
import lk.ijse.dto.*;
import lk.ijse.entity.DueStock;
import lk.ijse.entity.Supplier;
import lk.ijse.generate.AutoGenerateId;
import lk.ijse.generate.ComboBoxAutoComplete;

import javax.jws.soap.SOAPBinding;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class StockController implements Initializable{
    @FXML
    private Label errorLabel;
    @FXML
    private ImageView exitButton;
    @FXML
    private ImageView ok;

    @FXML
    private ImageView fail;
    @FXML
    private TableView<ItemTableDTO> itemTable;

    @FXML
    private JFXTextField searchText;

    @FXML
    private JFXButton reloadButton;

    @FXML
    private JFXButton stockDetails;

    @FXML
    private JFXButton addDueListButton;

    @FXML
    private JFXTextField qtyText;

    @FXML
    private JFXTextField addQtyText;

    @FXML
    private TableView<StockTableDTO> stockTable;

    @FXML
    private Button supplierButton;

    @FXML
    private JFXTextField costText;

    @FXML
    private JFXButton shareButton;

    @FXML
    private JFXButton removeButton;

    @FXML
    private JFXButton addStockButton;

    @FXML
    private Button stockButton;

    @FXML
    private JFXComboBox<String> supplierCombo;

    @FXML
    private JFXComboBox<String> nameCombo;
    int i=-1;
    ItemBO itemBO;
    DueStockBO dueStockBO;
    StockBO stockBO;
    SupplierBO supplierBO;
    QueryBO queryBO;
    ObservableList<ItemTableDTO>items=FXCollections.observableArrayList();
    ObservableList<StockTableDTO>stock= FXCollections.observableArrayList();
    ObservableList<ItemDTO>itemsList= FXCollections.observableArrayList();
    ObservableList<SupplierDTO>supplers= FXCollections.observableArrayList();
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        this.itemBO= BOFactory.getInstance().getBO(BOFactory.BOTypes.ITEM);
        this.queryBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.QUERY);
        this.dueStockBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.DUESTOCK);
        supplierBO= BOFactory.getInstance().getBO(BOFactory.BOTypes.SUPPLIER);
        this.stockBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.STOCK);
        loadItems();
        loadItemNames();
        loadSupplierNames();
        autoComplete();
        ok.setVisible(false);
        fail.setVisible(false);
        errorLabel.setVisible(false);
    }

    private void autoComplete() {
        new ComboBoxAutoComplete(supplierCombo);
        new ComboBoxAutoComplete(nameCombo);
    }

    private void loadItems() {
        items.removeAll(items);
        try{
            items=queryBO.getAllItems();
            itemTable.getColumns().get(0).setStyle("-fx-alignment: CENTER_LEFT;");
            itemTable.getColumns().get(1).setStyle("-fx-alignment: CENTER;");
            itemTable.getColumns().get(0).setCellValueFactory(new PropertyValueFactory<>("name"));
            itemTable.getColumns().get(1).setCellValueFactory(new PropertyValueFactory<>("qty"));
            itemTable.setItems(items);
            itemTable.refresh();
        }catch (Exception c){
            c.printStackTrace();
        }
    }

    public void viewDetails(ActionEvent actionEvent) throws IOException {
        AnchorPane ap = FXMLLoader.load(getClass().getResource("../View/StockDetailsPage.fxml"));
        Stage stage=new Stage();
        stage.setScene(new Scene(ap));
        stage.show();

        ok.setVisible(false);
        fail.setVisible(false);
    }

    @FXML
    private void deleteEmptyStock() {
        ArrayList<StockDTO> stocks=new ArrayList<>();
        boolean b=false;
        try {
            stocks=stockBO.getAllStocks();
            for (StockDTO s:stocks) {
                if(s.getQty()<=0){
                    b=stockBO.deleteStock(s.getStid());
                }
            }
            if(b)
                System.out.println("Empty Stocks Were Deleted");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void searchItem() {
        try {
            items.removeAll(items);
            ItemTableDTO i=queryBO.searchItem(searchText.getText());
            items.add(i);
            itemTable.setItems(items);
            itemTable.refresh();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    void searchFish(KeyEvent event) {
        if(searchText.getText()==null||searchText.getText().equals("")) {
            loadItems();
        }else {
            searchItem();
        }
    }
    public void addToDueList(ActionEvent actionEvent) {
        if(i>=0&&qtyText.getText()!=null) {
            try {
                ItemDTO item = itemBO.searchAnItem(items.get(i).getName());
                boolean b=dueStockBO.addNew(new DueStockDTO(item.getIid(),Double.parseDouble(qtyText.getText())));
                if(b){
                    Alert a=new Alert(Alert.AlertType.INFORMATION);
                    a.setTitle("State");
                    a.setContentText("Added");
                    a.show();
                }else {
                    Alert a=new Alert(Alert.AlertType.INFORMATION);
                    a.setTitle("State");
                    a.setContentText("Failed");
                    a.show();
                }
            } catch (Exception e) {
                errorLabel.setText("Already Added");
                errorLabel.setVisible(true);
            }
        }

    }

    public void loadItem(ActionEvent actionEvent) {
        loadItems();
    }

    public void searchItems(KeyEvent keyEvent) {

    }

    public void gotoQtyText(MouseEvent mouseEvent) {
        i=itemTable.getSelectionModel().getSelectedIndex();
        if(i>=0) {
            try {
                stock = queryBO.searchStock(items.get(i).getIid());
                stockTable.getColumns().get(0).setStyle("-fx-alignment: CENTER_LEFT;");
                stockTable.getColumns().get(1).setStyle("-fx-alignment: CENTER;");
                stockTable.getColumns().get(2).setStyle("-fx-alignment: CENTER;");
                stockTable.getColumns().get(3).setStyle("-fx-alignment: CENTER_LEFT;");
                stockTable.getColumns().get(4).setStyle("-fx-alignment: CENTER;");
                stockTable.getColumns().get(0).setCellValueFactory(new PropertyValueFactory<>("itemName"));
                stockTable.getColumns().get(1).setCellValueFactory(new PropertyValueFactory<>("itemQty"));
                stockTable.getColumns().get(2).setCellValueFactory(new PropertyValueFactory<>("stockDate"));
                stockTable.getColumns().get(3).setCellValueFactory(new PropertyValueFactory<>("supplierName"));
                stockTable.getColumns().get(4).setCellValueFactory(new PropertyValueFactory<>("price"));
                stockTable.setItems(stock);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        //qtyText.requestFocus();
        ok.setVisible(false);
        fail.setVisible(false);
        errorLabel.setVisible(false);
    }

    @FXML
    void addNewStock(ActionEvent event) {
        if(nameCombo.getValue()!=null&&addQtyText.getText()!=null&&costText.getText()!=null) {
            try {
                String stid = new AutoGenerateId().generateId("Stock","STID");
                ItemDTO item = itemBO.searchAnItem(nameCombo.getValue().toString());
                SupplierDTO s = supplierBO.searchSupplier(supplierCombo.getValue().toString());
                boolean b = stockBO.addStock(new StockTableDTO(stid, item.getIid(), Double.parseDouble(addQtyText.getText()), Date.valueOf(LocalDate.now()), s.getId(), Double.parseDouble(costText.getText())));
                if (b) {
                    ok.setVisible(true);
                    b = dueStockBO.deleteDue(item.getIid());
                } else
                    fail.setVisible(true);

            } catch (Exception e) {
                errorLabel.setText(e.getMessage());
                errorLabel.setVisible(true);
            }
        }
    }

    @FXML
    void addNewSupplier(ActionEvent event) throws IOException {
        AnchorPane ap = FXMLLoader.load(getClass().getResource("../View/SupplierPage.fxml"));
        Stage stage=new Stage();
        stage.setScene(new Scene(ap));
        stage.show();
    }

    @FXML
    void addStock(ActionEvent event) {

    }

    @FXML
    void comboAction(ActionEvent event) {
        //costText.requestFocus();
    }

    @FXML
    void costAction(ActionEvent event) {

    }

    @FXML
    void nameAction(ActionEvent event) {
        addQtyText.requestFocus();
        ok.setVisible(false);
        fail.setVisible(false);
    }

    @FXML
    void qtyAction(ActionEvent event) {
        supplierCombo.requestFocus();
    }

    @FXML
    void removeStock(ActionEvent event) {

    }

    @FXML
    void shareToBotique(ActionEvent event) {

    }

    @FXML
    void updateRow(MouseEvent event) {

    }

    private void loadItemNames() {
        try {
            itemsList = itemBO.getAllItemNames();
        }catch (Exception e) {
            e.printStackTrace();
        }
        ObservableList<String>itemNames=FXCollections.observableArrayList();
        for(int i=0;i<itemsList.size();i++){
            itemNames.add(itemsList.get(i).getName());
        }
        nameCombo.setItems(itemNames);
    }

    private void loadDate() {
        LocalDate date=LocalDate.now();
    }

    private void loadSupplierNames() {
        ObservableList<String>supNames=FXCollections.observableArrayList();
        try {
            supplers = supplierBO.getAllSuppliers();
            for (SupplierDTO s:supplers) {
                supNames.add(s.getName());
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
        supplierCombo.setItems(supNames);
    }

    public void addNewFish(ActionEvent actionEvent) {
        AnchorPane ap = null;
        try {
            ap = FXMLLoader.load(getClass().getResource("../View/AddNewItem.fxml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        Stage stage=new Stage();
        stage.setScene(new Scene(ap));
        stage.show();
        ok.setVisible(false);
        fail.setVisible(false);
        errorLabel.setVisible(false);
    }

    @FXML
    void exit(MouseEvent event) {
        System.exit(0);
    }
}
