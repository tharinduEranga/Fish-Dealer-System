package lk.ijse.controller;

import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import lk.ijse.business.custom.CustomerBO;
import lk.ijse.business.custom.ItemBO;
import lk.ijse.business.custom.QueryBO;
import lk.ijse.business.custom.QuotationsBO;
import lk.ijse.business.main.BOFactory;
import lk.ijse.dbconnection.DBConnection;
import lk.ijse.dto.CustomerDTO;
import lk.ijse.dto.ItemDTO;
import lk.ijse.dto.QuotationsDTO;
import lk.ijse.dto.QuotationsTableDTO;
import lk.ijse.entity.Customer;
import lk.ijse.entity.Item;
import lk.ijse.generate.AutoGenerateId;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.swing.JRViewer;

import javax.swing.*;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

public class MakeQuotationController implements Initializable{

    @FXML
    private JFXTextField priceText;

    @FXML
    private Label errorLabel;

    @FXML
    private JFXComboBox<String> customerCombo;

    @FXML
    private JFXComboBox<String> fishCombo;

    @FXML
    private ImageView addedImage;
    ObservableList<QuotationsTableDTO>quotations;
    ObservableList<ItemDTO>items=FXCollections.observableArrayList();
    CustomerDTO c;
    ItemDTO i;
    int count;
    CustomerBO customerBO;
    QueryBO queryBO;
    ItemBO itemBO;
    QuotationsBO quotationsBO;
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        customerBO= BOFactory.getInstance().getBO(BOFactory.BOTypes.CUSTOMER);
        queryBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.QUERY);
        itemBO= BOFactory.getInstance().getBO(BOFactory.BOTypes.ITEM);
        quotationsBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.QUOTATION);
        loadAllCustomers();
        loadAllItems();
        addedImage.setVisible(false);
        errorLabel.setVisible(false);
    }

    private void loadAllItems() {
        items.removeAll(items);
        try {
            items=itemBO.getAllItemNames();
            ObservableList<String> item= FXCollections.observableArrayList();
            for(ItemDTO i: items){
                item.add(i.getName());
            }
            fishCombo.setItems(item);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadAllCustomers() {
        try {
            ObservableList<String>customers=queryBO.getNonQuotationCustomers();
            customerCombo.setItems(customers);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    void addQuotation(ActionEvent event) {
        try {
            String qid=new AutoGenerateId().generateId("Quotations","QID");
            QuotationsDTO quotationsDTO=new QuotationsDTO(qid,c.getCid(),i.getIid(),Double.parseDouble(priceText.getText()));
            boolean b=quotationsBO.addQuotation(quotationsDTO);
            if(b){
                count++;
                addedImage.setVisible(true);
                if(items.size()==count){
                        Connection conn= DBConnection.getInstance().getConnection();
                        PreparedStatement stm=null;
                        ResultSet rst=null;

                        JasperDesign jd= JRXmlLoader.load("C:\\Users\\Tharindu\\JaspersoftWorkspace\\MyReports\\Quotation.jrxml");
                        String SQL="select c.name, i.itemname, q.price\n" +
                                "     from customer c, item i, quotations q\n" +
                                "     where c.cid=q.cid and i.iid=q.iid and q.cid='"+c.getCid()+"'";
                        JRDesignQuery jrDesignQuery=new JRDesignQuery();
                        jrDesignQuery.setText(SQL);
                        jd.setQuery(jrDesignQuery);

                        JasperReport jr= JasperCompileManager.compileReport(jd);
                        JasperPrint jp= JasperFillManager.fillReport(jr,null,conn);
                        if(!jp.getPages().toString().equals("[]")) {
                            JRViewer jv=new JRViewer(jp);
                            jv.setVisible(true);
                            jv.setOpaque(true);
                            JFrame f1 = new JFrame();
                            f1.setSize(1081, 899);
                            f1.add(jv);
                            f1.setLocationRelativeTo(null);
                            f1.setVisible(true);
                        }else{
                            Alert a=new Alert(Alert.AlertType.INFORMATION);
                            a.setContentText("Unable to Print Quotation");
                            a.show();
                        }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    void selectCustomer(ActionEvent event) {
        try {
            quotations=queryBO.getAllQuotations();
            if(fishCombo.getValue()!=null) {
                c = customerBO.searchCustomer(customerCombo.getValue().toString());
                i = itemBO.searchAnItem(fishCombo.getValue().toString());
                for (int j = 0; j < quotations.size(); j++) {
                    if (c.getName().equals(quotations.get(j).getCustomer()) && i.getName().equals(quotations.get(j).getFish())) {
                        errorLabel.setVisible(true);
                        priceText.setDisable(true);
                        break;
                    } else {
                        errorLabel.setVisible(false);
                        priceText.setDisable(false);
                        fishCombo.requestFocus();
                    }
                }
            }else {
                c = customerBO.searchCustomer(customerCombo.getValue().toString());
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @FXML
    void selectFish(ActionEvent event) {
        try {
            addedImage.setVisible(false);
            quotations=queryBO.getAllQuotations();
            if(customerCombo.getValue()!=null) {
                c = customerBO.searchCustomer(customerCombo.getValue().toString());
                i = itemBO.searchAnItem(fishCombo.getValue().toString());
                for (int j = 0; j < quotations.size(); j++) {
                    if (c.getName().equals(quotations.get(j).getCustomer()) && i.getName().equals(quotations.get(j).getFish())) {
                        errorLabel.setVisible(true);
                        priceText.setDisable(true);
                        break;
                    } else {
                        errorLabel.setVisible(false);
                        priceText.setDisable(false);
                        priceText.requestFocus();
                    }
                }
            }else {
                i = itemBO.searchAnItem(fishCombo.getValue().toString());
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @FXML
    public void setComboValues(CustomerDTO c) {
        System.out.println("arrived");
        //this.c=c;
        //this.i=i;
        customerCombo.setItems(FXCollections.observableArrayList(c.getName()));
        //fishCombo.setValue(i.getName());
        //priceText.requestFocus();
    }
}
