package lk.ijse.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import lk.ijse.business.custom.CustomerOrderDetailsBO;
import lk.ijse.business.main.BOFactory;
import lk.ijse.dto.CustomerOrderDetailsDTO;
import lk.ijse.dto.OrderDetailsTableDTO;

import java.net.URL;
import java.util.ResourceBundle;

public class OrderDetailController implements Initializable{
    @FXML
    private TableView<OrderDetailsTableDTO> orderDetailsTable;

    @FXML
    private JFXTextField qtyText;

    @FXML
    private JFXButton updateButton;

    @FXML
    private JFXButton deleteButton;

    @FXML
    private JFXTextField customerText;

    @FXML
    private JFXTextField fishText;
    int i=-1;
    CustomerOrderDetailsBO customerOrderDetailsBO;
    ObservableList<OrderDetailsTableDTO>orderDetails= FXCollections.observableArrayList();
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        this.customerOrderDetailsBO= BOFactory.getInstance().getBO(BOFactory.BOTypes.ORDERDETAIL);
        loadOrderDetails();
    }

    private void loadOrderDetails() {
        try {
            orderDetails=customerOrderDetailsBO.getOrderDetails();
            orderDetailsTable.getColumns().get(0).setStyle("-fx-alignment: CENTER_LEFT;");
            orderDetailsTable.getColumns().get(1).setStyle("-fx-alignment: CENTER_LEFT;");
            orderDetailsTable.getColumns().get(2).setStyle("-fx-alignment: CENTER;");
            orderDetailsTable.getColumns().get(3).setStyle("-fx-alignment: CENTER;");
            orderDetailsTable.getColumns().get(0).setCellValueFactory(new PropertyValueFactory<>("custName"));
            orderDetailsTable.getColumns().get(1).setCellValueFactory(new PropertyValueFactory<>("itemName"));
            orderDetailsTable.getColumns().get(2).setCellValueFactory(new PropertyValueFactory<>("qty"));
            orderDetailsTable.getColumns().get(3).setCellValueFactory(new PropertyValueFactory<>("price"));
            orderDetailsTable.setItems(orderDetails);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    void deleteDetail(ActionEvent event) {

    }

    @FXML
    void searchOrderDetail(ActionEvent event) {

    }

    @FXML
    void updateQty(ActionEvent event) {
        try {
            boolean b = customerOrderDetailsBO.updateOrderDetail(Double.parseDouble(qtyText.getText()),orderDetails.get(i).getOid(),orderDetails.get(i).getItemName());
            if(b){
                Alert a=new Alert(Alert.AlertType.INFORMATION);
                a.setTitle("Detail");
                a.setContentText("Added");
            }else {
                Alert a=new Alert(Alert.AlertType.INFORMATION);
                a.setTitle("Detail");
                a.setContentText("Failed");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void getIndex(MouseEvent mouseEvent) {
        i=orderDetailsTable.getSelectionModel().getSelectedIndex();
        qtyText.requestFocus();
    }

}
