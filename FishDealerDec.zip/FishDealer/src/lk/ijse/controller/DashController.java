package lk.ijse.controller;

import com.jfoenix.controls.JFXButton;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import lk.ijse.business.custom.CustomerOrderBO;
import lk.ijse.business.custom.ItemBO;
import lk.ijse.business.custom.QueryBO;
import lk.ijse.business.custom.StockBO;
import lk.ijse.business.main.BOFactory;
import lk.ijse.dto.ItemDTO;
import lk.ijse.dto.ItemTableDTO;
import lk.ijse.dto.OrderDTO;
import lk.ijse.dto.StockDTO;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.time.temporal.Temporal;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DashController implements Initializable {
    @FXML
    private AnchorPane notiPane;

    @FXML
    private ImageView closeNotiLabel;

    @FXML
    private Label orderNotiLabel;

    @FXML
    private Label stockNotiLabel;

    @FXML
    private JFXButton placeOrderButton;

    @FXML
    private JFXButton customerButton;

    @FXML
    private JFXButton orderButton;

    @FXML
    private JFXButton quotationButton;

    @FXML
    private JFXButton stockButton;

    @FXML
    private JFXButton supplierButton;

    @FXML
    private JFXButton paymentButton;

    @FXML
    private JFXButton reportButtton;
    
    @FXML
    private JFXButton dueStockButton;

    @FXML
    private AnchorPane mainPane;

    @FXML
    private ImageView alertNoImage;

    @FXML
    private ImageView alertImage;

    @FXML
    private ImageView exitImage;

    @FXML
    private JFXButton exitButton;

    @FXML
    private ImageView homeImage;

    public static AnchorPane pane;

    public static AnchorPane anchorPane;

    public CustomerOrderBO customerOrderBO;
    public StockBO stockBO;
    public ItemBO itemBO;
    public QueryBO queryBO;
    public ArrayList<OrderDTO>orders=new ArrayList<>();
    public ArrayList<StockDTO>stocks=new ArrayList<>();
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        pane=mainPane;
        this.customerOrderBO= BOFactory.getInstance().getBO(BOFactory.BOTypes.ORDER);
        this.itemBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.ITEM);
        this.queryBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.QUERY);
        this.stockBO=BOFactory.getInstance().getBO(BOFactory.BOTypes.STOCK);
        //deleteEmptyStock();
        setVisible();
        loadOrders();
        gotoHome();
        initLabels();
    }

    private void initLabels() {

    }

    private void setVisible() {
        notiPane.setVisible(false);
        orderNotiLabel.setVisible(false);
        stockNotiLabel.setVisible(false);
        alertImage.setVisible(false);
    }

    @FXML
    void openStockNoti(MouseEvent event) {
        openStock();
    }

//    private void deleteEmptyStock() {
//        boolean b=false;
//        try {
//            stocks=stockBO.getAllStocks();
//            for (StockDTO s:stocks) {
//                if(s.getQty()<=0){
//                    b=stockBO.deleteStock(s.getStid());
//                }
//            }
//            if(b)
//                System.out.println("Empty Stocks Were Deleted");
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

    @FXML
    void openOrders(MouseEvent event) {
       openOrder();
    }

    void setEnable(){
            placeOrderButton.setDisable(false);
            customerButton.setDisable(false);
            orderButton.setDisable(false);
            quotationButton.setDisable(false);
            stockButton.setDisable(false);
            supplierButton.setDisable(false);
            paymentButton.setDisable(false);
            reportButtton.setDisable(false);
            dueStockButton.setDisable(false);
            mainPane.requestFocus();
    }

    @FXML
    private void viewNotifications(){
        notiPane.setVisible(true);

    }

    @FXML
    private void closeNotifications(){
        notiPane.setVisible(false);
    }

    private void loadOrders() {
        try {
            orders=customerOrderBO.getAllCustomerOrders();
            for (OrderDTO o: orders) {
                long diff= ChronoUnit.DAYS.between(LocalDate.now(), o.getDate().toLocalDate());
                if(diff<=2&&diff>0){
                    alertImage.setVisible(true);
                    orderNotiLabel.setVisible(true);
                    Tooltip.install(alertImage, new Tooltip("You Have Orders to Issue"));
                }
            }
            ObservableList<ItemTableDTO>itemDTOS=queryBO.getAllItems();
            for (ItemTableDTO i:itemDTOS) {
                double qty=i.getQty();
                if(qty<10){
                    stockNotiLabel.setVisible(true);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    void exit() {
        System.exit(0);
    }

    @FXML
    void openCustomer(ActionEvent event) {
        try {
            Node ui1 = FXMLLoader.load(this.getClass().getResource("../view/CustomerPage.fxml"));

            if (!mainPane.getChildren().isEmpty()) {
                mainPane.getChildren().remove(0);
            }
            mainPane.getChildren().add(ui1);
            setEnable();
            customerButton.setDisable(true);
            closeNotifications();
        } catch (IOException ex) {
            Logger.getLogger(DashController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    void openDueStock(ActionEvent event) {
        try {
            Node ui1 = FXMLLoader.load(this.getClass().getResource("../view/DueStockList.fxml"));

            if (!mainPane.getChildren().isEmpty()) {
                mainPane.getChildren().remove(0);
            }
            mainPane.getChildren().add(ui1);
//            setEnable();
//            dueStockButton.setDisable(true);
//            closeNotifications();
        } catch (IOException ex) {
            Logger.getLogger(DashController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    void gotoHome() {
        try {
            Node ui1 = FXMLLoader.load(this.getClass().getResource("../view/HomePage.fxml"));

            if (!mainPane.getChildren().isEmpty()) {
                mainPane.getChildren().remove(0);
            }
            mainPane.getChildren().add(ui1);
            setEnable();
            closeNotifications();
        } catch (IOException ex) {
            Logger.getLogger(DashController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    void openOrder() {
        try {
            Node ui1 = FXMLLoader.load(this.getClass().getResource("../view/ViewOrdersPage.fxml"));

            if (!mainPane.getChildren().isEmpty()) {
                mainPane.getChildren().remove(0);
            }
            mainPane.getChildren().add(ui1);
            setEnable();
            orderButton.setDisable(true);
            closeNotifications();
        } catch (IOException ex) {
            Logger.getLogger(DashController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    void openPayments(ActionEvent event) {
        try {
            Node ui1 = FXMLLoader.load(this.getClass().getResource("../view/PaymentsPage.fxml"));

            if (!mainPane.getChildren().isEmpty()) {
                mainPane.getChildren().remove(0);
            }
            mainPane.getChildren().add(ui1);
            setEnable();
            paymentButton.setDisable(true);
            closeNotifications();
        } catch (IOException ex) {
            Logger.getLogger(DashController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    void openPlaceOrder(ActionEvent event) {
        try {
            Node ui1 = FXMLLoader.load(this.getClass().getResource("../view/OrderPage.fxml"));

            if (!mainPane.getChildren().isEmpty()) {
                mainPane.getChildren().remove(0);
            }
            mainPane.getChildren().add(ui1);
            setEnable();
            placeOrderButton.setDisable(true);
            closeNotifications();
        } catch (IOException ex) {
            Logger.getLogger(DashController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    void openQuotation(ActionEvent event) {
        try {
            Node ui1 = FXMLLoader.load(this.getClass().getResource("../view/Quotations.fxml"));

            if (!mainPane.getChildren().isEmpty()) {
                mainPane.getChildren().remove(0);
            }
            mainPane.getChildren().add(ui1);
            setEnable();
            quotationButton.setDisable(true);
            closeNotifications();
        } catch (IOException ex) {
            Logger.getLogger(DashController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    void openReports(ActionEvent event) {
        try {
            Node ui1 = FXMLLoader.load(this.getClass().getResource("../view/ReportsPage.fxml"));

            if (!mainPane.getChildren().isEmpty()) {
                mainPane.getChildren().remove(0);
            }
            mainPane.getChildren().add(ui1);
            setEnable();
            reportButtton.setDisable(true);
            closeNotifications();
        } catch (IOException ex) {
            Logger.getLogger(DashController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    void openStock() {
        try {
            Node ui1 = FXMLLoader.load(this.getClass().getResource("../view/StockPage.fxml"));

            if (!mainPane.getChildren().isEmpty()) {
                mainPane.getChildren().remove(0);
            }
            mainPane.getChildren().add(ui1);
            setEnable();
            stockButton.setDisable(true);
            closeNotifications();
        } catch (IOException ex) {
            Logger.getLogger(DashController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void openSupplier(ActionEvent actionEvent) {
        try {
            Node ui1 = FXMLLoader.load(this.getClass().getResource("../view/SupplierPage.fxml"));

            if (!mainPane.getChildren().isEmpty()) {
                mainPane.getChildren().remove(0);
            }
            mainPane.getChildren().add(ui1);
            setEnable();
            supplierButton.setDisable(true);
            closeNotifications();
        } catch (IOException ex) {
            Logger.getLogger(DashController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
