package lk.ijse.dbconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private Connection conn;
    private static DBConnection db;

    private DBConnection()throws ClassNotFoundException, SQLException{
        Class.forName("com.mysql.jdbc.Driver");
        conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/fish","root","Tharindu@123");
    }

    public static DBConnection getInstance() throws ClassNotFoundException, SQLException {
        if(db==null){
            db=new DBConnection();
        }
        return db;
    }

    public Connection getConnection() {
        return conn;
    }
}
