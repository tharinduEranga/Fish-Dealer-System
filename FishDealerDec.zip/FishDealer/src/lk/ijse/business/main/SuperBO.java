package lk.ijse.business.main;

public interface SuperBO {

}
