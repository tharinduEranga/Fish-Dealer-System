package lk.ijse.business.main;


import lk.ijse.business.impl.*;

public class BOFactory {
    public enum BOTypes{
        CUSTOMER, ITEM, ORDER, ORDERDETAIL, STOCK, SUPPLIER, PAYMENT, QUOTATION, MARKET, QUERY, DUESTOCK, PRIORITY, LOGIN
    }

    private static BOFactory boFactory;

    private BOFactory(){

    }

    public static BOFactory getInstance(){
        if (boFactory == null){
            boFactory = new BOFactory();
        }
        return boFactory;
    }

    public <T> T getBO(BOTypes boType){
        switch(boType){
            case CUSTOMER:
                return (T) new CustomerBOimpl();
            case ITEM:
                return (T) new ItemBOimpl();
            case ORDER:
                return (T) new CustomerOrderBOimpl();
            case SUPPLIER:
                return (T) new SupplierBOimpl();
            case PAYMENT:
                return (T) new CustomerPaymentBOimpl();
            case MARKET:
                return (T) new MarketBOimpl();
            case STOCK:
                return (T) new StockBOimpl();
            case QUOTATION:
                return (T) new QuotationsBOimpl();
            case ORDERDETAIL:
                return (T) new CustomerOrderDetailsBOimpl();
            case DUESTOCK:
                return (T) new DueStockBOimpl();
            case PRIORITY:
                return (T) new PriorityBOimpl();
            case LOGIN:
                return (T) new LogInBOimpl();
            case QUERY:
                return (T) new QueryBOimpl();
            default:
                return null;
        }
    }
}
