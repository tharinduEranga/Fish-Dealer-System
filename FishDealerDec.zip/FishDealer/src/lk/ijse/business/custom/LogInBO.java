package lk.ijse.business.custom;

import lk.ijse.business.main.SuperBO;
import lk.ijse.dto.LoginDTO;

public interface LogInBO extends SuperBO {

    LoginDTO getLoginData()throws Exception;
}
