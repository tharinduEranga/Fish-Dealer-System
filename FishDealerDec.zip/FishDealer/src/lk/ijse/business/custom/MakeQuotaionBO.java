package lk.ijse.business.custom;

public interface MakeQuotaionBO {
}
