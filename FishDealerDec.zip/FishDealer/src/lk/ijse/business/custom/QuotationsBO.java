package lk.ijse.business.custom;

import javafx.collections.ObservableList;
import lk.ijse.business.main.SuperBO;
import lk.ijse.dto.QuotationsDTO;
import lk.ijse.dto.QuotationsTableDTO;

public interface QuotationsBO extends SuperBO {
    boolean addQuotation(QuotationsDTO quotationsDTO)throws  Exception;

    String getLastQuotationId()throws Exception;

}
