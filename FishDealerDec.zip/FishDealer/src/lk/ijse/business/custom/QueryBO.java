package lk.ijse.business.custom;

import javafx.collections.ObservableList;
import lk.ijse.business.main.SuperBO;
import lk.ijse.dto.*;

import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;

public interface QueryBO extends SuperBO{
    ObservableList<PaymentDTO> getAllPayments()throws Exception;

    ObservableList<QuotationsTableDTO> searchQuotations(String text, String text1)throws Exception;

    ObservableList<String> getNonQuotationCustomers()throws Exception;

    public OrderDTO searchCustomerOrder(String oid)throws Exception;

    public ObservableList<SupplierTableDTO> getSuppliersForTable() throws SQLException, ClassNotFoundException;

    ObservableList<SupplierTableDTO> searchSuppliers(String text, String s) throws Exception;

    ObservableList<OrderDetailsTableDTO> getSelectedOrder(String oid)throws Exception;

    ObservableList<StockTableDTO> getAllStockForTable()throws Exception;

    ObservableList<StockTableDTO> searchStock(String name)throws Exception;

    ObservableList<OrderDTO> getOrdersForTable()throws Exception;

    ObservableList<DueStockTableDTO> getAllDueStocks()throws Exception;

    public ItemTableDTO searchItem(String iid)throws Exception;

    ObservableList<QuotationsTableDTO> getAllQuotations()throws Exception;

    QuotationsDTO loadQuotationPrice(String iid, String cid)throws Exception;

    public ObservableList<ItemTableDTO> getAllItems()throws Exception;

    ObservableList<OrderDTO> searchCustomerOrders(String cid, Date date)throws Exception;

    public ObservableList<OrderDTO> searchSceduleOrders(String cid, Date date) throws Exception;



}
