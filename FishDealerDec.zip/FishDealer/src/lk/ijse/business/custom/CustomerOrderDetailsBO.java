package lk.ijse.business.custom;

import javafx.collections.ObservableList;
import lk.ijse.business.main.SuperBO;
import lk.ijse.dto.CustomerOrderDetailsDTO;
import lk.ijse.dto.OrderDetailsTableDTO;

public interface CustomerOrderDetailsBO extends SuperBO{

    ObservableList<OrderDetailsTableDTO> getOrderDetails()throws Exception;

    boolean updateOrderDetail(double qty, String oid, String itemName)throws Exception;

    ObservableList<CustomerOrderDetailsDTO> searchOrderDetail(String oid)throws Exception;

    boolean addOrderDetails(ObservableList<CustomerOrderDetailsDTO> cdtos)throws Exception;

    double getTotalSoldKg()throws Exception;
}
