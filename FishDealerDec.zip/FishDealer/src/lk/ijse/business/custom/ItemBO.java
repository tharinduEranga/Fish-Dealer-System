package lk.ijse.business.custom;

import lk.ijse.business.main.SuperBO;
import lk.ijse.dto.ItemDTO;
import javafx.collections.ObservableList;
import lk.ijse.dto.ItemTableDTO;

import java.util.ArrayList;

public interface ItemBO extends SuperBO {
    public boolean addItem(ItemDTO item)throws Exception;
    public boolean updateItem(ItemDTO item)throws Exception;
    public boolean deleteItem(String iid)throws Exception;
    public ObservableList<ItemDTO> getAllItemNames()throws Exception;

    ItemDTO searchAnItem(String s)throws Exception;

}
