package lk.ijse.business.custom;

import javafx.collections.ObservableList;
import lk.ijse.business.main.SuperBO;
import lk.ijse.dto.StockDTO;
import lk.ijse.dto.StockTableDTO;

import java.util.ArrayList;

public interface StockBO extends SuperBO {

    String getLastId()throws Exception;

    boolean addStock(StockTableDTO stockTableDTO)throws Exception;

    ArrayList<StockDTO> getAllStocks()throws Exception;

    boolean deleteStock(String stid)throws Exception;


    boolean updateStock(StockDTO stock)throws Exception;

    ArrayList<StockDTO> getSelectedStocks(String itemCode)throws Exception;
}
