package lk.ijse.business.custom;

import lk.ijse.business.main.SuperBO;
import lk.ijse.dto.CustomerDTO;
import javafx.collections.ObservableList;

import java.sql.SQLException;
import java.time.LocalDate;

public interface CustomerBO extends SuperBO {
    public boolean addCustomer(CustomerDTO customer)throws Exception;
    public boolean updateCustomer(CustomerDTO customer)throws Exception;
    public boolean deleteCustomer(String cid)throws Exception;
    public CustomerDTO searchCustomer(String cid)throws Exception;
    public ObservableList<CustomerDTO> getAllCustomers()throws Exception;

    public String getLastCustomerId() throws SQLException, ClassNotFoundException;

    ObservableList<CustomerDTO> searchCustomers(String text, String value) throws SQLException, ClassNotFoundException;

}
