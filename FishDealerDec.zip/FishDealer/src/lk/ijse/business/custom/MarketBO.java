package lk.ijse.business.custom;

import javafx.collections.ObservableList;
import lk.ijse.business.main.SuperBO;
import lk.ijse.dto.MarketDTO;
import lk.ijse.entity.Market;

public interface MarketBO extends SuperBO {
    public ObservableList<MarketDTO>getMarkets()throws Exception;

    String getLastId()throws Exception;

    boolean addMarket(MarketDTO marketDTO)throws Exception;

    MarketDTO searchMarket(String s)throws Exception;
}
