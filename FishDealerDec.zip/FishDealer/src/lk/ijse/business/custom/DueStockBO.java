package lk.ijse.business.custom;

import javafx.collections.ObservableList;
import lk.ijse.business.main.SuperBO;
import lk.ijse.dto.DueStockDTO;
import lk.ijse.dto.DueStockTableDTO;

public interface DueStockBO extends SuperBO {
    boolean addNew(DueStockDTO iid)throws Exception;

    String getLastId()throws Exception;

    boolean deleteDue(String iid)throws Exception;

    boolean updateQty(String iid,double v)throws Exception;
}
