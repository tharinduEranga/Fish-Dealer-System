package lk.ijse.business.custom;

import javafx.collections.ObservableList;
import lk.ijse.business.main.SuperBO;
import lk.ijse.dto.CustomerDTO;
import lk.ijse.dto.OrderDTO;
import lk.ijse.dto.OrderDetailsTableDTO;
import lk.ijse.entity.Customer;

import java.sql.Date;
import java.util.ArrayList;

public interface CustomerOrderBO extends SuperBO {
    public boolean addCustomerOrder(OrderDTO orderDTO)throws Exception;
    public boolean updateCustomerOrder(Customer customer)throws Exception;
    public boolean deleteCustomerOrder(OrderDTO od)throws Exception;
    public ArrayList<OrderDTO> getAllCustomerOrders()throws Exception;
    public String getLastOrderId()throws Exception;



    ObservableList<OrderDTO> getShcheduled()throws Exception;

    ObservableList<OrderDTO> getPlaced()throws Exception;

    boolean addScheduleOrder(OrderDTO order)throws Exception;

    int getOrderCount()throws Exception;

    OrderDTO searchOrder(String oid)throws Exception;
}
