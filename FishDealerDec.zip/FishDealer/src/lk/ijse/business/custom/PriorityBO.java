package lk.ijse.business.custom;

import javafx.collections.ObservableList;
import lk.ijse.business.main.SuperBO;
import lk.ijse.dto.PriorityDTO;

public interface PriorityBO extends SuperBO {

    ObservableList<PriorityDTO> getAll()throws Exception;

    String searchPriority(String pname)throws Exception;
}
