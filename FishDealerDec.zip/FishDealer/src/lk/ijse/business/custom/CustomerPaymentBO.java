package lk.ijse.business.custom;

import javafx.collections.ObservableList;
import lk.ijse.business.main.SuperBO;
import lk.ijse.dto.PaymentDTO;

public interface CustomerPaymentBO extends SuperBO {
    boolean addPayment(PaymentDTO c)throws Exception;

    String getLastId()throws Exception;

    PaymentDTO searchPayment(String oid)throws Exception;

    ObservableList<PaymentDTO> getAllPayments()throws Exception;

    double getPaymentTotal()throws Exception;
}
