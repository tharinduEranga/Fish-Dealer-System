package lk.ijse.business.custom;

import lk.ijse.business.main.SuperBO;
import lk.ijse.dto.SupplierDTO;
import lk.ijse.dto.SupplierTableDTO;
import javafx.collections.ObservableList;

import java.sql.SQLException;

public interface SupplierBO extends SuperBO {
    public ObservableList<SupplierDTO> getAllSuppliers() throws Exception;

    SupplierDTO searchSupplier(String s)throws Exception;

    String getLastSupplierId()throws Exception;

    boolean addSupplier(SupplierDTO supplierDTO)throws Exception;
}
