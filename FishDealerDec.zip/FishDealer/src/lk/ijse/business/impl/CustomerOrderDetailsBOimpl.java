package lk.ijse.business.impl;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import lk.ijse.business.custom.CustomerOrderDetailsBO;
import lk.ijse.dao.custom.CustomerOrderDetailsDAO;
import lk.ijse.dao.custom.QueryDAO;
import lk.ijse.dao.main.DAOFactory;
import lk.ijse.dto.CustomerOrderDetailsDTO;
import lk.ijse.dto.OrderDetailsTableDTO;
import lk.ijse.entity.CustomEntity;
import lk.ijse.entity.CustomerOrderDetails;

public class CustomerOrderDetailsBOimpl implements CustomerOrderDetailsBO{
    private CustomerOrderDetailsDAO customerOrderDetailsDAO;
    private QueryDAO queryDAO;
    public CustomerOrderDetailsBOimpl() {
        this.customerOrderDetailsDAO = DAOFactory.getInstance().getDAO(DAOFactory.DAOTypes.ORDERDETAIL);
        this.queryDAO= DAOFactory.getInstance().getDAO(DAOFactory.DAOTypes.QUERY);
    }

    @Override
    public ObservableList<OrderDetailsTableDTO> getOrderDetails() throws Exception {
        ObservableList<CustomEntity>od=customerOrderDetailsDAO.getAllOrderDetails();
        ObservableList<OrderDetailsTableDTO>orderDetails= FXCollections.observableArrayList();
        for (CustomEntity c:od) {
            orderDetails.add(new OrderDetailsTableDTO(c.getCustOid(),c.getCustName(),c.getItemName(),c.getItemQty(),c.getPrice()));
        }
        return orderDetails;
    }

    @Override
    public boolean updateOrderDetail(double qty, String oid, String itemName) throws Exception {
        return customerOrderDetailsDAO.updateDetail(qty, oid, itemName);
    }

    @Override
    public ObservableList<CustomerOrderDetailsDTO> searchOrderDetail(String oid) throws Exception {
        ObservableList<CustomerOrderDetails>orderDetail=customerOrderDetailsDAO.getOrderDetail(oid);
        ObservableList<CustomerOrderDetailsDTO>orderDetails=FXCollections.observableArrayList();
        for (CustomerOrderDetails c:orderDetail) {
            orderDetails.add(new CustomerOrderDetailsDTO(c.getQty(), c.getUnitPrice(), c.getOd_pk().getOid(), "",c.getOd_pk().getIid()));
        }
        return orderDetails;
    }

    @Override
    public boolean addOrderDetails(ObservableList<CustomerOrderDetailsDTO> c) throws Exception {
        for (CustomerOrderDetailsDTO cd:c) {
            boolean isAdded=customerOrderDetailsDAO.addOcrderDetails(new CustomerOrderDetails(cd.getOid(), cd.getQty(), cd.getUnitPrice(), cd.getItemCode()));
            if(!isAdded){
                return false;
            }
        }
        return true;
    }

    @Override
    public double getTotalSoldKg() throws Exception {
        return customerOrderDetailsDAO.getTotalSoldKg();
    }
}
