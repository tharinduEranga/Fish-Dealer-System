package lk.ijse.business.impl;

import lk.ijse.business.custom.SupplierBO;
import lk.ijse.dao.custom.QueryDAO;
import lk.ijse.dao.custom.SupplierDAO;
import lk.ijse.dao.main.DAOFactory;
import lk.ijse.dto.SupplierDTO;
import lk.ijse.dto.SupplierTableDTO;
import lk.ijse.entity.CustomEntity;
import lk.ijse.entity.Supplier;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.SQLException;

public class SupplierBOimpl implements SupplierBO{
    private SupplierDAO supplierDAO;
    private QueryDAO queryDAO;
    public SupplierBOimpl(){
        this.supplierDAO= DAOFactory.getInstance().getDAO(DAOFactory.DAOTypes.SUPPLIER);
        this.queryDAO=DAOFactory.getInstance().getDAO(DAOFactory.DAOTypes.QUERY);
    }
    @Override
    public ObservableList<SupplierDTO> getAllSuppliers() throws Exception{
        ObservableList<Supplier>suppliers=supplierDAO.getAllSuppliers();
        ObservableList<SupplierDTO>supplierList= FXCollections.observableArrayList();
        for (Supplier s:suppliers) {
            supplierList.add(new SupplierDTO(s.getId(),s.getName(),s.getMid(),s.getTel()));
        }
        return supplierList;
    }

    @Override
    public SupplierDTO searchSupplier(String name) throws Exception {
        Supplier s=supplierDAO.searchSupplier(name);
        return new SupplierDTO(s.getId(),s.getName(),s.getMid(),s.getTel());
    }

    @Override
    public String getLastSupplierId() throws Exception {
        return supplierDAO.getLastId();
    }

    @Override
    public boolean addSupplier(SupplierDTO s) throws Exception {
        return supplierDAO.addSupplier(new Supplier(s.getId(), s.getName(), s.getMid(), s.getTel()));
    }
}
