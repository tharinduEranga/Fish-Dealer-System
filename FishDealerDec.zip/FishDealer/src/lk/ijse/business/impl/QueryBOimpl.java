package lk.ijse.business.impl;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import lk.ijse.business.custom.QueryBO;
import lk.ijse.dao.custom.QueryDAO;
import lk.ijse.dao.main.DAOFactory;
import lk.ijse.dto.*;
import lk.ijse.entity.CustomEntity;
import lk.ijse.entity.CustomerOrder;
import lk.ijse.entity.Quotations;

import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;

public class QueryBOimpl implements QueryBO {
    QueryDAO queryDAO ;

    public QueryBOimpl() {
        this.queryDAO = DAOFactory.getInstance().getDAO(DAOFactory.DAOTypes.QUERY);
    }

    @Override
    public ObservableList<PaymentDTO> getAllPayments() throws Exception {
        ObservableList<CustomEntity>payments=queryDAO.getAllPayments();
        ObservableList<PaymentDTO>paymentDTOS= FXCollections.observableArrayList();
        for (CustomEntity c:payments) {
            paymentDTOS.add(new PaymentDTO(c.getPid(), c.getCustOrderDate(), c.getPrice(), c.getCustName()));
        }return paymentDTOS;
    }

    @Override
    public ObservableList<QuotationsTableDTO> searchQuotations(String cu, String fi) throws Exception {
        ObservableList<QuotationsTableDTO>quotationsTableDTOS=FXCollections.observableArrayList();
        ObservableList<CustomEntity>searchQuot=queryDAO.searchQuotations(cu, fi);
        for (CustomEntity c:searchQuot) {
            quotationsTableDTOS.add(new QuotationsTableDTO(c.getCustName(), c.getItemName(), c.getPrice()));
        }
        return quotationsTableDTOS;
    }

    @Override
    public ObservableList<String> getNonQuotationCustomers() throws Exception {
        return queryDAO.getNonQuoCustomers();
    }
    @Override
    public OrderDTO searchCustomerOrder(String oid) throws Exception {
        CustomEntity o=queryDAO.searchOrderToPay(oid);
        OrderDTO od=new OrderDTO(o.getCustName(),o.getCustOrderDate(),o.getPrice());
        if(od!=null) {
            return od;
        }else
            return null;
    }

    @Override
    public ItemTableDTO searchItem(String name) throws Exception {
        CustomEntity ce=queryDAO.getItem(name);
        if(ce!=null) {
            return new ItemTableDTO(ce.getItemId(), ce.getItemName(), ce.getItemQty());
        }else
            return null;
    }

    @Override
    public ObservableList<QuotationsTableDTO> getAllQuotations() throws Exception {
        ObservableList<CustomEntity>q=queryDAO.getAllQuotations();
        ObservableList<QuotationsTableDTO>qo= FXCollections.observableArrayList();
        for (CustomEntity cq:q) {
            qo.add(new QuotationsTableDTO(cq.getCustName(),cq.getItemName(),cq.getPrice()));
        }
        return qo;
    }

    @Override
    public ObservableList<StockTableDTO> getAllStockForTable() throws Exception {
        ObservableList<CustomEntity>stock=queryDAO.getStockForTable();
        ObservableList<StockTableDTO>stocks= FXCollections.observableArrayList();
        for (CustomEntity c:stock) {
            stocks.add(new StockTableDTO(c.getItemId(),c.getItemName(),c.getItemQty(),c.getPrice(),c.getSupplierName(),c.getStockDate()));
        }
        return stocks;
    }

    @Override
    public ObservableList<SupplierTableDTO> getSuppliersForTable() throws SQLException, ClassNotFoundException {
        ObservableList<CustomEntity>suppliers=queryDAO.getSuppliersWithMarket();
        ObservableList<SupplierTableDTO>supplierTableDTOS=FXCollections.observableArrayList();
        for (CustomEntity c:suppliers) {
            supplierTableDTOS.add(new SupplierTableDTO(c.getSupplierName(),c.getMarketName(),c.getSupplierTel()));
        }
        return supplierTableDTOS;
    }

    @Override
    public ObservableList<SupplierTableDTO> searchSuppliers(String text, String s) throws Exception{
        ObservableList<CustomEntity>suppliers=queryDAO.searchSuppliers(text, s);
        ObservableList<SupplierTableDTO>supplierTableDTOS=FXCollections.observableArrayList();
        for (CustomEntity c:suppliers) {
            supplierTableDTOS.add(new SupplierTableDTO(c.getSupplierName(),
                    c.getMarketName(),
                    c.getSupplierTel()));
        }
        return supplierTableDTOS;
    }

    @Override
    public ObservableList<StockTableDTO> searchStock(String name) throws Exception {
        ObservableList<CustomEntity>stock=queryDAO.searchStock(name);
        ObservableList<StockTableDTO>stocks= FXCollections.observableArrayList();
        for (CustomEntity c:stock) {
            stocks.add(new StockTableDTO(c.getItemId(),c.getItemName(),c.getItemQty(),c.getPrice(),c.getSupplierName(),c.getStockDate()));
        }
        return stocks;
    }

    @Override
    public QuotationsDTO loadQuotationPrice(String iid, String cid) throws Exception {
        Quotations q=queryDAO.getQuotationPrice(cid, iid);
        if(q!=null) {
            return new QuotationsDTO(q.getQid(), q.getCid(), q.getIid(), q.getPrice());
        }else
            return null;
    }

    @Override
    public ObservableList<ItemTableDTO> getAllItems() throws Exception {
        ObservableList<CustomEntity>items=queryDAO.getAllItemsWithQty();
        ObservableList<ItemTableDTO>itemTableDTOS=FXCollections.observableArrayList();
        for (CustomEntity c: items) {
            itemTableDTOS.add(new ItemTableDTO(c.getItemId(),c.getItemName(),c.getItemQty()));
        }
        return itemTableDTOS;
    }

    @Override
    public ObservableList<DueStockTableDTO> getAllDueStocks() throws Exception {
        ObservableList<CustomEntity>ds=queryDAO.getDueStocks();
        ObservableList<DueStockTableDTO>dueStocks= FXCollections.observableArrayList();
        for (CustomEntity c: ds) {
            dueStocks.add(new DueStockTableDTO(c.getItemName(),c.getItemQty()));
        }
        return dueStocks;
    }

    @Override
    public ObservableList<OrderDetailsTableDTO> getSelectedOrder(String oid) throws Exception {
        ObservableList<CustomEntity>orderDetail=queryDAO.getOrderDetail(oid);
        ObservableList<OrderDetailsTableDTO>orderDetails=FXCollections.observableArrayList();
        for (CustomEntity c:orderDetail) {
            orderDetails.add(new OrderDetailsTableDTO(c.getItemName(),c.getItemQty(),c.getPrice()));
        }
        return orderDetails;
    }

    @Override
    public ObservableList<OrderDTO> getOrdersForTable() throws Exception {
        ObservableList<CustomEntity>orders=queryDAO.getOrdersForTable();
        ObservableList<OrderDTO>order= FXCollections.observableArrayList();
        for (CustomEntity c:orders) {
            order.add(new OrderDTO(c.getCustOid(),c.getCustName(),c.getOrderDate(),c.getPrice(),c.getPriority()));
        }
        return order;
    }

    @Override
    public ObservableList<OrderDTO> searchCustomerOrders(String cid, Date date) throws Exception {
        ObservableList<CustomEntity>cs=queryDAO.searchOrders(cid,date);
        ObservableList<OrderDTO>orders=FXCollections.observableArrayList();
        for (CustomEntity c:cs) {
            orders.add(new OrderDTO(c.getCustOid(),c.getCustName(),c.getOrderDate(),c.getPrice(),c.getPriority()));
        }
        return orders;
    }

    @Override
    public ObservableList<OrderDTO> searchSceduleOrders(String cid, Date date) throws Exception {
        ObservableList<CustomEntity>cs=queryDAO.searchSceduledOrders(cid,date);
        ObservableList<OrderDTO>orders=FXCollections.observableArrayList();
        for (CustomEntity c:cs) {
            orders.add(new OrderDTO(c.getCustOid(),c.getCustName(),c.getOrderDate(),c.getPrice(),c.getPriority()));
        }
        return orders;
    }
}
