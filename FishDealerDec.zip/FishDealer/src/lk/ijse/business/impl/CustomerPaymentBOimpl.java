package lk.ijse.business.impl;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import lk.ijse.business.custom.CustomerPaymentBO;
import lk.ijse.dao.custom.CustomerPaymentDAO;
import lk.ijse.dao.main.DAOFactory;
import lk.ijse.dto.PaymentDTO;
import lk.ijse.entity.CustomerPayment;

import java.sql.Date;

public class CustomerPaymentBOimpl implements CustomerPaymentBO{
    CustomerPaymentDAO customerPaymentDAO;

    public CustomerPaymentBOimpl() {
        this.customerPaymentDAO = DAOFactory.getInstance().getDAO(DAOFactory.DAOTypes.PAYMENT);
    }

    @Override
    public boolean addPayment(PaymentDTO c) throws Exception {
        CustomerPayment cp=new CustomerPayment(c.getPid(),c.getOid(),c.getDate(),c.getAmount());
        return customerPaymentDAO.addPayment(cp);
    }

    @Override
    public String getLastId() throws Exception {
        return customerPaymentDAO.getLastId();
    }

    @Override
    public PaymentDTO searchPayment(String oid) throws Exception {
        CustomerPayment cp=customerPaymentDAO.searchPaymrnt(oid);
        if(cp!=null){
            return new PaymentDTO(cp.getPid(), cp.getOid(), cp.getDate(), cp.getAmount());
        }else
            return null;
    }

    @Override
    public ObservableList<PaymentDTO> getAllPayments() throws Exception {
        ObservableList<CustomerPayment>pm=customerPaymentDAO.getAllPayments();
        ObservableList<PaymentDTO>payments=FXCollections.observableArrayList();
        for (CustomerPayment p:pm) {
            payments.add(new PaymentDTO(p.getPid(), p.getOid(), p.getDate(), p.getAmount()));
        }
        return payments;
    }

    @Override
    public double getPaymentTotal() throws Exception {
        return customerPaymentDAO.getTotalOfAllPayments();
    }
}
