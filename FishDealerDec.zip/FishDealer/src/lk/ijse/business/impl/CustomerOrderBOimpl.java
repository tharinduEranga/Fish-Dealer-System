package lk.ijse.business.impl;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import lk.ijse.business.custom.CustomerOrderBO;
import lk.ijse.dao.custom.*;
import lk.ijse.dao.main.DAOFactory;
import lk.ijse.dbconnection.DBConnection;
import lk.ijse.dto.CustomerDTO;
import lk.ijse.dto.OrderDTO;
import lk.ijse.dto.CustomerOrderDetailsDTO;
import lk.ijse.dto.OrderDetailsTableDTO;
import lk.ijse.entity.*;

import java.sql.Connection;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;

public class CustomerOrderBOimpl implements CustomerOrderBO{

    private static CustomerOrderDAO orderDAO;
    private static CustomerOrderDetailsDAO orderDetailsDAO;
    private static ItemDAO itemDAO;
    private static StockDAO stockDAO;
    private static QueryDAO queryDAO;
    public CustomerOrderBOimpl(){

        this.orderDAO = DAOFactory.getInstance().getDAO(DAOFactory.DAOTypes.ORDER);
        this.orderDetailsDAO = DAOFactory.getInstance().getDAO(DAOFactory.DAOTypes.ORDERDETAIL);
        this.itemDAO = DAOFactory.getInstance().getDAO(DAOFactory.DAOTypes.ITEM);
        this.stockDAO=DAOFactory.getInstance().getDAO(DAOFactory.DAOTypes.STOCK);
        this.queryDAO=DAOFactory.getInstance().getDAO(DAOFactory.DAOTypes.QUERY);
    }
    @Override
    public boolean addCustomerOrder(OrderDTO orderDTO) throws Exception {
        Connection conn=DBConnection.getInstance().getConnection();
        conn.setAutoCommit(false);
        try{
            CustomerOrder order=new CustomerOrder(orderDTO.getOid(),orderDTO.getDate(),orderDTO.getCid(),orderDTO.getPriority(),orderDTO.getPrice());
            boolean isAdded=orderDAO.addOrder(order);
            if(!isAdded){
                return false;
            }
            ArrayList<CustomerOrderDetailsDTO>orderDetails=orderDTO.getOrderDetils();
            for (CustomerOrderDetailsDTO cod:orderDetails) {
                isAdded=orderDetailsDAO.addOcrderDetails(new CustomerOrderDetails(cod.getOid(),cod.getQty(),cod.getUnitPrice(),cod.getItemCode()));
                if(!isAdded){
                    conn.rollback();
                    return false;
                }
                ArrayList<Stock>stocks=stockDAO.getSelectedStocks(cod.getItemCode());
                double qty=cod.getQty();
                F1:for (Stock stock: stocks) {
                    if(qty>stock.getQty()){
                        qty=qty-stock.getQty();
                        stock.setQty(0);
                    }else {
                        stock.setQty(stock.getQty()-qty);
                        qty=0;
                    }
                    isAdded=stockDAO.updateStock(stock);
                }
                if (!isAdded) {
                    conn.rollback();
                    return false;
                }
            }
            conn.commit();
            return true;
        }catch (Exception e){
            conn.rollback();
            e.printStackTrace();
            return false;
        }finally {
            conn.setAutoCommit(true);
        }
    }

    @Override
    public boolean updateCustomerOrder(Customer customer) throws Exception {
        return false;
    }

    @Override
    public boolean deleteCustomerOrder(OrderDTO od) throws Exception {
        return orderDAO.deleteOrder(od.getOid());
    }

    @Override
    public ArrayList<OrderDTO> getAllCustomerOrders() throws Exception {
        ArrayList<CustomerOrder> o= orderDAO.getAllOrders();
        ArrayList<OrderDTO>orders=new ArrayList<>();
        for (CustomerOrder or:o) {
            orders.add(new OrderDTO(or.getOid(), or.getDate(), or.getPriority(), or.getCid(), or.getPrice()));
        }return orders;

    }
    @Override
    public String getLastOrderId() throws Exception{
        return orderDAO.getLastOrderId();
    }

    @Override
    public boolean addScheduleOrder(OrderDTO orderDTO) throws Exception {
        Connection conn=DBConnection.getInstance().getConnection();
        conn.setAutoCommit(false);
        try{
            CustomerOrder order=new CustomerOrder(orderDTO.getOid(),orderDTO.getDate(),orderDTO.getCid(),orderDTO.getPriority(),orderDTO.getPrice());
            boolean isAdded=orderDAO.addOrder(order);
            if(!isAdded){
                return false;
            }
            ArrayList<CustomerOrderDetailsDTO>orderDetails=orderDTO.getOrderDetils();
            for (CustomerOrderDetailsDTO cod:orderDetails) {
                isAdded=orderDetailsDAO.addOcrderDetails(new CustomerOrderDetails(cod.getOid(),cod.getQty(),cod.getUnitPrice(),cod.getItemCode()));
                if(!isAdded){
                    conn.rollback();
                    return false;
                }
            }
            conn.commit();
            return true;
        }catch (Exception e){
            conn.rollback();
            e.printStackTrace();
            return false;
        }finally {
            conn.setAutoCommit(true);
        }
    }

    @Override
    public int getOrderCount() throws Exception {
        return orderDAO.getOrdersCount();
    }

    @Override
    public OrderDTO searchOrder(String oid) throws Exception {
        CustomerOrder co=orderDAO.searchOrder(oid);
        return new OrderDTO(co.getOid(), co.getDate(), co.getPriority(), co.getCid(), co.getPrice());
    }

    @Override
    public ObservableList<OrderDTO> getShcheduled() throws Exception {
        ObservableList<CustomEntity>so=queryDAO.getScheduledOrders();
        ObservableList<OrderDTO>sord=FXCollections.observableArrayList();
        for (CustomEntity c:so) {
            sord.add(new OrderDTO(c.getCustOid(),c.getCustName(),c.getOrderDate(),c.getPrice(),c.getPriority()));
        }
        return sord;
    }

    @Override
    public ObservableList<OrderDTO> getPlaced() throws Exception {
        ObservableList<CustomEntity>so=queryDAO.getPlacedOrders();
        ObservableList<OrderDTO>sord=FXCollections.observableArrayList();
        for (CustomEntity c:so) {
            sord.add(new OrderDTO(c.getCustOid(),c.getCustName(),c.getOrderDate(),c.getPrice(),c.getPriority()));
        }
        return sord;
    }

}
