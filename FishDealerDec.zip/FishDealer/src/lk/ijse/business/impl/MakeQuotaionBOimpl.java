package lk.ijse.business.impl;

import lk.ijse.business.custom.MakeQuotaionBO;

public class MakeQuotaionBOimpl implements MakeQuotaionBO{

}
