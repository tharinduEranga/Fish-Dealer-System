package lk.ijse.business.impl;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import lk.ijse.business.custom.MarketBO;
import lk.ijse.dao.custom.MarketDAO;
import lk.ijse.dao.main.DAOFactory;
import lk.ijse.dto.MarketDTO;
import lk.ijse.entity.Market;

public class MarketBOimpl implements MarketBO{
    MarketDAO marketDAO;

    public MarketBOimpl() {
        this.marketDAO = DAOFactory.getInstance().getDAO(DAOFactory.DAOTypes.MARKET);
    }

    @Override
    public ObservableList<MarketDTO> getMarkets() throws Exception {
        ObservableList<Market>ma=marketDAO.geAllMarkets();
        ObservableList<MarketDTO>marketDTOS= FXCollections.observableArrayList();
        for (Market m:ma) {
            marketDTOS.add(new MarketDTO(m.getMid(),m.getMname()));
        }
        return marketDTOS;
    }

    @Override
    public String getLastId() throws Exception {
        return marketDAO.getLastId();
    }

    @Override
    public boolean addMarket(MarketDTO m) throws Exception {
        Market market=new Market(m.getMid(),m.getMname(),m.getAddress());
        return marketDAO.addMarket(market);
    }

    @Override
    public MarketDTO searchMarket(String s) throws Exception {
        Market m=marketDAO.searchMarket(s);
        if(m!=null){
            return new MarketDTO(m.getMid(), m.getMname(), m.getAddress());
        }else
            return null;
    }
}
