package lk.ijse.business.impl;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import lk.ijse.business.custom.PriorityBO;
import lk.ijse.dao.custom.PriorityDAO;
import lk.ijse.dao.main.DAOFactory;
import lk.ijse.dto.PriorityDTO;
import lk.ijse.entity.Priority;

public class PriorityBOimpl implements PriorityBO {
    private PriorityDAO priorityDAO;

    public PriorityBOimpl() {
        this.priorityDAO = DAOFactory.getInstance().getDAO(DAOFactory.DAOTypes.PRIORITY);
    }

    @Override
    public ObservableList<PriorityDTO> getAll() throws Exception {
        ObservableList<Priority>priorities=priorityDAO.getAll();
        ObservableList<PriorityDTO>priorityDTOS= FXCollections.observableArrayList();
        for (Priority p:priorities) {
            priorityDTOS.add(new PriorityDTO(p.getPid(),p.getType()));
        }
        return priorityDTOS;
    }

    @Override
    public String searchPriority(String pname) throws Exception {
        return priorityDAO.searchPriority(pname);
    }
}
