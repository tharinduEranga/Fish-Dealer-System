package lk.ijse.business.impl;

import lk.ijse.business.custom.ItemBO;
import lk.ijse.dao.custom.ItemDAO;
import lk.ijse.dao.custom.QueryDAO;
import lk.ijse.dao.main.DAOFactory;
import lk.ijse.dto.ItemDTO;
import lk.ijse.dto.ItemTableDTO;
import lk.ijse.entity.CustomEntity;
import lk.ijse.entity.Item;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.ArrayList;

public class ItemBOimpl implements ItemBO{

    private ItemDAO itemDAO;
    private QueryDAO queryDAO;
    public ItemBOimpl(){
        this.queryDAO=DAOFactory.getInstance().getDAO(DAOFactory.DAOTypes.QUERY);
        this.itemDAO = DAOFactory.getInstance().getDAO(DAOFactory.DAOTypes.ITEM);
    }
    @Override
    public boolean addItem(ItemDTO item) throws Exception {
        return false;
    }

    @Override
    public boolean updateItem(ItemDTO item) throws Exception {
        return false;
    }

    @Override
    public boolean deleteItem(String iid) throws Exception {
        return false;
    }


    @Override
    public ObservableList<ItemDTO> getAllItemNames() throws Exception {
        ObservableList<Item>items= itemDAO.getItemNames();
        ObservableList<ItemDTO>itemdtos= FXCollections.observableArrayList();
        for (Item i:items) {
            itemdtos.add(new ItemDTO(i.getIid(),i.getName()));
        }
        return itemdtos;
    }

    @Override
    public ItemDTO searchAnItem(String s) throws Exception {
        Item i=itemDAO.getItem(s);
        ItemDTO itemDTO=new ItemDTO(i.getIid(),i.getName());
        return itemDTO;
    }
}
