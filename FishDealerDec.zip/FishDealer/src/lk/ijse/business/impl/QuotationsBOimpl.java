package lk.ijse.business.impl;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import lk.ijse.business.custom.QuotationsBO;
import lk.ijse.dao.custom.QueryDAO;
import lk.ijse.dao.custom.QuotationsDAO;
import lk.ijse.dao.main.DAOFactory;
import lk.ijse.dto.QuotationsDTO;
import lk.ijse.dto.QuotationsTableDTO;
import lk.ijse.entity.CustomEntity;
import lk.ijse.entity.Quotations;

public class QuotationsBOimpl implements QuotationsBO{
    QuotationsDAO quotationsDAO;
    QueryDAO queryDAO;
    public QuotationsBOimpl() {
        this.quotationsDAO = DAOFactory.getInstance().getDAO(DAOFactory.DAOTypes.QUOTATION);
        this.queryDAO = DAOFactory.getInstance().getDAO(DAOFactory.DAOTypes.QUERY);
    }

    @Override
    public boolean addQuotation(QuotationsDTO qDTO) throws Exception {
        Quotations quotations=new Quotations(qDTO.getQid(),qDTO.getPrice(),qDTO.getCid(),qDTO.getIid());
        return quotationsDAO.addQuotation(quotations);
    }

    @Override
    public String getLastQuotationId() throws Exception {
        return quotationsDAO.getLastId();
    }

}
