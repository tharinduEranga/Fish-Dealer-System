package lk.ijse.business.impl;

import lk.ijse.business.custom.LogInBO;
import lk.ijse.dao.custom.LoginDAO;
import lk.ijse.dao.main.DAOFactory;
import lk.ijse.dto.LoginDTO;
import lk.ijse.entity.Login;

public class LogInBOimpl implements LogInBO {
    LoginDAO loginDAO;

    public LogInBOimpl() {
        this.loginDAO = DAOFactory.getInstance().getDAO(DAOFactory.DAOTypes.LOGIN);
    }

    @Override
    public LoginDTO getLoginData() throws Exception {
        Login lg=loginDAO.getLogin();
        return new LoginDTO(lg.getUserName(), lg.getPassword());
    }
}
