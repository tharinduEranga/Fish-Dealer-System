package lk.ijse.business.impl;

import lk.ijse.business.custom.CustomerBO;
import lk.ijse.dao.custom.QueryDAO;
import lk.ijse.dao.impl.CustomerDAOimpl;
import lk.ijse.dao.custom.CustomerDAO;
import lk.ijse.dao.main.DAOFactory;
import lk.ijse.dto.CustomerDTO;
import lk.ijse.entity.CustomEntity;
import lk.ijse.entity.Customer;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.SQLException;
import java.time.LocalDate;

public class CustomerBOimpl implements CustomerBO {
    private CustomerDAO customerDAO;
    private QueryDAO queryDAO;
    public CustomerBOimpl(){
        this.queryDAO= DAOFactory.getInstance().getDAO(DAOFactory.DAOTypes.QUERY);
        this.customerDAO = DAOFactory.getInstance().getDAO(DAOFactory.DAOTypes.CUSTOMER);
    }

    public boolean addCustomer(CustomerDTO cdto) throws SQLException, ClassNotFoundException {
        Customer c=new Customer(cdto.getCid(),cdto.getName(),cdto.getAddress(),cdto.getTel(),cdto.getDate());
        return customerDAO.addCustomer(c);
    }

    @Override
    public boolean updateCustomer(CustomerDTO c) throws Exception {
        Customer customer=new Customer(c.getCid(),c.getName(),c.getAddress(),c.getTel(),c.getDate());
        return customerDAO.updateCustomer(customer);
    }

    @Override
    public boolean deleteCustomer(String cid) throws Exception {
        return customerDAO.deleteCustomer(cid);
    }

    @Override
    public CustomerDTO searchCustomer(String cid) throws Exception {
        Customer c=customerDAO.searchCustomer(cid);
        if(c!=null) {
            return new CustomerDTO(c.getCid(), c.getName(), c.getAddress(), c.getTel(), c.getDate());
        }else
            return null;
    }

    @Override
    public ObservableList<CustomerDTO> getAllCustomers() throws Exception {
        ObservableList<Customer>customers=customerDAO.getCustomerNames();
        ObservableList<CustomerDTO>customerDTOS= FXCollections.observableArrayList();
        for (Customer c: customers) {
            customerDTOS.add(new CustomerDTO(c.getCid(),c.getName(),c.getAddress(),c.getTel(),c.getDate()));
        }
        return customerDTOS;
    }

    @Override
    public String getLastCustomerId() throws SQLException, ClassNotFoundException {
        return customerDAO.getLastCustomerId();
    }

    @Override
    public ObservableList<CustomerDTO> searchCustomers(String text, String date) throws SQLException, ClassNotFoundException {
        ObservableList<Customer>customers=customerDAO.searchCustomers(text, date);
        ObservableList<CustomerDTO>customer=FXCollections.observableArrayList();
        for (Customer c:customers) {
            customer.add(new CustomerDTO(c.getCid(),c.getName(),c.getAddress(),c.getTel(),c.getDate()));
        }
        return customer;
    }




}
