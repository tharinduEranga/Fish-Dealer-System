package lk.ijse.business.impl;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import lk.ijse.business.custom.StockBO;
import lk.ijse.dao.custom.QueryDAO;
import lk.ijse.dao.custom.StockDAO;
import lk.ijse.dao.main.DAOFactory;
import lk.ijse.dto.StockDTO;
import lk.ijse.dto.StockTableDTO;
import lk.ijse.entity.CustomEntity;
import lk.ijse.entity.Stock;

import java.util.ArrayList;

public class  StockBOimpl implements StockBO{
    QueryDAO queryDAO;
    StockDAO stockDAO;
    public StockBOimpl() {
        this.stockDAO= DAOFactory.getInstance().getDAO(DAOFactory.DAOTypes.STOCK);
        this.queryDAO = DAOFactory.getInstance().getDAO(DAOFactory.DAOTypes.QUERY);
    }


    @Override
    public String getLastId() throws Exception {
        return stockDAO.getLastId();
    }

    @Override
    public boolean addStock(StockTableDTO s) throws Exception {
        Stock stock=new Stock(s.getStid(),s.getIid(),s.getItemQty(),s.getStockDate(),s.getSid(),s.getPrice());
        return stockDAO.addStock(stock);
    }

    @Override
    public ArrayList<StockDTO> getAllStocks() throws Exception {
        ArrayList<Stock>stock=stockDAO.getAllStocks();
        ArrayList<StockDTO>stocks= new ArrayList<>();
        for (Stock s:stock) {
            stocks.add(new StockDTO(s.getStid(), s.getIid(), s.getQty(), s.getData(), s.getSid(), s.getCost()));
        }
        return stocks;
    }

    @Override
    public boolean deleteStock(String stid) throws Exception {
        return stockDAO.deleteStock(stid);
    }

    @Override
    public boolean updateStock(StockDTO s) throws Exception {
        return stockDAO.updateStock(new Stock(s.getStid(), s.getIid(), s.getQty(), s.getData(), s.getSid(), s.getCost()));
    }

    @Override
    public ArrayList<StockDTO> getSelectedStocks(String itemCode) throws Exception {
        ArrayList<Stock>stocks=stockDAO.getSelectedStocks(itemCode);
        ArrayList<StockDTO>stockDTOS=new ArrayList<>();
        for (Stock s:stocks) {
            stockDTOS.add(new StockDTO(s.getStid(), s.getIid(), s.getQty(), s.getData(),s.getSid(), s.getCost()));
        }
        return stockDTOS;
    }
}
