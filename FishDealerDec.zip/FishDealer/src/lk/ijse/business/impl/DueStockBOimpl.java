package lk.ijse.business.impl;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import lk.ijse.business.custom.DueStockBO;
import lk.ijse.dao.custom.DueStockDAO;
import lk.ijse.dao.custom.QueryDAO;
import lk.ijse.dao.main.DAOFactory;
import lk.ijse.dto.DueStockDTO;
import lk.ijse.dto.DueStockTableDTO;
import lk.ijse.entity.CustomEntity;
import lk.ijse.entity.Customer;
import lk.ijse.entity.DueStock;

public class DueStockBOimpl implements DueStockBO{

    DueStockDAO dueStockDAO;
    QueryDAO queryDAO;
    public DueStockBOimpl() {
        this.dueStockDAO = DAOFactory.getInstance().getDAO(DAOFactory.DAOTypes.DUESTOCK);
        this.queryDAO=DAOFactory.getInstance().getDAO(DAOFactory.DAOTypes.QUERY);
    }

    @Override
    public boolean addNew(DueStockDTO due) throws Exception {
        return dueStockDAO.addnew(new DueStock(due.getIid(), due.getQty()));
    }

    @Override
    public String getLastId() throws Exception {
        return dueStockDAO.getLastId();
    }


    @Override
    public boolean deleteDue(String iid) throws Exception {
        return dueStockDAO.delete(iid);
    }

    @Override
    public boolean updateQty(String iid, double v) throws Exception {
        return dueStockDAO.updateQty(iid,v);
    }
}
