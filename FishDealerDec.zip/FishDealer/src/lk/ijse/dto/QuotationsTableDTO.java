package lk.ijse.dto;

public class QuotationsTableDTO {
    private String customer;
    private String fish;
    private double price;

    public QuotationsTableDTO(String customer, String fish, double price) {
        this.customer = customer;
        this.fish = fish;
        this.price = price;
    }

    public String getCustomer() {
        return customer;
    }

    public String getFish() {
        return fish;
    }

    public double getPrice() {
        return price;
    }
}
