package lk.ijse.dto;

public class ItemDTO {
    private String iid;
    private String name;

    public ItemDTO(String iid, String name) {
        this.iid = iid;
        this.name = name;
    }

    public String getIid() {
        return iid;
    }

    public String getName() {
        return name;
    }
}
