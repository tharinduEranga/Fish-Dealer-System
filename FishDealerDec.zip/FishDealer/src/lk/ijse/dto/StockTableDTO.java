package lk.ijse.dto;

import java.sql.Date;

public class StockTableDTO {
    String iid;
    String itemName;
    String stid;
    String sid;
    double itemQty;
    double price;
    String supplierName;
    Date stockDate;
    public StockTableDTO(String iid, String itemName, double itemQty, double price, String supplierName, Date stockDate) {
        this.iid=iid;
        this.itemName = itemName;
        this.itemQty = itemQty;
        this.price = price;
        this.supplierName = supplierName;
        this.stockDate = stockDate;
    }
    public StockTableDTO(String stid, String iid, double itemQty, Date stockDate, String sid,  double price) {
        this.stid = stid;
        this.sid = sid;
        this.iid = iid;
        this.itemQty = itemQty;
        this.price = price;
        this.stockDate = stockDate;
    }
    public String getIid() {
        return iid;
    }

    public String getItemName() {
        return itemName;
    }

    public double getItemQty() {
        return itemQty;
    }

    public double getPrice() {
        return price;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public Date getStockDate() {
        return stockDate;
    }

    public String getStid() {
        return stid;
    }

    public String getSid() {
        return sid;
    }
}
