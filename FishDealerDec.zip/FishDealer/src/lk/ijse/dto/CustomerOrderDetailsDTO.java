package lk.ijse.dto;

public class CustomerOrderDetailsDTO {
    private double qty;
    private double unitPrice;
    private String oid;
   private String itemName;
   private String itemCode;

    public CustomerOrderDetailsDTO(double qty, double unitPrice, String oid, String itemName, String itemCode) {
        this.qty = qty;
        this.unitPrice = unitPrice;
        this.oid = oid;
        this.itemName = itemName;
        this.itemCode=itemCode;
    }


    public double getQty() {
        return qty;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public String getOid() {
        return oid;
    }

    public String getItemName() {
        return itemName;
    }

    public String getItemCode() {
        return itemCode;
    }
}
