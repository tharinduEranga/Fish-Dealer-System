package lk.ijse.dto;

public class QuotationsDTO {
    private String qid;
    private String cid;
    private String iid;
    private double price;

    public QuotationsDTO(String qid, String cid, String iid, double price) {
        this.qid = qid;
        this.cid = cid;
        this.iid = iid;
        this.price = price;
    }

    public String getQid() {
        return qid;
    }

    public String getCid() {
        return cid;
    }

    public String getIid() {
        return iid;
    }

    public double getPrice() {
        return price;
    }
}
