package lk.ijse.dto;

public class SupplierDTO {
    private String id;
    private String name;
    private String mid;
    private int tel;

    public SupplierDTO(String id, String name, String mid, int tel) {
        this.id = id;
        this.name = name;
        this.mid = mid;
        this.tel = tel;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getMid() {
        return mid;
    }

    public int getTel() {
        return tel;
    }
}
