package lk.ijse.dto;

public class OrderDetailsTableDTO {
    private String oid;
    private String custName;
    private String itemName;
    private double qty;
    private double price;

    public OrderDetailsTableDTO(String oid, String custName, String itemName, double qty, double price) {
        this.oid=oid;
        this.custName = custName;
        this.itemName = itemName;
        this.qty = qty;
        this.price = price;
    }
    public OrderDetailsTableDTO(String itemName, double qty, double price) {
        this.itemName = itemName;
        this.qty = qty;
        this.price = price;
    }

    public String getCustName() {
        return custName;
    }

    public String getItemName() {
        return itemName;
    }

    public double getQty() {
        return qty;
    }

    public double getPrice() {
        return price;
    }

    public String getOid() {
        return oid;
    }
}
