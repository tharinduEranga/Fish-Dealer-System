package lk.ijse.dto;

public class PlaceOrderTableDTO {
    private String name;
   private double qty;
    private double unitPrice;
    private double amount;
    private String iid;

    public PlaceOrderTableDTO(String name, double qty, double unitPrice, String iid) {
        this.name = name;
        this.qty = qty;
        this.unitPrice = unitPrice;
        this.amount = qty*unitPrice;
        this.iid=iid;
    }

    public String getName() {
        return name;
    }

    public double getQty() {
        return qty;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public double getAmount() {
        return amount;
    }

    public String getIid() {
        return iid;
    }
}
