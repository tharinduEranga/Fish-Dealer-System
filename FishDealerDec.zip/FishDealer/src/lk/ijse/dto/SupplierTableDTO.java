package lk.ijse.dto;

import java.sql.Date;

public class SupplierTableDTO {
    private String name;
    private String market;
    private int tel;

    public SupplierTableDTO(String name, String market, int tel) {
        this.name = name;
        this.market = market;
        this.tel = tel;
    }

    public String getName() {
        return name;
    }

    public String getMarket() {
        return market;
    }

    public int getTel() {
        return tel;
    }
}
