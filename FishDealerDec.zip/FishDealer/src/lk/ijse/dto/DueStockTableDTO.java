package lk.ijse.dto;

public class DueStockTableDTO {
   private String itemName;
    private double qty;

    public DueStockTableDTO(String itemName, double qty) {
        this.itemName = itemName;
        this.qty = qty;
    }

    public String getItemName() {
        return itemName;
    }

    public double getQty() {
        return qty;
    }
}
