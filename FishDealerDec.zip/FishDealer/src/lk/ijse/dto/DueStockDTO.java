package lk.ijse.dto;

public class DueStockDTO {
    private String iid;
    private double qty;
    public DueStockDTO(String iid, double qty) {
        this.iid = iid;
        this.qty=qty;
    }


    public String getIid() {
        return iid;
    }

    public double getQty() {
        return qty;
    }
}
