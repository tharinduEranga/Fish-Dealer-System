package lk.ijse.dto;

import javafx.collections.ObservableList;

import java.sql.Date;
import java.util.ArrayList;

public class OrderDTO {
    private String oid;
    private String custName;

    private Date date;
    private String priority;
    private String cid;
    private double price;
    private ArrayList<CustomerOrderDetailsDTO> orderDetils;

    public OrderDTO(String oid, Date date, String priority, String cid, double price, ArrayList<CustomerOrderDetailsDTO> orderDetils) {
        this.oid = oid;
        this.date = date;
        this.priority = priority;
        this.cid = cid;
        this.price=price;
        this.orderDetils = orderDetils;
    }

    public OrderDTO(String oid, Date date, String priority, String cid, double price) {
        this.oid = oid;
        this.date = date;
        this.priority = priority;
        this.cid = cid;
        this.price=price;

    }
    public OrderDTO(String oid,String custName, Date date, double price, String priority) {
        this.oid = oid;
        this.custName = custName;
        this.date = date;
        this.priority = priority;
        this.price = price;
    }

    public OrderDTO(String custName, Date date, double price) {
        this.custName = custName;
        this.date = date;
        this.price = price;
    }

    public String getOid() {
        return oid;
    }

    public Date getDate() {
        return date;
    }

    public String getPriority() {
        return priority;
    }

    public String getCid() {
        return cid;
    }

    public double getPrice() {
        return price;
    }
    public String getCustName() {
        return custName;
    }
    public ArrayList<CustomerOrderDetailsDTO> getOrderDetils() {
        return orderDetils;
    }

    public void setOrderDetils(ObservableList<CustomerOrderDetailsDTO> orderDetils) {
        this.orderDetils = new ArrayList<>(orderDetils);
    }
}
