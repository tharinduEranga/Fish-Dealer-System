package lk.ijse.dto;

import java.sql.Date;

public class PaymentDTO {
    private String pid;
    private String oid;
    private Date date;
    private double amount;
    private String custName;
    public PaymentDTO(String pid, String oid, Date date, double amount) {
        this.pid = pid;
        this.oid = oid;
        this.date = date;
        this.amount = amount;
    }

    public PaymentDTO(String pid, Date date, double amount, String custName) {
        this.pid = pid;
        this.date = date;
        this.amount = amount;
        this.custName = custName;
    }

    public String getPid() {
        return pid;
    }

    public String getOid() {
        return oid;
    }

    public Date getDate() {
        return date;
    }

    public String getCustName() {
        return custName;
    }

    public double getAmount() {
        return amount;
    }
}
