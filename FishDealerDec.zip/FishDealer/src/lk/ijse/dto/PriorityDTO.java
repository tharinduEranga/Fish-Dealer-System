package lk.ijse.dto;

public class PriorityDTO {
    private String pid;
    private String type;

    public PriorityDTO(String pid, String type) {
        this.pid = pid;
        this.type = type;
    }

    public String getPid() {
        return pid;
    }

    public String getType() {
        return type;
    }
}
