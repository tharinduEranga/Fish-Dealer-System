package lk.ijse.dto;

public class ItemTableDTO {
    private String iid;
    private String name;
    private double qty;

    public ItemTableDTO( String iid,String name, double qty) {
        this.iid=iid;
        this.name = name;
        this.qty = qty;
    }

    public String getIid() {
        return iid;
    }

    public String getName() {
        return name;
    }

    public double getQty() {
        return qty;
    }
}
