package lk.ijse.dto;

import java.text.DateFormat;
import java.time.LocalDate;

public class CustomerDTO {
    private String cid;
    private String name;
    private String address;
    private int tel;
    private java.sql.Date date;

    public CustomerDTO() {
    }

    public CustomerDTO(String cid, String name, String address, int tel, java.sql.Date date) {
        this.cid = cid;
        this.name = name;
        this.address = address;
        this.tel = tel;
        this.date = date;
    }

    public String getCid() {
        return cid;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public int getTel() {
        return tel;
    }

    public java.sql.Date getDate() {
        return date;
    }
}
