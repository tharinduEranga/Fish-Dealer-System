package lk.ijse.dto;

import java.time.LocalDate;

public class CustomerTableDTO {
    private String name;
    private String address;
    private int tel;
    private java.sql.Date regDate;

    public CustomerTableDTO(String name, String address, int tel, java.sql.Date regDate) {
        this.name = name;
        this.address = address;
        this.tel = tel;
        this.regDate=regDate;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public int getTel() {
        return tel;
    }

    public java.sql.Date getRegDate() {
        return regDate;
    }
}
