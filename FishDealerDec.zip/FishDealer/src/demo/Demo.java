package demo;
enum Colour{
    RED(1001),GREEN(1002),BLACK(1003),BLUE(1004); //Objects
    private int code;

    private Colour(int code) {
        this.code = code;
    }

    /**
     * @return the code
     */
    public int getCode() {
        return code;
    }

    /**
     * @param code the code to set
     */
    public void setCode(int code) {
        this.code = code;
    }

}
public class Demo {
    public static void main(String[] args) {
        Colour c1=Colour.BLACK;
        System.out.println("Code of black : "+c1.getCode());
        c1.setCode(1111);
        System.out.println("Code of black : "+c1.getCode());
    }
}